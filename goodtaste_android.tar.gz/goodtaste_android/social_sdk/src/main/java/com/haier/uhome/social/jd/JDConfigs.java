/*
 * Copyright 2012 360buy, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.haier.uhome.social.jd;

/**
 * SDK使用的常量
 */
public interface JDConfigs {
    int JD_REQUEST_CODE = 10001;
    int AUTH_FAILED = 10003;
    String DEFAULT_CHARSET = "UTF-8";
    String ACCEPT_ENCODING = "gzip";
    String POST_METHOD = "POST";
    String USAGE_AGENT = " 360buy-sdk-java";
    String GET_METHOD = "GET";
    String AUTH_KEY = "code";

    String URL_AUTH = "https://oauth.jd.com/oauth/authorize?";
    String URL_TOKEN = "https://oauth.jd.com/oauth/token?";
    String URL_REGISTER = "https://passport.m.jd.com/user/home.action";
}
