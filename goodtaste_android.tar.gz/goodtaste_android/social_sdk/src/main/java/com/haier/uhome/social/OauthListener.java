package com.haier.uhome.social;

import java.util.Map;

/**
 * Created by dallas on 16-5-6.
 */
public interface OauthListener {
    void onComplete(@OauthPlatform.Type int platform, Map<String, String> data);

    void onError(@OauthPlatform.Type int platform, Throwable err);

    void onCancel(@OauthPlatform.Type int platform);
}
