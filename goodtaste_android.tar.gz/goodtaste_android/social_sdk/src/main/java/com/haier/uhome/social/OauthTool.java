package com.haier.uhome.social;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.alibaba.sdk.android.AlibabaSDK;
import com.alibaba.sdk.android.callback.CallbackContext;
import com.alibaba.sdk.android.login.LoginService;
import com.alibaba.sdk.android.login.callback.LoginCallback;
import com.alibaba.sdk.android.login.callback.LogoutCallback;
import com.alibaba.sdk.android.session.model.Session;
import com.haier.uhome.social.jd.JDAuthActivity;
import com.haier.uhome.social.jd.JDConfigs;
import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.bean.SHARE_MEDIA;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by dallas on 16-5-6.
 */
public class OauthTool {
    private static OauthTool instance;

    public static OauthTool get(Context context) {
        if (instance == null) {
            instance = new OauthTool(context.getApplicationContext());
        }
        return instance;
    }

    public static void destroy() {
        if (instance == null) {
            return;
        }
        if (instance.mOauthVerifyListener != null) {
            instance.mOauthVerifyListener = null;
        }
        if (instance.mOauthDeleteListener != null) {
            instance.mOauthDeleteListener = null;
        }
        if (instance.mShareAPI != null) {
            instance.mShareAPI = null;
        }
        instance = null;
    }


    private UMShareAPI mShareAPI;
    private InnerAuthListener mOauthVerifyListener;
    private InnerAuthListener mOauthDeleteListener;

    private OauthTool(Context context) {
        mShareAPI = UMShareAPI.get(context);
    }

    public void doOauthVerify(Activity activity, @OauthPlatform.Type final int platform, OauthListener listener) {
        SHARE_MEDIA pf = null;
        mOauthVerifyListener = new InnerAuthListener(listener);
        switch (platform) {
            case OauthPlatform.ALI:
                LoginService loginService = AlibabaSDK.getService(LoginService.class);
                loginService.showLogin(activity, new LoginCallback() {
                    @Override
                    public void onSuccess(Session session) {
                        Map<String, String> data = new HashMap<>();
                        data.put("login_time", session.getLoginTime() + "");
                        data.put("auth_code", session.getAuthorizationCode());
                        data.put("user_id", session.getUserId());
                        data.put("avatar_url", session.getUser().avatarUrl);
                        data.put("nick_name", session.getUser().nick);

                        mOauthVerifyListener.mOauthListener.onComplete(OauthPlatform.ALI, data);
                    }

                    @Override
                    public void onFailure(int code, String message) {
                        if (code == 10003) {
                            mOauthVerifyListener.mOauthListener.onCancel(OauthPlatform.ALI);
                        } else {
                            Exception exception = new Exception(code + ":" + message);
                            mOauthVerifyListener.mOauthListener.onError(OauthPlatform.ALI, exception);
                        }
                    }
                });
                return;
            case OauthPlatform.JD:
                Intent intent = new Intent(activity, JDAuthActivity.class);
                activity.startActivityForResult(intent, JDConfigs.JD_REQUEST_CODE);
                return;
            case OauthPlatform.QQ:
                pf = SHARE_MEDIA.QQ;
                break;
            case OauthPlatform.QZONE:
                pf = SHARE_MEDIA.QZONE;
                break;
            case OauthPlatform.TENCENT_WEIBO:
                pf = SHARE_MEDIA.TENCENT;
                break;
            case OauthPlatform.WEIXIN:
                pf = SHARE_MEDIA.WEIXIN;
                break;
            case OauthPlatform.DOUBAN:
                pf = SHARE_MEDIA.DOUBAN;
                break;
            case OauthPlatform.RENREN:
                pf = SHARE_MEDIA.RENREN;
                break;
            case OauthPlatform.SINA:
                pf = SHARE_MEDIA.SINA;
                break;
            default:
                break;
        }
        if (pf != null) {
            mShareAPI.doOauthVerify(activity, pf, mOauthVerifyListener);
        }
    }

    public void deleteOauth(Activity activity, @OauthPlatform.Type int platform, OauthListener listener) {
        SHARE_MEDIA pf = null;
        mOauthDeleteListener = new InnerAuthListener(listener);
        switch (platform) {
            case OauthPlatform.ALI:
                LoginService loginService = AlibabaSDK.getService(LoginService.class);
                loginService.logout(activity, new LogoutCallback() {
                    @Override
                    public void onSuccess() {
                        mOauthDeleteListener.mOauthListener.onComplete(OauthPlatform.ALI,
                            new HashMap<String, String>());
                    }

                    @Override
                    public void onFailure(int code, String message) {
                        Exception exception = new Exception(code + ":" + message);
                        mOauthDeleteListener.mOauthListener.onError(OauthPlatform.ALI, exception);
                    }
                });
                return;
            case OauthPlatform.JD:
                listener.onComplete(platform, new HashMap<String, String>());
                return;
            case OauthPlatform.QQ:
                pf = SHARE_MEDIA.QQ;
                break;
            case OauthPlatform.QZONE:
                pf = SHARE_MEDIA.QZONE;
                break;
            case OauthPlatform.TENCENT_WEIBO:
                pf = SHARE_MEDIA.TENCENT;
                break;
            case OauthPlatform.WEIXIN:
                pf = SHARE_MEDIA.WEIXIN;
                break;
            case OauthPlatform.DOUBAN:
                pf = SHARE_MEDIA.DOUBAN;
                break;
            case OauthPlatform.RENREN:
                pf = SHARE_MEDIA.RENREN;
                break;
            case OauthPlatform.SINA:
                pf = SHARE_MEDIA.SINA;
                break;
            default:
                break;
        }
        if (pf != null) {
            mShareAPI.deleteOauth(activity, pf, mOauthDeleteListener);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent resultData) {
        if (requestCode == JDConfigs.JD_REQUEST_CODE) {
            switch (resultCode) {
                case Activity.RESULT_OK:
                    String result = resultData.getStringExtra("result");
                    try {
                        JSONObject object = new JSONObject(result);
                        Map<String, String> data = new HashMap<>();
                        data.put("access_token", object.getString("access_token"));
                        data.put("code", object.getString("code"));
                        data.put("expires_in", object.getString("expires_in"));
                        data.put("refresh_token", object.getString("refresh_token"));
                        data.put("time", object.getString("time"));
                        data.put("token_type", object.getString("token_type"));
                        data.put("uid", object.getString("uid"));
                        data.put("user_nick", object.getString("user_nick"));

                        mOauthVerifyListener.mOauthListener.onComplete(OauthPlatform.JD, data);
                    } catch (JSONException e) {
                        mOauthVerifyListener.mOauthListener.onError(OauthPlatform.JD, e);
                    }
                    break;
                case Activity.RESULT_CANCELED:
                    mOauthVerifyListener.mOauthListener.onCancel(OauthPlatform.JD);
                    break;
                case JDConfigs.AUTH_FAILED:
                    Throwable error = (Throwable) resultData.getSerializableExtra("error");
                    mOauthVerifyListener.mOauthListener.onError(OauthPlatform.JD, error);
                    break;
                default:
                    break;
            }
        } else if (requestCode == 59995) {
            CallbackContext.onActivityResult(requestCode, resultCode, resultData);
        } else {
            mShareAPI.onActivityResult(requestCode, resultCode, resultData);
        }
    }

    private static class InnerAuthListener implements UMAuthListener {
        private OauthListener mOauthListener;

        public InnerAuthListener(OauthListener oauthListener) {
            mOauthListener = oauthListener;
        }

        @Override
        public void onComplete(SHARE_MEDIA platform, int action, Map<String, String> data) {
            int pf = -1;
            switch (platform) {
                case QQ:
                    pf = OauthPlatform.QQ;
                    break;
                case QZONE:
                    pf = OauthPlatform.QZONE;
                    break;
                case TENCENT:
                    pf = OauthPlatform.TENCENT_WEIBO;
                    break;
                case WEIXIN:
                    pf = OauthPlatform.WEIXIN;
                    break;
                case DOUBAN:
                    pf = OauthPlatform.DOUBAN;
                    break;
                case RENREN:
                    pf = OauthPlatform.RENREN;
                    break;
                case SINA:
                    pf = OauthPlatform.SINA;
                    break;
                default:
                    break;
            }
            if (pf != -1) {
                mOauthListener.onComplete(pf, data);
            }
        }

        @Override
        public void onError(SHARE_MEDIA platform, int action, Throwable throwable) {
            int pf = -1;
            switch (platform) {
                case QQ:
                    pf = OauthPlatform.QQ;
                    break;
                case QZONE:
                    pf = OauthPlatform.QZONE;
                    break;
                case TENCENT:
                    pf = OauthPlatform.TENCENT_WEIBO;
                    break;
                case WEIXIN:
                    pf = OauthPlatform.WEIXIN;
                    break;
                case DOUBAN:
                    pf = OauthPlatform.DOUBAN;
                    break;
                case RENREN:
                    pf = OauthPlatform.RENREN;
                    break;
                case SINA:
                    pf = OauthPlatform.SINA;
                    break;
                default:
                    break;
            }
            if (pf != -1) {
                mOauthListener.onError(pf, throwable);
            }
        }

        @Override
        public void onCancel(SHARE_MEDIA platform, int action) {
            int pf = -1;
            switch (platform) {
                case QQ:
                    pf = OauthPlatform.QQ;
                    break;
                case QZONE:
                    pf = OauthPlatform.QZONE;
                    break;
                case TENCENT:
                    pf = OauthPlatform.TENCENT_WEIBO;
                    break;
                case WEIXIN:
                    pf = OauthPlatform.WEIXIN;
                    break;
                case DOUBAN:
                    pf = OauthPlatform.DOUBAN;
                    break;
                case RENREN:
                    pf = OauthPlatform.RENREN;
                    break;
                case SINA:
                    pf = OauthPlatform.SINA;
                    break;
                default:
                    break;
            }
            if (pf != -1) {
                mOauthListener.onCancel(pf);
            }
        }
    }
}
