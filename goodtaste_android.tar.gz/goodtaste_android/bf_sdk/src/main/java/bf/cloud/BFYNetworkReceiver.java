package bf.cloud;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

/**
 * @author wang
 */
public final class BFYNetworkReceiver extends BroadcastReceiver {
    private final static String TAG = BFYNetworkReceiver.class.getSimpleName();
    public final static int NET_STATE_CONNECTION_NONE = 0;
    public final static int NET_STATE_CONNECTION_WIFI = 1;
    public final static int NET_STATE_CONNECTION_MOBILE = 2;
    public final static int NET_STATE_CONNECTION_ETHERNET = 3;

    private int mCurrentNetState = NET_STATE_CONNECTION_NONE;
    private int mLastNetState = NET_STATE_CONNECTION_NONE;
    private NetStateChangedListener mListener = null;


    private void updateNetState(Context context) {
        if (isWifiEnabled(context)) {
            mCurrentNetState = NET_STATE_CONNECTION_WIFI;
        } else if (isMobileEnabled(context)) {
            mCurrentNetState = NET_STATE_CONNECTION_MOBILE;
        } else if (isEthernetEnabled(context)) {
            mCurrentNetState = NET_STATE_CONNECTION_ETHERNET;
        } else {
            mCurrentNetState = NET_STATE_CONNECTION_NONE;
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "onReceive");
        String action = intent.getAction();
        if (!action.equalsIgnoreCase(ConnectivityManager.CONNECTIVITY_ACTION)) {
            return;
        }
        updateNetState(context);
        if (mLastNetState != mCurrentNetState) {
            mLastNetState = mCurrentNetState;
        }
        if (mListener != null) {
            mListener.onChanged(mLastNetState, mCurrentNetState);
        }
    }

    public static boolean isWifiEnabled(Context context) {
        ConnectivityManager connectMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifiNetInfo = connectMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        return wifiNetInfo != null && wifiNetInfo.isConnected();
    }

    public static boolean isEthernetEnabled(Context context) {
        ConnectivityManager connectMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ethernetNetInfo = connectMgr.getNetworkInfo(ConnectivityManager.TYPE_ETHERNET);
        return ethernetNetInfo != null && ethernetNetInfo.isConnected();
    }

    /**
     * 判断当前网络是否是移动数据或其他（非wifi）
     */
    public static boolean isMobileEnabled(Context context) {
        ConnectivityManager connectMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        //NetworkInfo mobNetInfo = connectMgr.getActiveNetworkInfo();
        NetworkInfo mobNetInfo = connectMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        //boolean isMobEnabled = (mobNetInfo != null && mobNetInfo.isConnected() && mobNetInfo.getType()
        // != ConnectivityManager.TYPE_WIFI);
        //mCode = BFYNetworkStatusData.NETWORK_CONNECTION_MOBILE;
        return (mobNetInfo != null && mobNetInfo.isConnected());
    }

    public int getCurrentNetworkState() {
        return mCurrentNetState;
    }

    public interface NetStateChangedListener {
        void onChanged(int lastNetState, int currentNetState);
    }

    public void registerNetStateChangedListener(NetStateChangedListener listener) {
        mListener = listener;
    }
}	