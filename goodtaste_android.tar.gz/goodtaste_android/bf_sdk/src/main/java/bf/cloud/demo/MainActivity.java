package bf.cloud.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.uhome.haier.bf_sdk.R;


public class MainActivity extends Activity {
    private Button btVod = null;
    private Button btLive = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        btVod = (Button) findViewById(R.id.vod);
        btVod.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, VodDemo.class);
                startActivity(intent);
            }
        });
        btLive = (Button) findViewById(R.id.live);
        btLive.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, LiveDemo.class);
                startActivity(intent);
            }
        });
    }
}
