package bf.cloud.demo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import com.uhome.haier.bf_sdk.R;

import bf.cloud.BFMediaPlayerControllerVod;
import bf.cloud.android.playutils.BasePlayer.PLAYER_TYPE;
import bf.cloud.android.playutils.BasePlayer.RATIO_TYPE;
import bf.cloud.android.playutils.DecodeMode;
import bf.cloud.android.playutils.VodPlayer;

public class VodDemo extends Activity {
    private final String TAG = VodDemo.class.getSimpleName();

    private VodPlayer mVodPlayer = null;
    private BFMediaPlayerControllerVod mMediaController = null;
    private String[] mUrls = {
        "servicetype=1&uid=4995606&fid=D754D209A442A6787962AB1552FF9412",
        "servicetype=1&uid=23896155&fid=967E8957F7ACA54C7FACA0EE80EF4CCE",
        "servicetype=1&uid=11165311&fid=226ED66AD284488DA46DF1859D6CBAB6"};
    private int mVideoIndex = 0;
    private EditText mInputUrl = null;
    private EditText mInputToken = null;
    private Toast mNotice = null;
    private long mHistory = -1;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_vod);
        init();
    }

    private void init() {
        mVideoIndex = 0;
        mMediaController = (BFMediaPlayerControllerVod) findViewById(R.id.vod_media_controller_vod);
        mInputUrl = (EditText) findViewById(R.id.play_url);
        mInputToken = (EditText) findViewById(R.id.play_token);
        mVodPlayer = (VodPlayer) mMediaController.getPlayer();
        // 预设一个DataSource
        mVodPlayer.setDataSource(mUrls[0]);
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.change_decode_mode) {
            String[] items = {"自动(ExoPlayer优先)", "软解", "系统原生解码(MediaPlayer)"};
            int checkedItem = -1;
            Log.d(TAG,
                    "mVodPlayer.getDecodeMode():" + mVodPlayer.getDecodeMode());
            if (mVodPlayer.getDecodeMode() == DecodeMode.AUTO) {
                checkedItem = 0;
            } else if (mVodPlayer.getDecodeMode() == DecodeMode.SOFT) {
                checkedItem = 1;
            } else
                checkedItem = 2;
            new AlertDialog.Builder(this)
                    .setSingleChoiceItems(items, checkedItem, null)
                    .setPositiveButton("确认",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    dialog.dismiss();
                                    mVodPlayer.stop();
                                    int position = ((AlertDialog) dialog)
                                            .getListView()
                                            .getCheckedItemPosition();
                                    if (position == 0) {
                                        mVodPlayer
                                                .setDecodeMode(DecodeMode.AUTO);
                                    } else if (position == 1) {
                                        mVodPlayer
                                                .setDecodeMode(DecodeMode.SOFT);
                                    } else {
                                        mVodPlayer.setDecodeMode(DecodeMode.MEDIAPLYAER);
                                    }
                                }
                            })
                    .setNegativeButton("取消",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    dialog.dismiss();
                                }
                            }).show();
        } else if (id == R.id.change_player_type) {
            String[] items = {"普通播放器", "全景播放器"};
            int checkedItem = -1;
            Log.d(TAG, "mVodPlayer.getDecodeMode():" + mVodPlayer.getPlayerType());
            if (mVodPlayer.getPlayerType() == PLAYER_TYPE.NORMAL) {
                checkedItem = 0;
            } else if (mVodPlayer.getPlayerType() == PLAYER_TYPE.FULL_SIGHT) {
                checkedItem = 1;
            }
            new AlertDialog.Builder(this)
                    .setSingleChoiceItems(items, checkedItem, null)
                    .setPositiveButton("确认",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    dialog.dismiss();
                                    mVodPlayer.stop();
                                    int position = ((AlertDialog) dialog)
                                            .getListView()
                                            .getCheckedItemPosition();
                                    if (position == 0) {
                                        mVodPlayer
                                                .setPlayerType(PLAYER_TYPE.NORMAL);
                                    } else if (position == 1) {
                                        mVodPlayer
                                                .setPlayerType(PLAYER_TYPE.FULL_SIGHT);
                                    }
                                }
                            })
                    .setNegativeButton("取消",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    dialog.dismiss();
                                }
                            }).show();
        } else if (id == R.id.start) {
            Log.d(TAG, "Start onClick");
            mVodPlayer.stop();
            String inputUrl = mInputUrl.getText().toString();
            String inputToken = mInputToken.getText().toString();
            if (inputUrl != null && inputUrl.length() != 0)
                mVodPlayer.setDataSource(inputUrl, inputToken);
            else {
                mVodPlayer.setDataSource(mUrls[mVideoIndex], inputToken);
                if (mNotice != null)
                    mNotice.cancel();
                mNotice = Toast.makeText(this, "开始播放默认视频", Toast.LENGTH_SHORT);
                mNotice.show();
            }
            mVodPlayer.start();
        } else if (id == R.id.stop) {
            mVodPlayer.stop();

        } else if (id == R.id.change_video) {
            mVideoIndex++;
            if (mVideoIndex > mUrls.length - 1)
                mVideoIndex = 0;
            mVodPlayer.stop();
            mVodPlayer.setDataSource(mUrls[mVideoIndex]);
            mVodPlayer.start();
            if (mNotice != null)
                mNotice.cancel();
            mNotice = Toast.makeText(this, "开始播放默认视频", Toast.LENGTH_SHORT);
            mNotice.show();
        } else if (id == R.id.pause) {
            mVodPlayer.pause();

        } else if (id == R.id.resume) {
            mVodPlayer.resume();

        } else if (id == R.id.seekto) {
            mVodPlayer.seekTo(30000);

        } else if (id == R.id.inc_volume) {
            mVodPlayer.incVolume();

        } else if (id == R.id.dec_volume) {
            mVodPlayer.decVolume();

        } else if (id == R.id.get_current_volume) {
            int value = mVodPlayer.getCurrentVolume();
            Toast.makeText(VodDemo.this, "" + value, Toast.LENGTH_SHORT).show();
        } else if (id == R.id.get_max_volume) {
            int value = mVodPlayer.getMaxVolume();
            Toast.makeText(VodDemo.this, "" + value, Toast.LENGTH_SHORT).show();
        } else if (id == R.id.get_cur_position) {
            long value = mVodPlayer.getCurrentPosition();
            Toast.makeText(VodDemo.this, "" + value, Toast.LENGTH_SHORT).show();
        } else if (id == R.id.get_duration) {
            long value = mVodPlayer.getDuration();
            Toast.makeText(VodDemo.this, "" + value, Toast.LENGTH_SHORT).show();
        } else if (id == R.id.auto_screen) {
            String[] items = {"是", "否"};
            int checkedItem = -1;
            if (mMediaController.getAutoChangeScreen()) {
                checkedItem = 0;
            } else {
                checkedItem = 1;
            }
            new AlertDialog.Builder(this)
                    .setSingleChoiceItems(items, checkedItem, null)
                    .setPositiveButton("确认",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    dialog.dismiss();
                                    int position = ((AlertDialog) dialog)
                                            .getListView()
                                            .getCheckedItemPosition();
                                    if (position == 0) {
                                        mMediaController
                                                .setAutoChangeScreen(true);
                                    } else if (position == 1) {
                                        mMediaController
                                                .setAutoChangeScreen(false);
                                    }
                                }
                            })
                    .setNegativeButton("取消",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    dialog.dismiss();
                                }
                            }).show();
        } else if (id == R.id.changed_ratio) {
            String[] items = {"16:9", "4:3", "原视频输出"};
            int checkedItem = 0;
            if (mVodPlayer.getVideoAspectRatio() == RATIO_TYPE.TYPE_16_9) {
                checkedItem = 0;
            } else if (mVodPlayer.getVideoAspectRatio() == RATIO_TYPE.TYPE_4_3) {
                checkedItem = 1;
            } else if (mVodPlayer.getVideoAspectRatio() == RATIO_TYPE.TYPE_ORIGENAL) {
                checkedItem = 2;
            }
            new AlertDialog.Builder(this)
                    .setSingleChoiceItems(items, checkedItem, null)
                    .setPositiveButton("确认",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    dialog.dismiss();
                                    int position = ((AlertDialog) dialog)
                                            .getListView()
                                            .getCheckedItemPosition();
                                    if (position == 0) {
                                        mVodPlayer.setVideoAspectRatio(RATIO_TYPE.TYPE_16_9);
                                    } else if (position == 1) {
                                        mVodPlayer.setVideoAspectRatio(RATIO_TYPE.TYPE_4_3);
                                    } else if (position == 2) {
                                        mVodPlayer.setVideoAspectRatio(RATIO_TYPE.TYPE_ORIGENAL);
                                    }
                                }
                            })
                    .setNegativeButton("取消",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    dialog.dismiss();
                                }
                            }).show();
        } else {
        }

    }

    @Override
    protected void onPause() {
        Log.d(TAG, "onPause");
        mHistory = mVodPlayer.getCurrentPosition();
        mVodPlayer.stop();
        super.onPause();
    }

    @Override
    protected void onStart() {
        if (mHistory > 0) {
            mVodPlayer.start((int) mHistory);
            mHistory = -1;
        }
        super.onStart();
    }

    @Override
    protected void onDestroy() {
        mVodPlayer.stop();
        try {
            mMediaController.finalize();
        } catch (Throwable e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        Log.d(TAG, "onConfigurationChanged");
        super.onConfigurationChanged(newConfig);
    }
}
