package com.gmail.adffice.rxflux.action;

import android.support.annotation.NonNull;

import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.util.SubscriptionManager;

import rx.Subscription;

/**
 * 用于创建Flux构架中Action模块的抽象类。app通过该类的子类为其提供的功能来创建Action。
 * <br>Created by Dallas.
 */
public abstract class RxActionCreator {
    private final Dispatcher dispatcher;
    private final SubscriptionManager subscriptionManager;

    public RxActionCreator(Dispatcher dispatcher, SubscriptionManager subscriptionManager) {
        this.dispatcher = dispatcher;
        this.subscriptionManager = subscriptionManager;
    }

    protected void addRxAction(RxAction action, Subscription subscription) {
        subscriptionManager.add(action, subscription);
    }

    protected boolean hasRxAction(RxAction action) {
        return subscriptionManager.contains(action);
    }

    protected void removeRxAction(RxAction action) {
        subscriptionManager.remove(action);
    }

    public <T> RxAction<T> newRxAction(@NonNull String actionType, T data) {
        if (actionType.isEmpty()) {
            throw new IllegalArgumentException("Type must not be empty");
        }
        return new RxAction<T>(actionType, data);
    }

    protected void postRxAction(@NonNull RxAction action) {
        dispatcher.postRxAction(action);
    }

    protected void postError(@NonNull RxAction action, Throwable throwable) {
        dispatcher.postRxAction(RxError.newRxError(action, throwable));
    }
}
