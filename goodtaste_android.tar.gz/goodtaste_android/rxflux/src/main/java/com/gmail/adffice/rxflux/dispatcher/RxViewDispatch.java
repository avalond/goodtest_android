package com.gmail.adffice.rxflux.dispatcher;


import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;

/**
 * 所有的activities必须实现该接口，为了能够获取到store发生变化时所发出的事件。
 * <br>Created by Dallas
 */
public interface RxViewDispatch {

    /**
     * 当store发生变化是会调用该方法，这样View层就可以获取到数据并更新UI。
     *
     * @param change 变化的数据
     */
    void onRxStoreChanged(RxStoreChange change);

    /**
     * 当发生错误时会调用该方法，View对错误信息进行处理。
     *
     * @param error 错误信息
     */
    void onRxError(RxError error);

}
