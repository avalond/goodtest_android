package com.gmail.adffice.rxflux.store;

import com.gmail.adffice.rxflux.action.RxAction;

/**
 * 用于通知store已经发生改变，通常被用于通知View视图层。
 * 视图层收到后可以通过{@link RxStoreChange#getStoreId}来过滤自己所需要处理的事件，
 * 然后通过{@link RxStoreChange#getRxAction()}来获取数据并更新UI
 * <br>Created by Dallas.
 */
public class RxStoreChange {
    String storeId;
    RxAction rxAction;

    public RxStoreChange(String storeId, RxAction rxAction) {
        this.storeId = storeId;
        this.rxAction = rxAction;
    }

    public String getStoreId() {
        return storeId;
    }

    public RxAction getRxAction() {
        return rxAction;
    }

    @Override
    public String toString() {
        return "RxStoreChange{" +
            "storeId='" + storeId + '\'' +
            ", rxAction=" + rxAction +
            '}';
    }
}
