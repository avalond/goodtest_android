package com.gmail.adffice.rxflux.action;

import android.support.annotation.NonNull;

import java.util.HashMap;
import java.util.Map;

/**
 * 封装了错误事件
 * <br>Created by Dallas.
 */
public class RxError extends RxAction<Map> {
    public static final String ERROR_TYPE = "RxError_Type";
    public static final String ERROR_ACTION = "RxError_Action";
    public static final String ERROR_THROWABLE = "RxError_Throwable";

    private RxError(String type, Map data) {
        super(type, data);
    }

    public static RxError newRxError(@NonNull RxAction<?> action, Throwable throwable) {
        Map<String, Object> data = new HashMap<>();
        data.put(ERROR_ACTION, action);
        data.put(ERROR_THROWABLE, throwable);
        return new RxError(ERROR_TYPE, data);
    }

    public RxAction<?> getAction() {
        return (RxAction<?>) getData().get(ERROR_ACTION);
    }

    public Throwable getThrowable() {
        return (Throwable) getData().get(ERROR_THROWABLE);
    }

    @Override
    public String toString() {
        return "RxError{" +
            "action='" + getAction() + '\'' +
            ", throwable=" + getThrowable().getMessage() +
            '}';
    }
}
