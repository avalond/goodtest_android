package com.gmail.adffice.rxflux.action;


/**
 * Flux构架中Action模块。只提供两个字段：type 和 data, 分别记录Action的类型和数据
 * <br>Created by Dallas.
 */
public class RxAction<T> {
    private final String type;
    private final T data;

    RxAction(String type, T data) {
        if (type == null || type.isEmpty()) {
            throw new IllegalArgumentException("type is null!");
        }
        this.type = type;
        this.data = data;
    }

    public String getType() {
        return type;
    }

    public T getData() {
        return data;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RxAction<?> rxAction = (RxAction<?>) o;

        if (type != null ? !type.equals(rxAction.type) : rxAction.type != null) {
            return false;
        }
        return !(data != null ? !data.equals(rxAction.data) : rxAction.data != null);

    }

    @Override
    public int hashCode() {
        int result = type != null ? type.hashCode() : 0;
        result = 31 * result + (data != null ? data.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "RxAction{" +
            "type='" + type + '\'' +
            ", data=" + data +
            '}';
    }
}
