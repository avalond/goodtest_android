package com.gmail.adffice.rxflux.store;

/**
 * Created by Dallas on 2016/3/1.
 */
public interface RxStoresRegister {
    void onRxStoresRegister();
    void onRxStoresUnRegister();
}
