package com.gmail.adffice.rxflux.store;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.dispatcher.RxActionDispatch;

/**
 * Flux的Store模块。app的中所有store必须继承自该类并实现{@link RxActionDispatch#onRxAction(RxAction)}，
 * 当Dispatcher有数据派发过来的时候，可以通过子类的{@link RxActionDispatch#onRxAction(RxAction)}里处理。
 * <br>Created by Dallas.
 */
public abstract class RxStore implements RxActionDispatch {
    private Dispatcher dispatcher;

    protected RxStore(Dispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    public void register() {
        dispatcher.registerRxAction(this);
    }

    public void unregister() {
        dispatcher.unRegisterRxAction(this);
    }

    protected void postStoreChange(final RxStoreChange storeChange) {
        dispatcher.postRxStoreChange(storeChange);
    }
}
