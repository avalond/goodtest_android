package com.gmail.adffice.rxflux.dispatcher;

import android.app.Activity;
import android.support.v4.util.ArrayMap;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.gmail.adffice.rxflux.util.Logger;

import java.util.Map;

import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func1;

import static com.gmail.adffice.rxflux.RxFlux.TAG;

/**
 * Flux构架中Dispatcher模块，Store会在这里注册自己的回调接口。
 * Dispatcher会把Action分发到注册的Store，所以它会提供一些公有方法来注册监听和分发消息
 * <br>Created by Dallas.
 */
public class Dispatcher {
    public static Dispatcher instance;
    private final RxBus bus;
    private ArrayMap<String, Subscription> rxActionMap;
    private ArrayMap<String, Subscription> rxStoreMap;

    private Dispatcher(RxBus bus) {
        this.bus = bus;
        this.rxActionMap = new ArrayMap<>();
        this.rxStoreMap = new ArrayMap<>();
    }

    public static synchronized Dispatcher getInstance(RxBus rxBus) {
        if (instance == null) {
            instance = new Dispatcher(rxBus);
        }
        return instance;
    }

    /**
     * 注册action事件。当有事件发送时，store会收到事件并处理事件。
     *
     * @param actionDispatch 实现了{@link RxActionDispatch}的类对象
     * @param <T>            {@link RxActionDispatch}
     */
    public <T extends RxActionDispatch> void registerRxAction(final T actionDispatch) {
        final String tag = actionDispatch.getClass().getSimpleName();
        Subscription subscription = rxActionMap.get(tag);
        if (subscription == null || subscription.isUnsubscribed()) {
            Logger.logRxStoreRegister(tag);
            rxActionMap.put(tag, bus.get().onBackpressureBuffer().filter(new Func1<Object, Boolean>() {
                @Override
                public Boolean call(Object o) {
                    return o instanceof RxAction;
                }
            })  .subscribe(new Action1<Object>() {
                @Override
                public void call(Object o) {
                    Logger.logRxAction(tag, (RxAction) o);
                    actionDispatch.onRxAction((RxAction) o);
                }
            }));
        }
    }

    /**
     * 取消注册action事件
     *
     * @param object 实现了{@link RxActionDispatch}的类对象
     * @param <T>    {@link RxActionDispatch}
     */
    public <T extends RxActionDispatch> void unRegisterRxAction(final T object) {
        final String tag = object.getClass().getSimpleName();
        Subscription subscription = rxActionMap.get(tag);
        if (subscription != null && !subscription.isUnsubscribed()) {
            subscription.unsubscribe();
            rxActionMap.remove(tag);
            Logger.logUnregisterRxAction(tag);
        }
    }

    /**
     * 注册异常错误action事件。当有错误事件发生时，View视图层会收到事件并处理事件。
     *
     * @param object 实现了{@link RxViewDispatch}的类对象
     * @param <T>    {@link RxViewDispatch}
     */
    public <T extends RxViewDispatch> void registerRxError(final T object) {
        final String tag = object.getClass().getSimpleName() + "_error";
        Subscription subscription = rxActionMap.get(tag);
        if (subscription == null || subscription.isUnsubscribed()) {
            rxActionMap.put(tag, bus.get().onBackpressureBuffer().filter(new Func1<Object, Boolean>() {
                @Override
                public Boolean call(Object o) {
                    return o instanceof RxError;
                }
            })  .observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<Object>() {
                @Override
                public void call(Object o) {
                    Logger.logRxError(tag, (RxError) o);
                    object.onRxError((RxError) o);
                }
            }));
        }
    }

    /**
     * 取消注册异常错误事件
     *
     * @param object 实现了{@link RxViewDispatch}的类对象
     * @param <T>    {@link RxViewDispatch}
     */
    public <T extends RxViewDispatch> void unRegisterRxError(final T object) {
        final String tag = object.getClass().getSimpleName() + "_error";
        Subscription subscription = rxActionMap.get(tag);
        if (subscription != null && !subscription.isUnsubscribed()) {
            subscription.unsubscribe();
            rxActionMap.remove(tag);
        }
    }

    /**
     * 注册RxStoreChanged, 当store处理完数据或逻辑后发送{@link RxStoreChange}，这时实现了{@link RxViewDispatch}接口的View层刷新界面.
     * <br>建议在{@link Activity#onResume()}里调用.
     *
     * @param object 实现了{@link RxViewDispatch}的类对象
     * @param <T>    {@link RxViewDispatch}
     */
    public <T extends RxViewDispatch> void registerRxStoreChanged(final T object) {
        final String tag = object.getClass().getSimpleName();
        Subscription subscription = rxStoreMap.get(tag);
        if (subscription == null || subscription.isUnsubscribed()) {
            Logger.logViewRegisterToStore(tag);
            rxStoreMap.put(tag, bus.get().onBackpressureBuffer().filter(new Func1<Object, Boolean>() {
                @Override
                public Boolean call(Object o) {
                    return o instanceof RxStoreChange;
                }
            })  .observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<Object>() {
                @Override
                public void call(Object o) {
                    Logger.logRxStore(tag, (RxStoreChange) o);
                    object.onRxStoreChanged((RxStoreChange) o);
                }
            }));
        }
        registerRxError(object);
    }

    /**
     * 取消注册RxStoreChanged, 建议在{@link Activity#onPause()}里调用.
     *
     * @param object 实现了{@link RxViewDispatch}的类对象
     * @param <T>    {@link RxViewDispatch}
     */
    public <T extends RxViewDispatch> void unRegisterRxStoreChanged(final T object) {
        final String tag = object.getClass().getSimpleName();
        Subscription subscription = rxStoreMap.get(tag);
        if (subscription != null && !subscription.isUnsubscribed()) {
            subscription.unsubscribe();
            rxStoreMap.remove(tag);
            Logger.logUnregisterRxStore(tag);
        }
        unRegisterRxError(object);
    }

    /**
     * 取消注册所有事件
     */
    public synchronized void unregisterAll() {
        Logger.log(TAG, "unregisterAll");
        for (Map.Entry<String, Subscription> entry : rxActionMap.entrySet()) {
            if (entry.getValue().isUnsubscribed()) {
                entry.getValue().unsubscribe();
            }
            Logger.logUnregisterRxAction(entry.getKey());
        }

        for (Map.Entry<String, Subscription> entry : rxStoreMap.entrySet()) {
            if (entry.getValue().isUnsubscribed()) {
                entry.getValue().unsubscribe();
            }
            Logger.logUnregisterRxStore(entry.getKey());
        }
        rxActionMap.clear();
        rxStoreMap.clear();
        Logger.log(TAG, "unregisterAll end");
    }

    public void postRxAction(final RxAction action) {
        bus.post(action);
    }

    public void postRxStoreChange(final RxStoreChange storeChange) {
        bus.post(storeChange);
    }
}
