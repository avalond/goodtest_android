package com.haier.uhome.goodtaste;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.support.multidex.MultiDex;
import android.text.TextUtils;

import com.gmail.adffice.rxflux.RxFlux;
import com.haier.uhome.goodtaste.actions.DeviceActionCreator;
import com.haier.uhome.goodtaste.actions.UserActionCreator;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.exception.SdkException;
import com.haier.uhome.goodtaste.utils.ChannelUtil;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.social.OauthPlatform;
import com.haier.uhome.uAnalytics.MobEvent;
import com.haier.uhome.uAnalytics.PolicyConst;
import com.haier.uhome.uphybrid.UpHybrid;
import com.haier.uhome.usdk.api.uSDKErrorConst;
import com.haier.uhome.usdk.api.uSDKManager;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.umeng.analytics.AnalyticsConfig;
import com.umeng.analytics.MobclickAgent;

import java.util.Random;

import rx.Observable;
import rx.Subscriber;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.functions.Func2;
import rx.schedulers.Schedulers;

/**
 * <br>Created by dallas on 16-4-18.
 */
public class HaierApplication extends Application {
    public static final String TAG = "HaierApp";

    private RxFlux mRxFlux;
    private DataManager mDataManager;
    private UserActionCreator mUserActionCreator;
    private DeviceActionCreator mDeviceActionCreator;

    @Override
    public void onCreate() {
        super.onCreate();
        MultiDex.install(this);
        init();
    }

    public RxFlux getRxFlux() {
        return mRxFlux;
    }

    public UserActionCreator getUserActionCreator() {
        return mUserActionCreator;
    }

    public DeviceActionCreator getDeviceActionCreator() {
        return mDeviceActionCreator;
    }

    public DataManager getDataManager() {
        return mDataManager;
    }

    public String getAppId() {
        return getMetaData("APP_ID", "MB-WZD-0000");
    }

    public String getAppKey() {
        return getMetaData("APP_KEY", "ae20e80702156ca45eb5ec66d4581e4a");
    }

    public String getAppVersion() {
        PackageManager packageManager = getPackageManager();
        PackageInfo packInfo;
        try {
            packInfo = packageManager.getPackageInfo(getPackageName(), 0);
            return packInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return "1.0";
    }

    public long getVersionCode() {
        PackageManager packageManager = getPackageManager();
        PackageInfo packInfo;
        try {
            packInfo = packageManager.getPackageInfo(getPackageName(), 0);
            return packInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public String getMetaData(String key, String defaultValue) {
        ApplicationInfo appInfo;
        try {
            appInfo = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            if (appInfo.metaData != null) {
                return appInfo.metaData.getString(key, defaultValue);
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return defaultValue;
    }

    public void startSdk() {
        startSdk(this).subscribe(new Action1<uSDKErrorConst>() {
            @Override
            public void call(uSDKErrorConst ret) {
                if (ret == uSDKErrorConst.RET_USDK_OK) {
                    HaierLoger.d(TAG, "start usdk success!");
                }
            }
        });
    }

    /**
     * 启动uSDK，内部会重试3次，如果3次都失败则失败。
     */
    public Observable<uSDKErrorConst> startSdk(final Context context) {
        return Observable.create(new Observable.OnSubscribe<uSDKErrorConst>() {
            @Override
            public void call(Subscriber<? super uSDKErrorConst> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                uSDKManager mgr = uSDKManager.getSingleInstance();
                uSDKErrorConst result = mgr.startSDK(context.getApplicationContext());
                if (result == uSDKErrorConst.RET_USDK_OK) {
                    subscriber.onNext(result);
                    subscriber.onCompleted();
                } else {
                    subscriber.onError(new SdkException(result));
                }
            }
        }).subscribeOn(Schedulers.newThread()).retry(new Func2<Integer, Throwable, Boolean>() {
            @Override
            public Boolean call(Integer count, Throwable throwable) {
                HaierLoger.d(TAG, "start usdk count = " + count);
                return count != 3;
            }
        }).onErrorReturn(new Func1<Throwable, uSDKErrorConst>() {
            @Override
            public uSDKErrorConst call(Throwable throwable) {
                return ((SdkException) throwable).getSDKError();
            }
        }).doOnNext(new Action1<uSDKErrorConst>() {
            @Override
            public void call(uSDKErrorConst errorConst) {
                HaierLoger.d(TAG, "start usdk result = " + errorConst.toString());
            }
        });
    }

    /**
     * 初始化统计SDK
     */
    private void initAnalytics(final Context context) {
        Observable.create(new Observable.OnSubscribe<Object>() {
            @Override
            public void call(Subscriber<? super Object> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                // 友盟的统计
                String channel = ChannelUtil.getChannel(context, "服务器");
                HaierLoger.d(TAG, "channel=" + channel);
                AnalyticsConfig.setChannel(channel);
                MobclickAgent.setDebugMode(BuildConfig.DEBUG);

                // 海尔的统计
                final String sdkVersion = uSDKManager.getSingleInstance().getuSDKVersion();
                MobEvent.setAutoLocation(context, true);
                MobEvent.bindUSDK(context, sdkVersion);
                MobEvent.setDefaultReportPolicy(context, PolicyConst.UANALYTICS_BATCH);
                MobEvent.onEvent(context, "e_app_start");
            }
        }).subscribeOn(Schedulers.io()).subscribe();
    }

    private void init() {
        // startSdk();
        // dbflow数据库初始化
        FlowManager.init(this);
        // 初始化统计库
        initAnalytics(this);

        HaierLoger.showLog(BuildConfig.DEBUG);

        mDataManager = DataManager.init(this);
        mRxFlux = RxFlux.init();
        mRxFlux.registerActivityLifecycleCallbacks(this);

        OauthPlatform.setWeixin("wxb368f746fab5e730", "0272158af4f8ae59702c3ec106875d51");
        // qq和qqzone都是调用setQQZone
        OauthPlatform.setQQZone("1105330535", "qlCVG3nA3Uh53fdE");
        OauthPlatform.setSinaWeibo("1623408796", "813828778e790f480601d80e079e869f");

        mUserActionCreator = new UserActionCreator(this, mDataManager, mRxFlux.getDispatcher(),
                mRxFlux.getSubscriptionManager());
        mDeviceActionCreator = new DeviceActionCreator(this, mDataManager, mRxFlux.getDispatcher(),
                mRxFlux.getSubscriptionManager());
        UpHybrid upHybrid = UpHybrid.getInstance(getApplicationContext());
    }

    public String getClientId() {
        String clientId = uSDKManager.getSingleInstance().getClientId(this);
        if (TextUtils.isEmpty(clientId)) {
            clientId = "haiergoodtaste" + new Random().nextInt(1000000);
        }
        return clientId;
    }
}