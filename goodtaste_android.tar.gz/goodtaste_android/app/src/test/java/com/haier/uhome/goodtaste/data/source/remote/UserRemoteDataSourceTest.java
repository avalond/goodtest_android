package com.haier.uhome.goodtaste.data.source.remote;


import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.LoginInfo;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.data.models.RewardInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.UserProfileType;
import com.haier.uhome.goodtaste.data.models.UserScore;
import com.haier.uhome.goodtaste.exception.BaseException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import rx.observers.TestSubscriber;

import static junit.framework.TestCase.assertEquals;

/**
 * Created by dallas on 16-4-26.
 */
public class UserRemoteDataSourceTest extends RemoteDataSourceTest {
    private UserRemoteDataSource mRemoteDataSource;

    @Before
    public void setUp() throws Exception {
        mRemoteDataSource = new UserRemoteDataSource(mode, okHttpClient);
    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testRegister() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        mRemoteDataSource.register("18602945459", "qwerty", "666666", "").toBlocking().subscribe(subscriber);

        // {"retCode":"JK_00003_22805","retInfo":"验证码错误或已失效","data":""}
        subscriber.assertError(BaseException.class);
        BaseException e = (BaseException) subscriber.getOnErrorEvents().get(0);
        assertEquals(e.getMessage(), "JK_00003_22805", e.getCode());
    }

    @Test
    public void testApplyRegMsgCode() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        mRemoteDataSource.applyRegMsgCode("18602945459").toBlocking().subscribe(subscriber);

        // {"retCode":"JK_00003_22803","retInfo":"[18602945459]已被占用！","data":""}
        subscriber.assertError(BaseException.class);
        BaseException e = (BaseException) subscriber.getOnErrorEvents().get(0);
        assertEquals(e.getMessage(), "JK_00003_22803", e.getCode());
    }

    @Test
    public void testLogin() throws Exception {
        TestSubscriber<LoginInfo> subscriber = new TestSubscriber<>();
        String pwd = "qwerty123!";
        if (mode != AbsRemoteDataSource.DEBUG) {
            pwd = "qwerty123";
        }
        mRemoteDataSource.login("18602945459", pwd).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        LoginInfo info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.getAccessToken());
        Assert.assertNotEquals(info.getAccessToken(), "");
    }

    @Test
    public void testGetDeviceGateWay() throws Exception {

    }


    @Test
    public void testFindUserInfoById() throws Exception {
        TestSubscriber<UserInfo> subscriber = new TestSubscriber<>();
        mRemoteDataSource.findUserInfoById(userId).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        UserInfo info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.getNickName());
    }

    @Test
    public void testUpdateUserProfile() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        mRemoteDataSource.updateUserInfoById(userId, UserProfileType.NIKE_NAME, "测试")
            .toBlocking()
            .subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        BaseResult info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.getRetCode());
        Assert.assertNotNull(info.getRetInfo());
        assertEquals(info.getRetInfo(), "00000", info.getRetCode());
    }

    @Test
    public void testSendMsgToUser() throws Exception {
        TestSubscriber<MessageInfo> subscriber = new TestSubscriber<>();
        String toUserId = "321";
        mRemoteDataSource.sendMsgToUser(userId, toUserId, "hello", "").toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        MessageInfo info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.getId());
    }

    @Test
    public void testGetUnReadPersonMsg() throws Exception {
        TestSubscriber<List<MessageInfo>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getUnReadPersonMsg(userId).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<MessageInfo> info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertTrue(info.size() >= 0);
    }

    @Test
    public void rewardUser() throws Exception {
        TestSubscriber<RewardInfo> subscriber = new TestSubscriber<>();
        String rewardUserId = "321";
        String rewardScore = "30";
        mRemoteDataSource.rewardUser(userId, rewardUserId, rewardScore).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        RewardInfo info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
    }

    @Test
    public void findUserPoint() throws Exception {
        TestSubscriber<UserScore> subscriber = new TestSubscriber<>();
        mRemoteDataSource.findUserPoint(userId).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        UserScore info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.getPoint());
    }
}