package com.haier.uhome.goodtaste.data.source.remote;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Protocol;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * <br>Created by dallas on 16-5-6.
 */
public class TestFakeInterceptor implements Interceptor {
    private static final String TAG = TestFakeInterceptor.class.getSimpleName();

    @Override
    public Response intercept(Chain chain) throws IOException {
        HttpUrl url = chain.request().url();
        String apiName = url.pathSegments().get(url.pathSize() - 1);
        String fakeResponseFile = "success_response.txt";
        switch (apiName) {
            case "login":
                fakeResponseFile = "login_response.txt";
                break;
            case "findUserInfoById":
                fakeResponseFile = "findUserInfoById_response.txt";
                break;
            case "sendMsgToUser":
                fakeResponseFile = "sendMsgToUser_response.txt";
                break;
            case "getUnReadPersonMsg":
                fakeResponseFile = "getUnReadPersonMsg_response.txt";
                break;
            case "findRecipeByKey":
                fakeResponseFile = "findRecipeByKey_response.txt";
                break;
            case "findRecipeInfoById":
                fakeResponseFile = "findRecipeInfoById_response.txt";
                break;
            case "findPubRecipeByUserId":
            case "findCollRecipeByUserId":
            case "findDraftRecipeByUserId":
                fakeResponseFile = "findPubRecipeByUserId_response.txt";
                break;
            case "findCommRecipeById":
                fakeResponseFile = "findCommRecipeById_response.txt";
                break;
            case "findMaterial":
                fakeResponseFile = "findMaterial_response.txt";
                break;
            case "createRecipe":
                fakeResponseFile = "createRecipe_response.txt";
                break;
            case "findRecipeHotKey":
                fakeResponseFile = "findRecipeHotKey_response.txt";
                break;
            case "findChefRank":
                fakeResponseFile = "findChefRank_response.txt";
                break;
            case "findFansByUserId":
                fakeResponseFile = "findFansByUserId_response.txt";
                break;
            case "findFansNumByUserId":
                fakeResponseFile = "findFansNumByUserId_response.txt";
                break;
            case "findFocusByUserId":
                fakeResponseFile = "findFocusByUserId_response.txt";
                break;
            case "findFocusNumByUserId":
                fakeResponseFile = "findFocusNumByUserId_response.txt";
                break;
            case "findUserPoint":
                fakeResponseFile = "findUserPoint_response.txt";
                break;
            case "getVideoList":
                fakeResponseFile = "getVideoList_response.txt";
                break;
            case "getTopVideo":
                fakeResponseFile = "getTopVideo_response.txt";
                break;
            case "findCommVideoById":
            case "findCommVideoByIdMore":
                fakeResponseFile = "findCommVideoById_response.txt";
                break;
            case "findInfoVideoById":
                fakeResponseFile = "findInfoVideoById_response.txt";
                break;
            default:
                break;
        }
        File file = new File("src/test/assets/" + fakeResponseFile);
        boolean exit = file.exists();
        InputStream stream = new FileInputStream(file);
        int len = stream.available();
        byte[] buff = new byte[len];
        stream.read(buff);

        ResponseBody responseBody = ResponseBody.create(MediaType.parse("application/json"), buff);
        return new Response.Builder().code(200)
            .request(chain.request())
            .protocol(Protocol.HTTP_1_0)
            .body(responseBody)
            .addHeader("content-type", "application/json")
            .build();
    }
}
