package com.haier.uhome.goodtaste.data.source.remote;

import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.CommentInfo;
import com.haier.uhome.goodtaste.data.models.HotKey;
import com.haier.uhome.goodtaste.data.models.Material;
import com.haier.uhome.goodtaste.data.models.RecipeData;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;
import com.haier.uhome.goodtaste.data.models.req.CreateRecipeReq;
import com.haier.uhome.goodtaste.data.models.req.CreateRecipeStepReq;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import rx.observers.TestSubscriber;

/**
 * Created by dallas on 16-5-7.
 */
public class RecipesRemoteDataSourceTest extends RemoteDataSourceTest {
    private RecipesRemoteDataSource mRemoteDataSource;

    @Before
    public void setUp() throws Exception {
        mRemoteDataSource = new RecipesRemoteDataSource(mode, okHttpClient);
    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testGetRecipeInfoList() throws Exception {
        TestSubscriber<List<RecipeWithUser>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getRecipeInfoList("11", 1, 1, 1, "").toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<RecipeWithUser> info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertTrue(info.size() == 2);
    }

    @Test
    public void testGetRecipeDetail() throws Exception {
        TestSubscriber<RecipeData> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getRecipeDetail("100").toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        RecipeData recipeData = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(recipeData);
        Assert.assertEquals("100", recipeData.getRecipeId());
    }

    @Test
    public void testGetUserPubRecipeList() throws Exception {
        TestSubscriber<List<RecipeData>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getUserPubRecipeList("11", "dddd", 1, 1).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<RecipeData> info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertTrue(info.size() == 2);
    }

    @Test
    public void testGetUserFavRecipeList() throws Exception {
        TestSubscriber<List<RecipeData>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getUserFavRecipeList("11", 1).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<RecipeData> info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertTrue(info.size() == 2);
    }

    @Test
    public void testGetUserDraftRecipeList() throws Exception {
        TestSubscriber<List<RecipeData>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getUserDraftRecipeList("11", 1).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<RecipeData> info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertTrue(info.size() == 2);
    }

    @Test
    public void testGetRecipeCommentList() throws Exception {
        TestSubscriber<List<CommentInfo>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getRecipeCommentList("11", 1).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<CommentInfo> info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertEquals(5, info.size());
    }

    @Test
    public void testGetMaterialList() throws Exception {
        TestSubscriber<List<Material>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getMaterialList(1).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<Material> info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertEquals(5, info.size());
    }

    @Test
    public void testCreateRecipe() throws Exception {
        TestSubscriber<String> subscriber = new TestSubscriber<>();
        CreateRecipeReq recipeReq = new CreateRecipeReq();
        mRemoteDataSource.createRecipe(recipeReq).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        String id = subscriber.getOnNextEvents().get(0);
        Assert.assertEquals("111111", id);
    }

    @Test
    public void testCreateRecipeStep() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        CreateRecipeStepReq req = new CreateRecipeStepReq();
        mRemoteDataSource.createRecipeStep(req).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        BaseResult result = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(result);
        Assert.assertEquals(result.getRetInfo(), BaseResult.RET_OK, result.getRetCode());
    }

    @Test
    public void testUploadRecipeStepPic() throws Exception {
        // ignore
    }

    @Test
    public void testGetRecipeHotKey() throws Exception {
        TestSubscriber<List<HotKey>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getRecipeHotKey().toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<HotKey> result = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(result);
        Assert.assertTrue(result.size() >= 0);
    }
}