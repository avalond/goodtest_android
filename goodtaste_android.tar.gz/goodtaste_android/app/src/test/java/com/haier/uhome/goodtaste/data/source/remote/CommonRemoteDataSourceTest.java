package com.haier.uhome.goodtaste.data.source.remote;


import com.haier.uhome.goodtaste.data.models.AppVersionResult;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.ResourceResult;
import com.haier.uhome.goodtaste.data.models.UvcResult;
import com.haier.uhome.goodtaste.data.models.Validate;
import com.haier.uhome.goodtaste.exception.BaseException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;

import rx.observers.TestSubscriber;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Created by dallas on 16-4-26.
 */
public class CommonRemoteDataSourceTest extends RemoteDataSourceTest {
    private CommonRemoteDataSource mRemoteDataSource;

    @Before
    public void setUp() throws Exception {
        mRemoteDataSource = new CommonRemoteDataSource(mode, okHttpClient);
    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testGetDeviceGateWay() throws Exception {

    }

    @Test
    public void testGetAppVersionInfo() throws Exception {
        TestSubscriber<AppVersionResult> subscriber = new TestSubscriber<>();

        mRemoteDataSource.getAppVersionInfo("MB-AIRCONDITION1-0001").toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        AppVersionResult info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertEquals(info.getRetCode(), BaseResult.RET_OK);
    }

    @Test
    public void testPostUvcMobile() throws Exception {
        TestSubscriber<UvcResult> subscriber = new TestSubscriber<>();
        mRemoteDataSource.postUvcMobile("18602945459", "18602945459", Validate.SCENE_ACTIVATION)
            .toBlocking()
            .subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        UvcResult result = subscriber.getOnNextEvents().get(0);
        assertNotNull(result);
        assertEquals(result.getRetInfo(), UvcResult.RET_OK, result.getRetCode());
        assertEquals(result.getTransactionId(), "");
    }

    @Test
    public void testPostUvcEmail() throws Exception {
        TestSubscriber<UvcResult> subscriber = new TestSubscriber<>();
        mRemoteDataSource.postUvcEmail("18602945459", "caobin@haierubic.com", Validate.SCENE_ACTIVATION)
            .toBlocking()
            .subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        UvcResult result = subscriber.getOnNextEvents().get(0);
        assertNotNull(result);
        assertEquals(result.getRetInfo(), UvcResult.RET_OK, result.getRetCode());
        assertEquals(result.getTransactionId(), "");
    }

    @Test
    public void testVerifyUvcMobile() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        mRemoteDataSource.verifyUvcMobile("ddddd", "18602945459", "", Validate.SCENE_ACTIVATION)
            .toBlocking()
            .subscribe(subscriber);

        // {"retCode":"22805","retInfo":"激活码错误，还有2次机会重试"}
        subscriber.assertError(BaseException.class);
        BaseException exception = (BaseException) subscriber.getOnErrorEvents().get(0);
        assertEquals(exception.getMessage(), "22805", exception.getCode());
    }

    @Test
    public void testVerifyUvcEmail() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        mRemoteDataSource.verifyUvcEmail("ddddd", "18602945459", "", Validate.SCENE_ACTIVATION)
            .toBlocking()
            .subscribe(subscriber);

        // {"retCode":"22821","retInfo":"用户UH3100287750无激活项"}
        subscriber.assertError(BaseException.class);
        BaseException exception = (BaseException) subscriber.getOnErrorEvents().get(0);
        assertEquals(exception.getMessage(), "22821", exception.getCode());
    }

    @Test
    public void testAssignResource() throws Exception {
        TestSubscriber<ResourceResult> subscriber = new TestSubscriber<>();
        mRemoteDataSource.assignResource("U", userId, "avatar", ".jpg", "123", "头像").toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        ResourceResult result = subscriber.getOnNextEvents().get(0);
        assertNotNull(result);
        assertEquals(result.getRetInfo(), ResourceResult.RET_OK, result.getRetCode());
        assertNotNull(result.getUri());
        assertNotEquals(result.getUri(), "");
    }

    @Test
    public void testUploadAvatar() throws Exception {
        File file = new File("src/test/test.jpg");
        TestSubscriber<String> subscriber = new TestSubscriber<>();
        mRemoteDataSource.uploadAvatar(userId, file).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        String result = subscriber.getOnNextEvents().get(0);
        assertNotNull(result);
        assertNotNull(result);
        assertNotEquals(result, "");
    }

    @Test
    public void logout() throws Exception {
        File file = new File("src/test/test.jpg");
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        mRemoteDataSource.logout().toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        BaseResult result = subscriber.getOnNextEvents().get(0);
        assertNotNull(result);
        assertEquals(result.getRetInfo(), "00000", result.getRetCode());
    }


}