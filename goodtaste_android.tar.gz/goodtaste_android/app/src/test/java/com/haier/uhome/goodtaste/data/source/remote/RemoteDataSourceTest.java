package com.haier.uhome.goodtaste.data.source.remote;


import com.haier.uhome.goodtaste.data.models.LoginInfo;

import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import rx.Scheduler;
import rx.android.plugins.RxAndroidPlugins;
import rx.android.plugins.RxAndroidSchedulersHook;
import rx.schedulers.Schedulers;

/**
 * Created by dallas on 16-4-21.
 */
public abstract class RemoteDataSourceTest {
    @Rule
    public final RxJavaPluginsResetRule pluginsReset = new RxJavaPluginsResetRule();

    @Rule
    public final LoginRule loginRule = new LoginRule();

    @AbsRemoteDataSource.EnvironmentMode
    protected int mode = AbsRemoteDataSource.DEBUG;

    Map<String, String> headers;
    String userId;
    OkHttpClient okHttpClient = createClient();


    protected OkHttpClient createClient() {
        headers = new HashMap<>();

        headers.put("appId", "MB-WZD-0000");
        headers.put("appVersion", "1.0.0");
        headers.put("clientId", "D90AFF95D16A5361244D854AF7B2A7AD");
        headers.put("appKey", "ae20e80702156ca45eb5ec66d4581e4a");

        return new OkHttpClient.Builder().addInterceptor(new AccessTokenInterceptor(headers))
//            .addInterceptor(new TestFakeInterceptor())
            .addInterceptor(new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
            .sslSocketFactory(HttpsTrustManager.getSsLSocketFactory())
            .hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            })
            .readTimeout(10, TimeUnit.SECONDS)
            .connectTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .build();
    }

    private void updateToken(String token, OkHttpClient httpClient) {
        for (Interceptor interceptor : httpClient.interceptors()) {
            if (interceptor instanceof AccessTokenInterceptor) {
                ((AccessTokenInterceptor) interceptor).updateToken(token);
                break;
            }
        }
    }

    private class LoginRule implements TestRule {

        @Override
        public Statement apply(final Statement base, Description description) {
            return new Statement() {
                @Override
                public void evaluate() throws Throwable {
                    if (!headers.containsKey("accessToken")) {
                        UserRemoteDataSource remoteDataSource = new UserRemoteDataSource(mode, okHttpClient);
                        String pwd = "qwerty123!";
                        if (mode != AbsRemoteDataSource.DEBUG) {
                            pwd = "qwerty123";
                        }
                        LoginInfo info = remoteDataSource.login("18602945459", pwd).toBlocking().first();
                        headers.put("accessToken", info.getAccessToken());
                        userId = info.getUserId();
                        updateToken(info.getAccessToken(), remoteDataSource.getHttpClient());
                    }
                    base.evaluate();
                }
            };
        }
    }


    private class RxJavaPluginsResetRule implements TestRule {

        @Override
        public Statement apply(final Statement base, Description description) {
            return new Statement() {
                @Override
                public void evaluate() throws Throwable {
                    //before: plugins reset, execution and schedulers hook defined
                    RxAndroidPlugins.getInstance().reset();
                    RxAndroidPlugins.getInstance().registerSchedulersHook(new RxAndroidSchedulersHook() {
                        @Override
                        public Scheduler getMainThreadScheduler() {
                            return Schedulers.io();
                        }
                    });

                    base.evaluate();

                    //after: clean up
                    RxAndroidPlugins.getInstance().reset();
                }
            };
        }
    }
}
