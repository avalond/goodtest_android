package com.haier.uhome.goodtaste.data.source;

import org.junit.Test;

/**
 * Created by dallas on 16-4-18.
 */
public class CommonRepositoryTest {

    @Test
    public void testRegister() throws Exception {

    }

    @Test
    public void testLogin() throws Exception {

    }

    @Test
    public void testLogout() throws Exception {

    }

    @Test
    public void testGetDeviceGateWay() throws Exception {

    }

    @Test
    public void testGetAppVersionInfo() throws Exception {

    }

    @Test
    public void testPostUserVerificationCode() throws Exception {

    }

    @Test
    public void testPostUvcMobile() throws Exception {

    }

    @Test
    public void testPostUvcEmail() throws Exception {

    }

    @Test
    public void testVerifyUserVerificationCode() throws Exception {

    }

    @Test
    public void testVerifyUvcMobile() throws Exception {

    }

    @Test
    public void testVerifyUvcEmail() throws Exception {

    }

    @Test
    public void testAssignResource() throws Exception {

    }

    @Test
    public void testUploadAvatar() throws Exception {

    }

    @Test
    public void testGetUserInfo() throws Exception {

    }

    @Test
    public void testGetUserInfo1() throws Exception {

    }

    @Test
    public void testUpdateUserProfile() throws Exception {

    }
}