package com.haier.uhome.goodtaste.data.source.remote;

import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.TopVideoInfo;
import com.haier.uhome.goodtaste.data.models.VideoCommentInfo;
import com.haier.uhome.goodtaste.data.models.VideoInfo;
import com.haier.uhome.goodtaste.data.models.req.VideoCommentReq;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import rx.observers.TestSubscriber;

/**
 * Created by dallas on 16-5-7.
 */
public class VideoRemoteDataSourceTest extends RemoteDataSourceTest {
    private VideoRemoteDataSource mRemoteDataSource;

    @Before
    public void setUp() throws Exception {
        mRemoteDataSource = new VideoRemoteDataSource(mode, okHttpClient);
    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testPostLike() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        mRemoteDataSource.postLike("dddd", "dddd").toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        BaseResult result = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(result);
        Assert.assertEquals(result.getRetInfo(), BaseResult.RET_OK, result.getRetCode());
    }

    @Test
    public void testCommentVideo() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        VideoCommentReq comment = new VideoCommentReq();
        mRemoteDataSource.commentVideo(comment).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        BaseResult result = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(result);
        Assert.assertEquals(result.getRetInfo(), BaseResult.RET_OK, result.getRetCode());
    }

    @Test
    public void testGetVideoList() throws Exception {
        TestSubscriber<List<VideoInfo>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getVideoList("dd", 1).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<VideoInfo> result = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(result);
        Assert.assertEquals(4, result.size());
    }

    @Test
    public void testGetTopVideo() throws Exception {
        TestSubscriber<List<TopVideoInfo>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getTopVideo("dd", "1111").toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<TopVideoInfo> result = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(result);
        Assert.assertEquals(4, result.size());
    }

    @Test
    public void testGetVideoComment() throws Exception {
        TestSubscriber<List<VideoCommentInfo>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getVideoComment("dd", "11", 10+"").toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<VideoCommentInfo> result = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(result);
        Assert.assertEquals(2, result.size());
    }

    @Test
    public void testGetMoreVideoComment() throws Exception {
        TestSubscriber<List<VideoCommentInfo>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getMoreVideoComment("dd", "11", 1).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<VideoCommentInfo> result = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(result);
        Assert.assertEquals(2, result.size());
    }

    @Test
    public void testGetVideoInfo() throws Exception {
        TestSubscriber<VideoInfo> subscriber = new TestSubscriber<>();
        mRemoteDataSource.getVideoInfo("dd").toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        VideoInfo result = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(result);
    }
}