package com.haier.uhome.goodtaste.data.source.remote;


import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.ChefInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import rx.observers.TestSubscriber;

import static junit.framework.TestCase.assertEquals;

/**
 * Created by dallas on 16-4-26.
 */
public class ChefRemoteDataSourceTest extends RemoteDataSourceTest {
    private ChefRemoteDataSource mRemoteDataSource;

    @Before
    public void setUp() throws Exception {
        mRemoteDataSource = new ChefRemoteDataSource(mode, okHttpClient);
    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testFindChefRank() throws Exception {
        TestSubscriber<List<ChefInfo>> subscriber = new TestSubscriber<>();
        mRemoteDataSource.findChefRank("1").toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<ChefInfo> info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.get(0));
        Assert.assertNotNull(info.get(0).getUserId());
    }

    @Test
    public void findFansByUserId() throws Exception {
        TestSubscriber<List<UserInfo>> subscriber = new TestSubscriber<>();
        String pageNum = "1";
        mRemoteDataSource.findFansByUserId(userId, pageNum).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<UserInfo> info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertTrue(info.size() >= 0);
    }

    @Test
    public void findFansNumByUserId() throws Exception {
        TestSubscriber<Integer> subscriber = new TestSubscriber<>();
        mRemoteDataSource.findFansNumByUserId(userId).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        Integer info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
    }

    @Test
    public void findFocusByUserId() throws Exception {
        TestSubscriber<List<UserInfo>> subscriber = new TestSubscriber<>();
        String pageNum = "1";
        mRemoteDataSource.findFocusByUserId(userId, pageNum).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        List<UserInfo> info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertTrue(info.size() >= 0);
    }

    @Test
    public void findFocusNumByUserId() throws Exception {
        TestSubscriber<Integer> subscriber = new TestSubscriber<>();
        mRemoteDataSource.findFocusNumByUserId(userId).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        Integer info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
    }

    @Test
    public void addPraise() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        String recipeId = "12121";
        mRemoteDataSource.addPraise(userId, recipeId).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        BaseResult info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.getRetCode());
        Assert.assertNotNull(info.getRetInfo());
        assertEquals(info.getRetInfo(), "00000", info.getRetCode());
    }

    @Test
    public void subscribe() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        String followedUserId = "1";
        mRemoteDataSource.subscribe(userId, followedUserId).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        BaseResult info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.getRetCode());
        Assert.assertNotNull(info.getRetInfo());
        assertEquals(info.getRetInfo(), "00000", info.getRetCode());
    }

    @Test
    public void unsubscribe() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        String followedUserId = "1";
        mRemoteDataSource.unsubscribe(userId, followedUserId).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        BaseResult info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.getRetCode());
        Assert.assertNotNull(info.getRetInfo());
        assertEquals(info.getRetInfo(), "00000", info.getRetCode());
    }

    @Test
    public void collectRecipe() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        String recipeId = "1";
        mRemoteDataSource.collectRecipe(userId, recipeId).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        BaseResult info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.getRetCode());
        Assert.assertNotNull(info.getRetInfo());
        assertEquals(info.getRetInfo(), "00000", info.getRetCode());
    }

    @Test
    public void uncollectRecipe() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        String recipeId = "1";
        mRemoteDataSource.uncollectRecipe(userId, recipeId).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        BaseResult info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.getRetCode());
        Assert.assertNotNull(info.getRetInfo());
        assertEquals(info.getRetInfo(), "00000", info.getRetCode());
    }

    @Test
    public void commentRecipe() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        String recipeId = "1";
        String content = "content";
        mRemoteDataSource.commentRecipe(userId, recipeId, content).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        BaseResult info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.getRetCode());
        Assert.assertNotNull(info.getRetInfo());
        assertEquals(info.getRetInfo(), "00000", info.getRetCode());
    }


    @Test
    public void delCommentRecipe() throws Exception {
        TestSubscriber<BaseResult> subscriber = new TestSubscriber<>();
        String id = "1";
        mRemoteDataSource.delCommentRecipe(id).toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        BaseResult info = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(info);
        Assert.assertNotNull(info.getRetCode());
        Assert.assertNotNull(info.getRetInfo());
        assertEquals(info.getRetInfo(), "00000", info.getRetCode());
    }

    @Test
    public void testIsSubscribe() throws Exception {
        TestSubscriber<Boolean> subscriber = new TestSubscriber<>();
        mRemoteDataSource.isSubscribe(userId, "111").toBlocking().subscribe(subscriber);
        subscriber.assertNoErrors();
        subscriber.assertCompleted();

        Boolean result = subscriber.getOnNextEvents().get(0);
        Assert.assertNotNull(result);
    }
}