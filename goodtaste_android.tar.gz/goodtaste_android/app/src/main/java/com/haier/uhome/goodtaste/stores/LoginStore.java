package com.haier.uhome.goodtaste.stores;

import android.content.Context;
import android.os.Bundle;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.actions.LoginActions;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.HaierPreference;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;

/**
 * Created by Administrator on 2016/5/13.
 */
public class LoginStore extends BaseStore {

    private static LoginStore instance;
    public static final String ID = "LoginStore";
    private String loginId;
    private String pwd;
    private Boolean savestatus;
    RxPreference preference;

    public synchronized static LoginStore get(Context context) {
        if (instance == null) {
            HaierApplication app = (HaierApplication) context.getApplicationContext();
            instance = new LoginStore(app.getRxFlux().getDispatcher());
        }
        return instance;
    }
    protected LoginStore(Dispatcher dispatcher) {
        super(dispatcher);
        preference = DataManager.instance().getPreference();
    }

    @Override
    protected void onAction(RxAction action) {
        switch (action.getType()) {
            case LoginActions.ID_LOGIN:
                Bundle data = (Bundle) action.getData();
                String loginId = data.getString("loginId");
                preference.put(HaierPreference.LOGINID, loginId);
                HaierLoger.a("KEY_TOKEN", preference.getString(HaierPreference.KEY_TOKEN, ""));
                HaierLoger.a("account2", loginId);
                break;
            case LoginActions.ID_LOGOUT:

                break;
            case LoginActions.ID_SAVE_PASSWORD:
                Bundle data1 = (Bundle) action.getData();
                String pwd = data1.getString("pwd");
                Boolean savestatus = data1.getBoolean("savestatus");
                preference.put(HaierPreference.SAVESTATUS, savestatus);
                if (savestatus) {
                    preference.put(HaierPreference.PASSWORD, pwd);
                } else {
                    preference.put(HaierPreference.PASSWORD, "");
                }
                HaierLoger.a("account3", pwd);
                break;

            default:
                return;
        }
        postStoreChange(new RxStoreChange(ID, action));

    }

    public String getloginId() {
        loginId = preference.getString(HaierPreference.LOGINID, "");
        HaierLoger.a("account1", loginId);
        return loginId;
    }

    public String getPassword() {
        pwd = preference.getString(HaierPreference.PASSWORD, "");
        HaierLoger.a("account4", pwd);
        return pwd;
    }

    public Boolean getSavestatus() {
        savestatus = preference.getBoolean(HaierPreference.SAVESTATUS, true);
        HaierLoger.a("account4", savestatus);
        return savestatus;
    }
}
