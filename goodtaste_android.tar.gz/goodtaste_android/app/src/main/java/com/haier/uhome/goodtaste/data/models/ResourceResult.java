package com.haier.uhome.goodtaste.data.models;

public class ResourceResult extends BaseResult {
    private static final long serialVersionUID = 271540115182901017L;
    /**
     * 资源编号
     */
    String resId;
    /**
     * 资源地址
     */
    String uri;
    /**
     * 文件最大大小(Byte),-1为无限制
     */
    long quota;

    public String getResId() {
        return resId;
    }

    public void setResId(String resId) {
        this.resId = resId;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public long getQuota() {
        return quota;
    }

    public void setQuota(long quota) {
        this.quota = quota;
    }
}