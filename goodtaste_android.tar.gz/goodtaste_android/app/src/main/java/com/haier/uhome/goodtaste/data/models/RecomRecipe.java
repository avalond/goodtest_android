package com.haier.uhome.goodtaste.data.models;

import com.haier.uhome.goodtaste.data.source.local.GoodTasteDataBase;
import com.raizlabs.android.dbflow.annotation.ModelContainer;
import com.raizlabs.android.dbflow.annotation.Table;

/**
 * 推荐菜谱
 * Created by dallas on 16-5-11.
 */
@ModelContainer
@Table(database = GoodTasteDataBase.class, allFields = true)
public class RecomRecipe extends RecipeWithUser {
    private static final long serialVersionUID = 1013579776760199671L;
}
