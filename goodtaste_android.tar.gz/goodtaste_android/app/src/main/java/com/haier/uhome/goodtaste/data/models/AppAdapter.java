package com.haier.uhome.goodtaste.data.models;

import java.io.Serializable;

public class AppAdapter implements Serializable {
    private static final long serialVersionUID = 6272279370532539833L;
    /**
     * 接入网关id
     */
    private String id;
    /**
     * 接入网关名称
     */
    private String name;
    /**
     * 接入地址
     */
    private String uri;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }
}
