package com.haier.uhome.goodtaste.actions;

import android.content.Context;
import android.text.TextUtils;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.util.SubscriptionManager;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.VideoCommentInfo;
import com.haier.uhome.goodtaste.data.models.VideoInfo;
import com.haier.uhome.goodtaste.data.models.req.VideoCommentReq;
import com.haier.uhome.goodtaste.data.source.VideoDataSource;
import com.haier.uhome.goodtaste.exception.BaseException;

import java.util.List;

import rx.Subscriber;
import rx.Subscription;

/**
 * Created by Administrator on 2016/5/6.
 */

public class VideoCommentActionsCreator extends BaseActionCreator implements VideoCommentActions {

    public VideoCommentActionsCreator(Context context, DataManager dataManager, Dispatcher dispatcher,
        SubscriptionManager subscriptionManager) {
        super(context, dataManager, dispatcher, subscriptionManager);
    }

    //获取首页5条评论
    @Override
    public void videoComment(String userId, String videoId, String size) {
        final RxAction action = newRxAction(ID_FIVE_MESSAGE, null);
        if (hasRxAction(action)) {
            return;
        }
        VideoDataSource repository = mDataManager.getVideoRepository();
        Subscription subscription = repository.getVideoComment(videoId, userId, size).
            subscribe(new Subscriber<List<VideoCommentInfo>>() {
                @Override
                public void onCompleted() {

                }

                @Override
                public void onError(Throwable e) {
                    postError(action, e);
                }

                @Override
                public void onNext(List<VideoCommentInfo> videoCommentInfos) {
                    RxAction<List<VideoCommentInfo>> resultAction = newRxAction(ID_FIVE_MESSAGE, videoCommentInfos);
                    postRxAction(resultAction);
                }
            });
        addRxAction(action, subscription);
    }

    @Override
    public void send(String message, String userId, String videoId) {
        final RxAction action = newRxAction(ID_SEND, null);
        if (hasRxAction(action)) {
            return;
        }
    }

    @Override
    public void videoMoreComment(String userId, String videoId) {

    }

    @Override
    public void postLike(String userId, String videoId) {
        final RxAction action = newRxAction(ID_LIKE, null);
        if (hasRxAction(action)) {
            return;
        }
        if (TextUtils.isEmpty(videoId)) {
            postError(action, new BaseException("videoId失效了"));
        }

        VideoDataSource repository = mDataManager.getVideoRepository();
        Subscription subscribe = repository.postLike(userId, videoId).subscribe(new Subscriber<BaseResult>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(BaseResult baseResult) {
                RxAction<BaseResult> resultRxAction = newRxAction(ID_LIKE, baseResult);
                postRxAction(resultRxAction);
            }
        });
        addRxAction(action, subscribe);
    }

    //视频评论
    @Override
    public void commentVideo(VideoCommentReq comment) {
        final RxAction action = newRxAction(ID_COMMENT_VIDEO, null);
        if (hasRxAction(action)) {
            return;
        }
        VideoDataSource repository = mDataManager.getVideoRepository();
        Subscription subscribe = repository.commentVideo(comment).subscribe(new Subscriber<BaseResult>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(BaseResult baseResult) {
                RxAction<BaseResult> resultRxAction = newRxAction(ID_COMMENT_VIDEO, baseResult);
                postRxAction(resultRxAction);
            }
        });
        addRxAction(action, subscribe);
    }

    //获取相关视频
    @Override
    public void videoListByAlbumId(String albumId) {
        final RxAction action = newRxAction(ID_VIDEO_LIST_BY_ALBUMID, null);
        if (hasRxAction(action)) {
            return;
        }
        if (TextUtils.isEmpty(albumId)) {
            postError(action, new BaseException("albumId是空"));
        }
        VideoDataSource repository = mDataManager.getVideoRepository();
        Subscription subscribe = repository.getVideoListByAlbumId(albumId).subscribe(new Subscriber<List<VideoInfo>>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                postError(action, new BaseException("albumId是空"));
            }

            @Override
            public void onNext(List<VideoInfo> videoInfos) {
                RxAction<List<VideoInfo>> videoInfoAction = newRxAction(ID_VIDEO_LIST_BY_ALBUMID, videoInfos);
                postRxAction(videoInfoAction);
            }
        });
        addRxAction(action, subscribe);
    }

    //删除视频
    @Override
    public void deleteVideoComment(String videoId, String userId ) {
        final RxAction action = newRxAction(ID_DELE_VIDEO_ITEM, null);
        if (hasRxAction(action)) {
            return;
        }
        if (TextUtils.isEmpty(userId)) {
            postError(action, new BaseException("用户Id失效"));
        }
        VideoDataSource repository = mDataManager.getVideoRepository();
        Subscription subscribe = repository.deleteVideoComment("评论ID", videoId, userId)
            .subscribe(new Subscriber<BaseResult>() {
                @Override
                public void onCompleted() {

                }

                @Override
                public void onError(Throwable e) {
                    postError(action, e);
                }

                @Override
                public void onNext(BaseResult baseResult) {
                    RxAction<BaseResult> deleteVideoItem = newRxAction(ID_DELE_VIDEO_ITEM, baseResult);
                    postRxAction(deleteVideoItem);
                }
            });
        addRxAction(action, subscribe);
    }

    //获取视频信息
    @Override
    public void videoInfo(String videoId) {
        final RxAction action = newRxAction(ID_VIDEO_INFO, null);
        if (hasRxAction(action)) {
            return;
        }
        if (TextUtils.isEmpty(videoId)) {
            postError(action, new BaseException("服务器迷路了"));
        }
        VideoDataSource repository = mDataManager.getVideoRepository();
        Subscription subscribe = repository.getVideoInfo(videoId).subscribe(new Subscriber<VideoInfo>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(VideoInfo videoInfo) {
                RxAction<VideoInfo> videoInfoAction = newRxAction(ID_VIDEO_INFO, videoInfo);
                postRxAction(videoInfoAction);
            }
        });
        addRxAction(action, subscribe);
    }

    //根据视频ID获取视频评论列表
    @Override
    public void moreVideoComment(String videoId, String userId, int pageNum) {
        final RxAction action = newRxAction(ID_MORE_VIDEO_COMMENT, null);
        if (hasRxAction(action)) {
            return;
        }
        if (TextUtils.isEmpty(videoId)) {
            postError(action, new BaseException("服务器迷路了"));
        }
        VideoDataSource repository = mDataManager.getVideoRepository();
        Subscription subscribe = repository.getMoreVideoComment(videoId, userId, pageNum).
            subscribe(new Subscriber<List<VideoCommentInfo>>() {
                @Override
                public void onCompleted() {

                }

                @Override
                public void onError(Throwable e) {
                    postError(action, e);
                }

                @Override
                public void onNext(List<VideoCommentInfo> videoCommentInfos) {
                    RxAction<List<VideoCommentInfo>> listRxAction = newRxAction(ID_MORE_VIDEO_COMMENT,
                        videoCommentInfos);
                    postRxAction(listRxAction);
                }
            });
        addRxAction(action, subscribe);
    }
}