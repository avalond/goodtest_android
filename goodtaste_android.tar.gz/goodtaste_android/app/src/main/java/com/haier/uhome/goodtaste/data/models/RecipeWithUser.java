package com.haier.uhome.goodtaste.data.models;

import com.haier.uhome.goodtaste.data.source.local.GoodTasteDataBase;

import com.raizlabs.android.dbflow.annotation.ForeignKey;

import com.raizlabs.android.dbflow.annotation.ModelContainer;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.io.Serializable;

/**
 * 包含用户信息的菜谱
 * Created by dallas on 16-5-7.
 */
@ModelContainer
@Table(database = GoodTasteDataBase.class, allFields = true)
public class RecipeWithUser extends BaseModel implements Serializable {
    private static final long serialVersionUID = 6643447868584633274L;

    @PrimaryKey
    private String id;

    private String updateTime;

    @ForeignKey(saveForeignKeyModel = true)
    private UserInfo userInfo;

    @ForeignKey(saveForeignKeyModel = true)
    private RecipeData recipeInfo;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public UserInfo getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }

    public RecipeData getRecipeInfo() {
        return recipeInfo;
    }

    public void setRecipeInfo(RecipeData recipeData) {
        this.recipeInfo = recipeData;
    }

}
