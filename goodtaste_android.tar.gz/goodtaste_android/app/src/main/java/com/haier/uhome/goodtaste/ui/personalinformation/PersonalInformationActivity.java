package com.haier.uhome.goodtaste.ui.personalinformation;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.gmail.adffice.rxflux.RxFlux;
import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.actions.LoginActionCreator;
import com.haier.uhome.goodtaste.actions.LoginActions;
import com.haier.uhome.goodtaste.actions.UserActionCreator;
import com.haier.uhome.goodtaste.actions.UserActions;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.UserProfileType;
import com.haier.uhome.goodtaste.stores.BaseStore;
import com.haier.uhome.goodtaste.stores.PersonalInformationStore;
import com.haier.uhome.goodtaste.stores.UserStore;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.ui.login.LoginActivity;
import com.haier.uhome.goodtaste.utils.BitmapUtil;
import com.haier.uhome.goodtaste.utils.DateUtil;
import com.haier.uhome.goodtaste.utils.ErrorHandler;
import com.haier.uhome.goodtaste.utils.ImageDownLoader;
import com.haier.uhome.goodtaste.widgets.pickerview.TimePickerView;
import com.haier.uhome.goodtaste.widgets.roundedimageview.RoundedImageView;

import java.io.File;
import java.util.Date;

import butterknife.Bind;
import butterknife.OnClick;
import pl.aprilapps.easyphotopicker.DefaultCallback;
import pl.aprilapps.easyphotopicker.EasyImage;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;


/**
 * Created by Administrator on 2016/5/4.
 */
public class PersonalInformationActivity extends BaseActivity {

    @Bind(R.id.tv_nickname)
    TextView nickName;
    @Bind(R.id.tv_gender)
    TextView tvGender;
    @Bind(R.id.iv_gender)
    ImageView ivGender;
    @Bind(R.id.tv_home_now)
    TextView tvHome;
    @Bind(R.id.tv_introduction_my)
    TextView tvIntroduction;
    @Bind(R.id.tv_emil)
    TextView tvEmil;
    @Bind(R.id.tv_telephone)
    TextView tvTelephone;
    //@Bind(R.id.tv_passworld_user)
    //TextView tvPassword;
    @Bind(R.id.iv_user_icon)
    RoundedImageView userIcon;
    //@Bind(R.id.ll_photo)
    //LinearLayout ll;
    @Bind(R.id.tv_birthday)
    TextView tvBirthday;

    private UserStore mUserStore;
    //修改个人信息的type  1 修改昵称2 修改性别 3 修改城市 4修改简介5修改邮箱6修改电话7修改生日
    private final int nicknameId = UserProfileType.NIKE_NAME;
    private final int genderId = UserProfileType.SEX;
    private final int addressId = UserProfileType.CITY;
    private final int introductionId = UserProfileType.ABOUT;
    private final int emilId = UserProfileType.EMAIL;
    private final int phoneId = UserProfileType.PHONE;
    private final int birthdayId = UserProfileType.BIRTHDAY;
    private String userId;
    private LoginActionCreator mLoginActionCreator;
    private RxFlux mRxFlux;
    private DataManager mDataManager;
    private Boolean isBack = false;
    private UserActionCreator mUserActionCreator;
    private UserInfo userInfo;
    public static final int RESULT_CODE_INFORMATION = 1001;
    private PersonalInformationStore mPersonalInformationStore;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_information);
        showToolbar();
        showProgressDialog(getString(R.string.information_loading));
        setToolbarTitle(getString(R.string.personal_information));
        userInfo = mUserStore.getUserInfo();
        userId = mUserStore.getUserId();
        if (userInfo != null) {
            ImageDownLoader.get(this).display(userInfo.getAvater(), R.drawable.head_default_icon, userIcon);
            ImageDownLoader.get(this).display(userInfo.getAvater(),
                    R.drawable.head_default_icon, userIcon);
            nickName.setText(userInfo.getNickName());
            tvGender.setText(userInfo.getGender());
            showGenderImage(userInfo.getGender());
            tvHome.setText(userInfo.getAddress());
            tvIntroduction.setText(userInfo.getIntroduction());
            tvEmil.setText(userInfo.getEmail());
            tvTelephone.setText(userInfo.getPhone());
            tvBirthday.setText(userInfo.getBirthday());
            stopProgressDialog();
        }

        mRxFlux = getApp().getRxFlux();
        mDataManager = getApp().getDataManager();
        mLoginActionCreator = new LoginActionCreator(this, mDataManager, mRxFlux.getDispatcher(),
                mRxFlux.getSubscriptionManager());
        mUserActionCreator = getApp().getUserActionCreator();
        mUserActionCreator.getUserInfo(mUserStore.getUserId());
        initBirthdayTime();
    }

    //
    @Override
    protected void onResume() {
        super.onResume();
        //UserActionCreator mUserActionCreator = getApp().getUserActionCreator();
        //mUserActionCreator.getUserInfo(mUserStore.getUserId());
    }

    private void showGenderImage(String gender) {

        if ("1".equals(gender)) {
            tvGender.setText(getString(R.string.information_man));
            ivGender.setImageResource(R.drawable.icon_man);
        } else if ("0".equals(gender)) {
            tvGender.setText(getString(R.string.information_women));
            ivGender.setImageResource(R.drawable.icon_woman);
        }

    }

    /**
     * 初始化选择生日的界面
     */
    private void initBirthdayTime() {

        pvTime = new TimePickerView(this, TimePickerView.Type.YEAR_MONTH_DAY);
        //控制时间范围
        //Calendar calendar = Calendar.getInstance();
        //pvTime.setRange(calendar.get(Calendar.YEAR) - 20, calendar.get(Calendar.YEAR));
        pvTime.setTime(new Date());
        pvTime.setCyclic(true);
        pvTime.setCancelable(true);
        pvTime.setTitle(getString(R.string.information_birthday));
        //时间选择后回调
        pvTime.setOnTimeSelectListener(new TimePickerView.OnTimeSelectListener() {

            @Override
            public void onTimeSelect(Date date) {
                String birthday = DateUtil.getFormatDateTime(date).substring(0, 9);
                mUserActionCreator.updateUserProfile(userId, birthdayId, birthday);

                if (isUpdataSuccess) {
                    tvBirthday.setText(birthday);
                    showToast(getString(R.string.updata_success));
                } else {
                    isUpdataSuccess = true;
                    showToast(getString(R.string.updata_faile));
                }

                //tvUpdata.setTextColor(Color.BLACK);
            }
        });

    }

    @Override
    protected View createToolbarView(LayoutInflater inflater, ViewGroup container) {

        View view = super.createToolbarView(inflater, container);
        //TextView mLeftBack = (TextView) view.findViewById(R.id.toolbar_left_btn);
        TextView mRightBtn = (TextView) view.findViewById(R.id.toolbar_right_btn);
        mRightBtn.setVisibility(View.INVISIBLE);
        //mRightBtn.setBackgroundColor();
        //mRightBtn.setCompoundDrawables(null, null, null, null);
        //mRightBtn.setText(getString(R.string.information_exit));
        return view;
    }

    private int photo = 0;

    @OnClick(R.id.rl_user_icon)
    protected void gotUpdataIcon() {

        // 使用不带theme的构造器，获得的dialog边框距离屏幕仍有几毫米的缝隙。
        // Dialog dialog = new Dialog(getActivity());
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // must be called before set content
        View v = View.inflate(this, R.layout.dialog_person_informention, null);
        dialog.setContentView(v);
        TextView tvspeace = (TextView) v.findViewById(R.id.tv_speace);
        TextView tvdismiss = (TextView) v.findViewById(R.id.tv_dismiss);
        TextView photograph = (TextView) v.findViewById(R.id.tv_photograph);
        TextView photoAlbums = (TextView) v.findViewById(R.id.tv_photo_albums);
        LinearLayout ll = (LinearLayout) v.findViewById(R.id.ll_photo);
        photograph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                photo = 1;
                EasyImage.openCamera(PersonalInformationActivity.this, photo);

            }
        });
        tvdismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        photoAlbums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                photo = 2;
                EasyImage.openGallery(PersonalInformationActivity.this, photo);
                dialog.dismiss();
            }
        });
        //tvspeace.setBackgroundColor(Color.TRANSPARENT);
        dialog.setCanceledOnTouchOutside(false);

        // 设置宽度为屏宽、靠近屏幕底部。
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.BOTTOM;
        wlp.width = WindowManager.LayoutParams.MATCH_PARENT;
        window.setAttributes(wlp);
        dialog.show();

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        EasyImage.handleActivityResult(requestCode, resultCode, data, this, new DefaultCallback() {
            @Override
            public void onImagePicked(File file, EasyImage.ImageSource imageSource, int i) {
                onPhotoReturned(file);
            }

        });

    }

    @OnClick(R.id.rl_nickname)
    protected void updataNickName() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(PersonalInformationActivity.this);
        View view = getLayoutInflater().inflate(R.layout.dialog_information_nickname, null);
        TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
        final EditText etMessage = (EditText) view.findViewById(R.id.tv_message);
        final ImageView ivDelete = (ImageView) view.findViewById(R.id.iv_delete);
        TextView btnDelete = (TextView) view.findViewById(R.id.btn_delete);
        TextView notDelete = (TextView) view.findViewById(R.id.btn_not_delete);
        tvTitle.setText(getString(R.string.information_nickname));
        //tvMessage.setText("确定要删除此菜谱?");
        etMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ivDelete.setVisibility(View.VISIBLE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etMessage.setText("");
                ivDelete.setVisibility(View.GONE);
            }
        });
        btnDelete.setText(getString(R.string.information_cancle));
        notDelete.setText(getString(R.string.information_determine));
        builder.setView(view);
        final AlertDialog create = builder.create();
        create.setCanceledOnTouchOutside(false);
        WindowManager.LayoutParams lp = create.getWindow().getAttributes();
        lp.alpha = 1.0f;
        create.getWindow().setAttributes(lp);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                create.dismiss();
                ivDelete.setVisibility(View.GONE);
            }
        });
        notDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String etNickname = etMessage.getText().toString().trim();
                if (!TextUtils.isEmpty(etNickname)) {

                    if (etNickname.length() > 10){
                        showToast(getString(R.string.nick_name_maxsum));
                        return;
                    }

                    mUserActionCreator.updateUserProfile(userId, nicknameId, etNickname);
                    if (isUpdataSuccess) {
                        nickName.setText(etNickname);
                        showToast(getString(R.string.updata_success));
                    } else {
                        isUpdataSuccess = true;
                        showToast(getString(R.string.updata_faile));
                    }

                    create.cancel();
                    //tvUpdata.setTextColor(Color.BLACK);
                } else {

                    showToast(R.string.information_enter_nickname);
                }
            }
        });

        create.show();

    }

    private TimePickerView pvTime;

    @OnClick(R.id.rl_birthday)
    protected void updataBirthday() {
        //弹出时间选择器

        pvTime.show();

    }

    @OnClick(R.id.rl_sex)
    protected void updataSex() {

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // must be called before set content
        View v = View.inflate(this, R.layout.dialog_person_informention, null);
        dialog.setContentView(v);
        TextView tvspeace = (TextView) v.findViewById(R.id.tv_speace);
        TextView tvdismiss = (TextView) v.findViewById(R.id.tv_dismiss);
        TextView tvWoman = (TextView) v.findViewById(R.id.tv_photograph);
        TextView tvMan = (TextView) v.findViewById(R.id.tv_photo_albums);
        final String genderMan = getString(R.string.information_man);
        final String genderWomen = getString(R.string.information_women);
        tvMan.setText(getString(R.string.information_man));
        tvWoman.setText(R.string.information_women);
        tvMan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mUserActionCreator.updateUserProfile(userId, genderId, "1");

                if (isUpdataSuccess) {
                    ivGender.setImageResource(R.drawable.icon_man);
                    tvGender.setText(getString(R.string.information_man));
                    showToast(getString(R.string.updata_success));
                } else {
                    isUpdataSuccess = true;
                    showToast(getString(R.string.updata_faile));
                }

                dialog.dismiss();
                //tvUpdata.setTextColor(Color.BLACK);
            }
        });
        tvdismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        tvWoman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mUserActionCreator.updateUserProfile(userId, genderId, "0");

                if (isUpdataSuccess) {
                    ivGender.setImageResource(R.drawable.icon_woman);
                    tvGender.setText(R.string.information_women);
                    showToast(getString(R.string.updata_success));
                } else {
                    isUpdataSuccess = true;
                    showToast(getString(R.string.updata_faile));
                }

                dialog.dismiss();
                //tvUpdata.setTextColor(Color.BLACK);

            }
        });
        //tvspeace.setBackgroundColor(Color.TRANSPARENT);
        dialog.setCanceledOnTouchOutside(false);

        // 设置宽度为屏宽、靠近屏幕底部。
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.BOTTOM;
        wlp.width = WindowManager.LayoutParams.MATCH_PARENT;
        window.setAttributes(wlp);
        dialog.show();

    }

    @OnClick(R.id.rl_home)
    protected void updataHome() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(PersonalInformationActivity.this);
        View view = getLayoutInflater().inflate(R.layout.dialog_information_nickname, null);
        TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
        final EditText etMessage = (EditText) view.findViewById(R.id.tv_message);
        final ImageView ivDelete = (ImageView) view.findViewById(R.id.iv_delete);
        TextView btnDelete = (TextView) view.findViewById(R.id.btn_delete);
        TextView notDelete = (TextView) view.findViewById(R.id.btn_not_delete);
        tvTitle.setText(getString(R.string.information_address));
        //tvMessage.setText("确定要删除此菜谱?");
        etMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ivDelete.setVisibility(View.VISIBLE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etMessage.setText("");
                ivDelete.setVisibility(View.GONE);
            }
        });
        btnDelete.setText(getString(R.string.information_cancle));
        notDelete.setText(getString(R.string.information_determine));
        builder.setView(view);
        final AlertDialog create = builder.create();
        create.setCanceledOnTouchOutside(false);
        WindowManager.LayoutParams lp = create.getWindow().getAttributes();
        lp.alpha = 1.0f;
        create.getWindow().setAttributes(lp);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                create.dismiss();
                ivDelete.setVisibility(View.GONE);
            }
        });
        notDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String etHome = etMessage.getText().toString().trim();
                if (!TextUtils.isEmpty(etHome)) {
                    if (etHome.length() > 30){
                        showToast(getString(R.string.address_maxsum));
                        return;
                    }
                    mUserActionCreator.updateUserProfile(userId, addressId, etHome);

                    if (isUpdataSuccess) {
                        tvHome.setText(etHome);
                        showToast(getString(R.string.updata_success));

                    } else {
                        isUpdataSuccess = true;
                        showToast(getString(R.string.updata_faile));
                    }

                    create.cancel();
                    //tvUpdata.setTextColor(Color.BLACK);
                } else {
                    showToast(getString(R.string.information_write_address));
                }

            }
        });

        create.show();

    }

    @OnClick(R.id.rl_introduction)
    protected void updataIntroduction() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(PersonalInformationActivity.this);
        View view = getLayoutInflater().inflate(R.layout.dialog_information_nickname, null);
        TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
        final EditText etMessage = (EditText) view.findViewById(R.id.tv_message);
        final ImageView ivDelete = (ImageView) view.findViewById(R.id.iv_delete);
        TextView btnDelete = (TextView) view.findViewById(R.id.btn_delete);
        TextView notDelete = (TextView) view.findViewById(R.id.btn_not_delete);
        tvTitle.setText(getString(R.string.information_introduction));
        //tvMessage.setText("确定要删除此菜谱?");
        etMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ivDelete.setVisibility(View.VISIBLE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etMessage.setText("");
                ivDelete.setVisibility(View.GONE);
            }
        });
        btnDelete.setText(getString(R.string.information_cancle));
        notDelete.setText(getString(R.string.information_determine));
        builder.setView(view);
        final AlertDialog create = builder.create();
        create.setCanceledOnTouchOutside(false);
        WindowManager.LayoutParams lp = create.getWindow().getAttributes();
        lp.alpha = 1.0f;
        create.getWindow().setAttributes(lp);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                create.dismiss();
                ivDelete.setVisibility(View.GONE);
            }
        });
        notDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String etIntroduction = etMessage.getText().toString().trim();
                if (!TextUtils.isEmpty(etIntroduction)) {
                    if (etIntroduction.length() > 30){
                        showToast(getString(R.string.introduction_maxsum));
                        return;
                    }

                    mUserActionCreator.updateUserProfile(userId, introductionId, etIntroduction);

                    if (isUpdataSuccess) {
                        tvIntroduction.setText(etIntroduction);
                        showToast(getString(R.string.updata_success));
                    } else {
                        isUpdataSuccess = true;
                        showToast(getString(R.string.updata_faile));
                    }

                    create.cancel();
                    //tvUpdata.setTextColor(Color.BLACK);
                } else {
                    showToast(getString(R.string.information_write_introduction));
                }

            }
        });

        create.show();

    }

    @OnClick(R.id.rl_emil)
    protected void updataEmil() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(PersonalInformationActivity.this);
        View view = getLayoutInflater().inflate(R.layout.dialog_information_nickname, null);
        TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
        final EditText etMessage = (EditText) view.findViewById(R.id.tv_message);
        final ImageView ivDelete = (ImageView) view.findViewById(R.id.iv_delete);
        TextView btnDelete = (TextView) view.findViewById(R.id.btn_delete);
        TextView notDelete = (TextView) view.findViewById(R.id.btn_not_delete);
        tvTitle.setText(getString(R.string.information_emil));
        //tvMessage.setText("确定要删除此菜谱?");
        etMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ivDelete.setVisibility(View.VISIBLE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etMessage.setText("");
                ivDelete.setVisibility(View.GONE);
            }
        });
        btnDelete.setText(getString(R.string.information_cancle));
        notDelete.setText(getString(R.string.information_determine));
        builder.setView(view);
        final AlertDialog create = builder.create();
        create.setCanceledOnTouchOutside(false);
        WindowManager.LayoutParams lp = create.getWindow().getAttributes();
        lp.alpha = 1.0f;
        create.getWindow().setAttributes(lp);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                create.dismiss();
                ivDelete.setVisibility(View.GONE);
            }
        });
        notDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String evEmil = etMessage.getText().toString().trim();
                if (!TextUtils.isEmpty(evEmil)) {
                    mUserActionCreator.updateUserProfile(userId, emilId, evEmil);

                    if (isUpdataSuccess) {
                        tvEmil.setText(evEmil);
                        showToast(getString(R.string.updata_success));
                    } else {
                        isUpdataSuccess = true;
                        showToast(getString(R.string.updata_faile));
                    }

                    create.cancel();
                    //tvUpdata.setTextColor(Color.BLACK);
                } else {
                    showToast(getString(R.string.information_write_emil));
                }

            }
        });

        create.show();

    }

    @OnClick(R.id.rl_telephone)
    protected void updataTelephone() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(PersonalInformationActivity.this);
        View view = getLayoutInflater().inflate(R.layout.dialog_information_nickname, null);
        TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
        final EditText etMessage = (EditText) view.findViewById(R.id.tv_message);
        final ImageView ivDelete = (ImageView) view.findViewById(R.id.iv_delete);
        TextView btnDelete = (TextView) view.findViewById(R.id.btn_delete);
        TextView notDelete = (TextView) view.findViewById(R.id.btn_not_delete);
        tvTitle.setText(getString(R.string.information_phone_number));
        //tvMessage.setText("确定要删除此菜谱?");
        etMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ivDelete.setVisibility(View.VISIBLE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etMessage.setText("");
                ivDelete.setVisibility(View.GONE);
            }
        });
        btnDelete.setText(getString(R.string.information_cancle));
        notDelete.setText(getString(R.string.information_determine));
        builder.setView(view);
        final AlertDialog create = builder.create();
        create.setCanceledOnTouchOutside(false);
        WindowManager.LayoutParams lp = create.getWindow().getAttributes();
        lp.alpha = 1.0f;
        create.getWindow().setAttributes(lp);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                create.dismiss();
                ivDelete.setVisibility(View.GONE);
            }
        });
        notDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String etTelephone = etMessage.getText().toString().trim();
                if (!TextUtils.isEmpty(etTelephone)) {
                    mUserActionCreator.updateUserProfile(userId, phoneId, etTelephone);

                    if (isUpdataSuccess) {
                        tvTelephone.setText(etTelephone);
                        showToast(getString(R.string.updata_success));
                    } else {
                        isUpdataSuccess = true;
                        showToast(getString(R.string.updata_faile));
                    }

                    create.cancel();
                    //tvUpdata.setTextColor(Color.BLACK);
                } else {
                    showToast(getString(R.string.information_write_phone_number));
                }

            }
        });

        create.show();

    }

    /* @OnClick(R.id.rl_password)
     protected void updataPassword(){

         final AlertDialog.Builder builder = new AlertDialog.Builder(PersonalInformationActivity.this);
         View view = getLayoutInflater().inflate(R.layout.dialog_information_nickname, null);
         TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
         final EditText etMessage = (EditText) view.findViewById(R.id.tv_message);
         final ImageView ivDelete = (ImageView) view.findViewById(R.id.iv_delete);
         TextView btnDelete = (TextView) view.findViewById(R.id.btn_delete);
         TextView notDelete = (TextView) view.findViewById(R.id.btn_not_delete);
         tvTitle.setText("密码");
         //tvMessage.setText("确定要删除此菜谱?");
         etMessage.addTextChangedListener(new TextWatcher() {
             @Override
             public void beforeTextChanged(CharSequence s, int start, int count, int after) {

             }

             @Override
             public void onTextChanged(CharSequence s, int start, int before, int count) {
                 ivDelete.setVisibility(View.VISIBLE);
             }

             @Override
             public void afterTextChanged(Editable s) {

             }
         });
         ivDelete.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 etMessage.setText("");
                 ivDelete.setVisibility(View.GONE);
             }
         });
         btnDelete.setText("取消");
         notDelete.setText("完成");
         builder.setView(view);
         final AlertDialog create = builder.create();
         create.setCanceledOnTouchOutside(false);
         WindowManager.LayoutParams lp = create.getWindow().getAttributes();
         lp.alpha = 1.0f;
         create.getWindow().setAttributes(lp);
         btnDelete.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 create.dismiss();

             }
         });
         notDelete.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String etPassword = etMessage.getText().toString().trim();
                 if (!TextUtils.isEmpty(etPassword)) {
                     tvPassword.setText(etPassword);
                     create.cancel();
                     tvUpdata.setTextColor(Color.BLACK);
                 }else{
                     showToast("请输入修改后的密码");
                 }

             }
         });

         create.show();

     }
 */


    //退出登录
    @OnClick(R.id.tv_exit)
    protected void outGoLoagin(){
        if (!TextUtils.isEmpty(mUserStore.getAccessToken())) {
            final android.app.AlertDialog.Builder myBuilder = new android.app.AlertDialog.Builder(this);
            View view = getLayoutInflater().inflate(R.layout.activity_collection_dialog, null);
            TextView title = (TextView) view.findViewById(R.id.tv_title);
            TextView message = (TextView) view.findViewById(R.id.tv_message);
            TextView no = (TextView) view.findViewById(R.id.btn_ok);
            TextView yes = (TextView) view.findViewById(R.id.btn_cancel);

            title.setText(getString(R.string.message_dialog_title));
            message.setText(getString(R.string.message_dialog_outlogin_message));
            yes.setText(getString(R.string.information_determine));
            no.setText(getString(R.string.information_cancle));

            myBuilder.setView(view);
            final android.app.AlertDialog create = myBuilder.create();
            yes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showProgressDialog(getString(R.string.back_login));
                    mLoginActionCreator.logout();
                    create.dismiss();
                    isBack = true;
                }
            });
            no.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    create.cancel();
                }
            });
            create.show();

        }
    }

    @Override
    public void onRxStoresRegister() {
        mUserStore = UserStore.get(this);
        mUserStore.register();
        //mPersonalInformationStore = new PersonalInformationStore(getApp().getRxFlux().getDispatcher(), this);
        mPersonalInformationStore = PersonalInformationStore.get(this);
        mPersonalInformationStore.register();

    }

    @Override
    public void onRxStoresUnRegister() {
        mUserStore.unregister();

    }

    //判断是否保存成功
    private boolean isUpdataSuccess = true;

    @Override
    public void onRxStoreChanged(RxStoreChange change) {

        switch (change.getStoreId()) {
            case BaseStore.ID_SHOW_LOADING:
                /*if (isBack) {
                    showProgressDialog(getString(R.string.back_login));
                }*/
                isBack = false;
                break;
            case BaseStore.ID_STOP_LOADING:
                stopProgressDialog();
                break;
            case UserStore.ID:
                switch (change.getRxAction().getType()) {
                    case LoginActions.ID_LOGOUT:
                        if (mUserStore.isLogoutSuccess()) {
                            Toast.makeText(this, getString(R.string.outlogin), Toast.LENGTH_LONG).show();
                            startActivity(new Intent(this,MineActivity.class));
                            finish();
                        }
                        break;
                    case UserActions.ID_GET_USER_INFO:
                        userInfo = (UserInfo) change.getRxAction().getData();
                        if (userInfo != null) {
                            stopProgressDialog();
                            ImageDownLoader.get(this)
                                    .display(userInfo.getAvater(), R.drawable.head_default_icon, userIcon);
                            ImageDownLoader.get(this).display(userInfo.getAvater(),
                                    R.drawable.head_default_icon, userIcon);
                            nickName.setText(userInfo.getNickName());
                            tvGender.setText(userInfo.getGender());
                            showGenderImage(userInfo.getGender());
                            tvHome.setText(userInfo.getAddress());
                            tvIntroduction.setText(userInfo.getIntroduction());
                            tvEmil.setText(userInfo.getEmail());
                            tvTelephone.setText(userInfo.getPhone());
                            tvBirthday.setText(userInfo.getBirthday());
                        }

                        break;
                    case UserActions.ID_UPDATE_USER_PROFILE:
                        //isUpdataSuccess = false;
                        setResult(RESULT_CODE_INFORMATION);
                        break;
                    case UserActions.ID_UPLOAD_AVATAR:
                        //String imageUrl = (String) change.getRxAction().getData();
                        //userInfo.setAvater(imageUrl);
                        setResult(RESULT_CODE_INFORMATION);
                    default:
                        break;
                }
            default:
                break;
        }

    }

    @Override
    public void onRxError(RxError error) {
        isUpdataSuccess = false;
        showToast(ErrorHandler.handelError(error.getThrowable(), this));
    }

    private Observable<Bitmap> resizeBitmap(final File imageFile, final int destWidth, final int destHeight) {
        return Observable.create(new Observable.OnSubscribe<Bitmap>() {
            @Override
            public void call(Subscriber<? super Bitmap> subscriber) {
                try {
                    Bitmap temp = BitmapUtil.decodeBitmap(imageFile, destWidth, destHeight);

                    subscriber.onNext(temp);
                    subscriber.onCompleted();
                } catch (Exception e) {
                    e.printStackTrace();
                    subscriber.onError(e);
                }
            }
        }).subscribeOn(Schedulers.io());
    }

    private void onPhotoReturned(File photoFile) {
        // 调整图片大小后，显示头像。
        resizeBitmap(photoFile, 300, 300).subscribeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Bitmap>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                    }

                    @Override
                    public void onNext(Bitmap bitmap) {
                        userIcon.setImageBitmap(bitmap);
                    }
                });
        // 上传头像
        // TODO: 16-5-17 这里调用上传头像接口
        mUserActionCreator.uploadAvatar(mUserStore.getUserId(), photoFile);


    }
}
