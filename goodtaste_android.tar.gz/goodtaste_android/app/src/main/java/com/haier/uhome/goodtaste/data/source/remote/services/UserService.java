package com.haier.uhome.goodtaste.data.source.remote.services;

import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.data.models.BaseEntity;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.data.models.RewardInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.UserScore;

import java.util.List;

import retrofit2.http.Body;
import retrofit2.http.POST;
import rx.Observable;

/**
 * 用户
 * <br>Created by Dallas.
 */
public interface UserService {
    String DEBUG_BASE_URL = "http://" + BaseService.DEBUG_HOST + ":7480/";
    String DEBUG_VERIFY_BASE_URL = "http://" + BaseService.DEBUG_VERIFY_HOST + ":7480/";
    String PRE_PRODUCT_BASE_RUL = "http://" + BaseService.PRE_PRODUCT_HOST + ":7480/";
    String PRODUCT_BASE_RUL = "http://" + BaseService.PRODUCT_HOST + ":7480/";

    @POST("foodStreetData/recipe/user/register")
    Observable<BaseResult> register(@Body JsonObject req);

    @POST("foodStreetData/recipe/user/applyRegMsgCode")
    Observable<BaseResult> postUvcForRegister(@Body JsonObject req);

    @POST("foodStreetData/recipe/user/findUserInfoById")
    Observable<BaseEntity<UserInfo>> findUserInfoById(@Body JsonObject req);

    @POST("foodStreetData/recipe/user/updateUserInfoById")
    Observable<BaseResult> updateUserInfoById(@Body JsonObject req);

    @POST("foodStreetData/recipe/user/sendMsgToUser")
    Observable<BaseEntity<MessageInfo>> sendMsgToUser(@Body JsonObject req);

    @POST("foodStreetData/recipe/user/getUnReadPersonMsg")
    Observable<BaseEntity<List<MessageInfo>>> getUnReadPersonMsg(@Body JsonObject req);

    @POST("foodStreetData/recipe/user/changePersonMsg")
    Observable<BaseResult> updateMsgStatus(@Body JsonObject req);

    @POST("foodStreetData/recipe/user/findUserPoint")
    Observable<BaseEntity<UserScore>> findUserPoint(@Body JsonObject req);

    @POST("foodStreetData/recipe/user/rewardUser")
    Observable<BaseEntity<RewardInfo>> rewardUser(@Body JsonObject req);
}
