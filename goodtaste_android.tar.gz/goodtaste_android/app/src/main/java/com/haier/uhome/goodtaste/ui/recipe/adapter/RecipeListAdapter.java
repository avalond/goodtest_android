package com.haier.uhome.goodtaste.ui.recipe.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;
import com.haier.uhome.goodtaste.ui.main.HandleHomeDishInterface;
import com.haier.uhome.goodtaste.utils.ImageDownLoader;

import java.util.List;

/**
 * Created by sharp on 16-5-14.
 */
public class RecipeListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final String TAG = "RecipeListAdapter";
    private List<RecipeWithUser> mRecipeDataList;
    private Activity mActivity;
    private LayoutInflater mLayoutInflater;
    private HandleHomeDishInterface mHandleHomeDishInterface;

    public RecipeListAdapter(Activity context, List<RecipeWithUser> recipeDataList,
        HandleHomeDishInterface handleHomeDishInterface) {
        mActivity = context;
        mLayoutInflater = LayoutInflater.from(mActivity);
        mRecipeDataList = recipeDataList;
        mHandleHomeDishInterface = handleHomeDishInterface;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        View view = mLayoutInflater.inflate(R.layout.item_activity_recipe_list_layout, parent, false);
        viewHolder = new DishListHolder(view, mActivity);
        return viewHolder;
    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof DishListHolder) {
            DishListHolder dishListHolder = (DishListHolder) holder;

            refreshRecipeItem(position, dishListHolder);
            //            dishListHolder.dishName.setText(mRecipeDataList.get(position).getUserInfo().getNickName());
        }
    }

    @Override
    public int getItemCount() {
        return mRecipeDataList.size();
    }

    public void setmRecipeDataList(List<RecipeWithUser> mRecipeDataList) {
        this.mRecipeDataList.clear();
        this.mRecipeDataList = mRecipeDataList;
        notifyDataSetChanged();
    }

    public void addmRecipeDataList(List<RecipeWithUser> recipeWithUserList) {
        this.mRecipeDataList.addAll(recipeWithUserList);
        notifyDataSetChanged();
    }


    private void refreshRecipeItem(final int pos, final DishListHolder dishListHolder) {
        if (mRecipeDataList == null || mRecipeDataList.size() < 1) {
            return;
        }
        final RecipeWithUser mRecipeWithUser = mRecipeDataList.get(pos);
        if (mRecipeWithUser == null) {
            return;
        }

        //菜谱相关
        String dishNameStr = "";
        String cuisineNameStr = "";
        String levelNameStr = "";
        String duringNameStr = "";
        int praiseNumNameStr = 0;
        String goodDishImageUrl = "";
        String recipeId = "";
        String title = null;

        if (mRecipeWithUser.getRecipeInfo() != null) {
            dishNameStr = mRecipeWithUser.getRecipeInfo().getTitle();
            cuisineNameStr = mRecipeWithUser.getRecipeInfo().getCuisine();
            levelNameStr = mRecipeWithUser.getRecipeInfo().getLevel();
            duringNameStr = mRecipeWithUser.getRecipeInfo().getDuring();
            if (mRecipeWithUser.getRecipeInfo().getFavoriteNumber() != null) {
                praiseNumNameStr = Integer.parseInt(mRecipeWithUser.getRecipeInfo().getFavoriteNumber());
            } else {
                praiseNumNameStr = 0;
            }
            goodDishImageUrl = mRecipeWithUser.getRecipeInfo().getPic();
            recipeId = mRecipeWithUser.getRecipeInfo().getRecipeId();
            title = mRecipeWithUser.getRecipeInfo().getTitle();
        }

        dishListHolder.dishName.setText(dishNameStr);

        dishListHolder.cuisineName.setText(cuisineNameStr);

        dishListHolder.levelName.setText(levelNameStr);

        dishListHolder.duringName.setText(duringNameStr);

        dishListHolder.praiseNumName.setText(praiseNumNameStr+"");

        ImageDownLoader.get(mActivity)
            .display(goodDishImageUrl, R.drawable.bg_defalt_recepe, dishListHolder.goodDishImage);

        //菜谱详情
        if (!TextUtils.isEmpty(recipeId)) {
            final String finalRecipeId = recipeId;
            final String finalTitle = title;
            dishListHolder.goodDishImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //    Toast.makeText(mActivity, pos + "菜谱pic id"
                    // + finalRecipeId, Toast.LENGTH_SHORT).show();
                    //需要回调接口 调取打开菜谱详情页
                    mHandleHomeDishInterface.onDishMainPage(finalRecipeId, finalTitle);
                }
            });
        }

        //用户相关
        String cookerNameStr = "";
        String dishCookerImageUrl = "";
        String cookerUserId = "";

        if (mRecipeWithUser.getUserInfo() != null) {
            cookerNameStr = mRecipeWithUser.getUserInfo().getNickName();
            dishCookerImageUrl = mRecipeWithUser.getUserInfo().getAvater();
            cookerUserId = mRecipeWithUser.getUserInfo().getUserId();
        }

        dishListHolder.cookerName.setText(cookerNameStr);

        ImageDownLoader.get(mActivity)
            .display(dishCookerImageUrl, R.drawable.test_pic_user, dishListHolder.dishCookerImage);

        final String finalCookerUserId = cookerUserId;
        //点赞
        dishListHolder.dishPraiseImage.setImageResource(R.drawable.btn_to_like);

        final int praise = praiseNumNameStr;
        final boolean isPraise = mRecipeWithUser.getRecipeInfo().getIsPraise();

        dishListHolder.dishPraiseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isPraise && !TextUtils.isEmpty(finalCookerUserId)) {
                    mRecipeWithUser.getRecipeInfo().setIsPraise(true);
                    dishListHolder.dishPraiseImage.setImageResource(R.drawable.btn_liked);
                    dishListHolder.praiseNumName.setText((praise + 1) + "");

                    //                Toast.makeText(mActivity, pos + "点赞user Id"
                    // + finalCookerUserId, Toast.LENGTH_SHORT).show();
                    //需要回调接口 调取点赞接口
                    mHandleHomeDishInterface.onDishPraise(finalCookerUserId);
                }
            }
        });

        //打开厨咖主页
        dishListHolder.dishCookerImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //                Toast.makeText(mActivity, pos + "头像user Id"
                // + finalCookerUserId1, Toast.LENGTH_SHORT).show();
                //需要回调接口 菜谱详情页
                mHandleHomeDishInterface.onDishCookerPage(finalCookerUserId);
            }
        });
    }

    /**
     * 推荐菜谱列表的ViewHolder
     */
    class DishListHolder extends RecyclerView.ViewHolder {

        Activity mActivity;
        //菜谱名，口味，时间，难易，点赞数，厨咖昵称
        TextView dishName;
        TextView cuisineName;
        TextView levelName;
        TextView duringName;
        TextView praiseNumName;
        TextView cookerName;

        //菜谱图，点赞图标，用户头像
        ImageView goodDishImage;
        ImageView dishPraiseImage;
        ImageView dishCookerImage;

        public DishListHolder(View itemView, final Activity activity) {
            super(itemView);
            mActivity = activity;
            dishName = (TextView) itemView.findViewById(R.id.tv_item_dish_name);
            cuisineName = (TextView) itemView.findViewById(R.id.tv_dish_tip_cuisine);
            levelName = (TextView) itemView.findViewById(R.id.tv_dish_tip_level);
            duringName = (TextView) itemView.findViewById(R.id.tv_dish_tip_during);
            praiseNumName = (TextView) itemView.findViewById(R.id.tv_dish_praise_num);
            cookerName = (TextView) itemView.findViewById(R.id.tv_dish_cooker_name);

            goodDishImage = (ImageView) itemView.findViewById(R.id.iv_good_dish_pic);
            dishPraiseImage = (ImageView) itemView.findViewById(R.id.iv_dish_praise_pic);
            dishCookerImage = (ImageView) itemView.findViewById(R.id.iv_dish_cooker_pic);

        }
    }
}
