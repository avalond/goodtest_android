package com.haier.uhome.goodtaste.data.models;

import com.haier.uhome.goodtaste.data.source.local.GoodTasteDataBase;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.io.Serializable;

/**
 * Created by lijin on 16-5-6.
 */
@Table(database = GoodTasteDataBase.class, allFields = true)
public class UserInfo extends BaseModel implements Serializable {
    private static final long serialVersionUID = -8948578279869350432L;


    /**
     * id : 6
     * userId : 100013957366161889
     * loginId :
     * score : 1600
     * nickName : 雪姑娘爱大雪天
     * honorScore : 1000
     * level :
     * levelName :
     * fansNumber : 0
     * followsNumber : 0
     * userType : 2
     * avater : http://uhome.haier.net:4869/edf832c0a7588df3dd1d47771c798d3d
     * gender : 0
     * address :
     * introduction :
     * email :
     * phone : 18818207136
     * birthday : 1993/11/06
     * time : 2015-11-17 16:47:04
     * inviteCode : 2Zgj4XK
     * inviteNumber : 0
     */
    @PrimaryKey
    private String userId = "";

    private String id = "";
    private String loginId = "";
    private String score;
    private String nickName = "";
    private String honorScore;
    private String level;
    private String levelName;
    private String fansNumber;
    private String followsNumber;
    private String userType;
    private String avater = "";
    private String gender;
    private String address;
    private String introduction;
    private String email;
    private String phone;
    private String birthday;
    private String time;
    private String inviteCode;
    private String inviteNumber;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getHonorScore() {
        return honorScore;
    }

    public void setHonorScore(String honorScore) {
        this.honorScore = honorScore;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getLevelName() {
        return levelName;
    }

    public void setLevelName(String levelName) {
        this.levelName = levelName;
    }

    public String getFansNumber() {
        return fansNumber;
    }

    public void setFansNumber(String fansNumber) {
        this.fansNumber = fansNumber;
    }

    public String getFollowsNumber() {
        return followsNumber;
    }

    public void setFollowsNumber(String followsNumber) {
        this.followsNumber = followsNumber;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getAvater() {
        return avater;
    }

    public void setAvater(String avater) {
        this.avater = avater;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getInviteCode() {
        return inviteCode;
    }

    public void setInviteCode(String inviteCode) {
        this.inviteCode = inviteCode;
    }

    public String getInviteNumber() {
        return inviteNumber;
    }

    public void setInviteNumber(String inviteNumber) {
        this.inviteNumber = inviteNumber;
    }
}
