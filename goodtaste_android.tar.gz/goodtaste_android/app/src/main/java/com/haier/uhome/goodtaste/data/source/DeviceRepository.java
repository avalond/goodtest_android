package com.haier.uhome.goodtaste.data.source;

import android.content.Context;

/**
 * Created by lijin on 16-5-7.
 */
public class DeviceRepository implements DeviceDataSource {
    private final DeviceDataSource mLocalDataSource;
    private final DeviceDataSource mRemoteDataSource;
    private final Context mContext;

    public DeviceRepository(Context context, DeviceDataSource localDataSource, DeviceDataSource remoteDataSource) {
        mContext = context;
        mLocalDataSource = localDataSource;
        mRemoteDataSource = remoteDataSource;
    }
}
