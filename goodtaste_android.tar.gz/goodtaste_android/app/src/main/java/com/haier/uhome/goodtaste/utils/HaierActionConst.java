package com.haier.uhome.goodtaste.utils;

/**
 * Created by dallas on 16-5-19.
 */
public class HaierActionConst {
    /**
     * 隐式跳转登录页Action，AndroidManifest.xml中引用
     */
    public static final String GOTO_LOGIN_ACTION = "com.haier.uhome.goodtaste.ACTION.login";
}
