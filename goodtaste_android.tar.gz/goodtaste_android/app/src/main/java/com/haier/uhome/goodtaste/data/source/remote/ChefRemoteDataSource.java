package com.haier.uhome.goodtaste.data.source.remote;

import android.support.annotation.NonNull;

import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.data.models.BaseEntity;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.ChefInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.source.ChefDataSource;
import com.haier.uhome.goodtaste.data.source.remote.services.ChefService;

import java.util.List;

import okhttp3.OkHttpClient;
import rx.Observable;
import rx.functions.Func1;

import static com.haier.uhome.goodtaste.utils.Preconditions.checkNotNull;

/**
 * Created by lijin on 16-5-7.
 */
public class ChefRemoteDataSource extends AbsRemoteDataSource implements ChefDataSource {
    private final ChefService mChefService;

    public ChefRemoteDataSource(@EnvironmentMode int mode, @NonNull OkHttpClient httpClient) {
        super(mode, httpClient);
        switch (mode) {
            case DEBUG:
                mChefService = createService(ChefService.DEBUG_BASE_URL, ChefService.class);
                break;
            case DEBUG_VERIFY:
                mChefService = createService(ChefService.DEBUG_VERIFY_BASE_URL, ChefService.class);
                break;
            case PRE_PRODUCT:
                mChefService = createService(ChefService.PRE_PRODUCT_BASE_RUL, ChefService.class);
                break;
            case PRODUCT:
            default:
                mChefService = createService(ChefService.PRODUCT_BASE_RUL, ChefService.class);
                break;
        }
    }

    @Override
    public Observable<List<ChefInfo>> findChefRank(String pageNum) {
        checkNotNull(pageNum);

        JsonObject req = new JsonObject();
        req.addProperty("loginId", pageNum);

        return mChefService.findChefRank(req)
            .compose(this.<BaseEntity<List<ChefInfo>>, List<ChefInfo>>getTransformer2());
    }

    @Override
    public Observable<List<UserInfo>> findFansByUserId(String userId, String pageNum) {
        checkNotNull(userId);
        checkNotNull(pageNum);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("pageNum", pageNum);

        return mChefService.findFansByUserId(req)
            .compose(this.<BaseEntity<List<UserInfo>>, List<UserInfo>>getTransformer2());
    }

    @Override
    public Observable<Integer> findFansNumByUserId(String userId) {
        checkNotNull(userId);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);

        return mChefService.findFansNumByUserId(req)
            .compose(this.<BaseEntity<JsonObject>, JsonObject>getTransformer2())
            .map(new Func1<JsonObject, Integer>() {
                @Override
                public Integer call(JsonObject object) {
                    int result = 0;
                    if (object != null && object.has("fansNumber")) {
                        try {
                            String num = object.get("fansNumber").getAsString();
                            result = Integer.parseInt(num);
                        } catch (Exception e) {
                            // ignore
                        }
                    }
                    return result;
                }
            });
    }

    @Override
    public Observable<List<UserInfo>> findFocusByUserId(String userId, String pageNum) {
        checkNotNull(userId);
        checkNotNull(pageNum);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("pageNum", pageNum);

        return mChefService.findFocusByUserId(req)
            .compose(this.<BaseEntity<List<UserInfo>>, List<UserInfo>>getTransformer2());
    }

    @Override
    public Observable<Integer> findFocusNumByUserId(String userId) {
        checkNotNull(userId);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);

        return mChefService.findFocusNumByUserId(req)
            .compose(this.<BaseEntity<JsonObject>, JsonObject>getTransformer2())
            .map(new Func1<JsonObject, Integer>() {
                @Override
                public Integer call(JsonObject object) {
                    int result = 0;
                    if (object != null && object.has("focusNumber")) {
                        String num = object.get("focusNumber").getAsString();
                        try {
                            result = Integer.parseInt(num);
                        } catch (NumberFormatException e) {
                            // ignore
                        }
                    }
                    return result;
                }
            });
    }

    @Override
    public Observable<BaseResult> addPraise(String userId, String recipeId) {
        checkNotNull(userId);
        checkNotNull(recipeId);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("recipeId", recipeId);

        return mChefService.addPraise(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<BaseResult> subscribe(String userId, String followedUserId) {
        checkNotNull(userId);
        checkNotNull(followedUserId);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("followedUserId", followedUserId);

        return mChefService.subscribe(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<BaseResult> unsubscribe(String userId, String followedUserId) {
        checkNotNull(userId);
        checkNotNull(followedUserId);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("followedUserId", followedUserId);

        return mChefService.unsubscribe(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<Boolean> isSubscribe(String userId, String targetUserId) {
        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("followedUserId", targetUserId);

        return mChefService.isSubscribe(req)
            .compose(this.<BaseEntity<JsonObject>, JsonObject>getTransformer2())
            .map(new Func1<JsonObject, Boolean>() {
                @Override
                public Boolean call(JsonObject object) {
                    return object != null && object.has("issubscribe") &&
                        "Y".equals(object.get("issubscribe").getAsString());
                }
            });
    }

    @Override
    public Observable<BaseResult> collectRecipe(String userId, String recipeId) {
        checkNotNull(userId);
        checkNotNull(recipeId);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("recipeId", recipeId);

        return mChefService.collectRecipe(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<BaseResult> uncollectRecipe(String userId, String recipeId) {
        checkNotNull(userId);
        checkNotNull(recipeId);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("recipeId", recipeId);

        return mChefService.uncollectRecipe(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<BaseResult> commentRecipe(String userId, String recipeId, String content) {
        checkNotNull(userId);
        checkNotNull(recipeId);
        checkNotNull(content);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("recipeId", recipeId);
        req.addProperty("content", content);

        return mChefService.commentRecipe(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<BaseResult> delCommentRecipe(String id) {
        checkNotNull(id);

        JsonObject req = new JsonObject();
        req.addProperty("id", id);
        return mChefService.delCommentRecipe(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<List<ChefInfo>> saveChefRank(List<ChefInfo> chefList) {
        return Observable.empty();
    }
}
