package com.haier.uhome.goodtaste.actions;

/**
 * Created by Administrator on 2016/5/6.
 */
public interface MessageActions {

    String SEND_MESSAGE = "send_message";
    String GET_UNREAD_MESSAGE_CURRENT = "get_unread_message_current";
    //调用接口判断发送成功还是发送失败
    String SEND_MESSAGE_SUCCESS = "send_message_success";
    String SEND_MESSAGE_ERRO = "send_message_erro";
    String RECEIVE_MESSAGE = "receive_message";

    //发送消息
    void send(String fromUserId, String toUserId, String msg , String nickname , String avter);

    //接收消息
    String receive();

    //发送成功
    void sendSuccess();

    //发送失败
    void sendErro();

}
