package com.haier.uhome.goodtaste.data.source;

import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.ChefInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;

import java.util.List;

import rx.Observable;

/**
 * Created by lijin on 16-5-6.
 * <p>
 * 主厨数据源
 */
public interface ChefDataSource {

    /**
     * 首页获取主厨排名数据(返回结果集按照排名返回)
     *
     * @param pageNum 分页查询数据
     * @return
     */
    Observable<List<ChefInfo>> findChefRank(String pageNum);

    /**
     * 根据用户ID查询粉丝列表(返回条数，服务端控制)
     *
     * @param userId  用户ID
     * @param pageNum 分页查询数据
     * @return
     */
    Observable<List<UserInfo>> findFansByUserId(String userId, String pageNum);

    /**
     * 根据用户ID查询粉丝数
     *
     * @param userId 用户ID
     * @return
     */
    Observable<Integer> findFansNumByUserId(String userId);

    /**
     * 根据用户ID查询此用户关注列表
     *
     * @param userId  用户ID
     * @param pageNum 分页查询数据
     * @return
     */
    Observable<List<UserInfo>> findFocusByUserId(String userId, String pageNum);

    /**
     * 根据用户ID查询此用户关注数
     *
     * @param userId 用户ID
     * @return
     */
    Observable<Integer> findFocusNumByUserId(String userId);

    /**
     * 点赞给某个菜谱 （需要增加消息提醒功能）
     *
     * @param userId   用户ID
     * @param recipeId 菜谱ID
     * @return
     */
    Observable<BaseResult> addPraise(String userId, String recipeId);

    /**
     * 关注某人
     *
     * @param userId         用户ID
     * @param followedUserId 关注用户ID
     * @return
     */
    Observable<BaseResult> subscribe(String userId, String followedUserId);

    /**
     * 取消关注某人
     *
     * @param userId         用户ID
     * @param followedUserId 关注用户ID
     * @return
     */
    Observable<BaseResult> unsubscribe(String userId, String followedUserId);

    /**
     * 当前用户是否关注某用户
     *
     * @param userId       用户ID
     * @param targetUserId 目标用户ID
     * @return 是否关注
     */
    Observable<Boolean> isSubscribe(String userId, String targetUserId);

    /**
     * 收藏某个菜谱
     *
     * @param userId   用户ID
     * @param recipeId 菜谱ID
     * @return
     */
    Observable<BaseResult> collectRecipe(String userId, String recipeId);

    /**
     * 取消收藏
     *
     * @param userId   用户ID
     * @param recipeId 菜谱ID
     * @return
     */
    Observable<BaseResult> uncollectRecipe(String userId, String recipeId);

    /**
     * 评论某个菜谱
     *
     * @param userId   用户ID
     * @param recipeId 菜谱ID
     * @param content  评论内容
     * @return
     */
    Observable<BaseResult> commentRecipe(String userId, String recipeId, String content);

    /**
     * 删除某个菜谱评论
     *
     * @param id 评论ID
     * @return
     */
    Observable<BaseResult> delCommentRecipe(String id);

    /**
     * 保存首页获取主厨数据
     *
     * @param chefList 主厨排名数据
     * @return Observable
     */
    Observable<List<ChefInfo>> saveChefRank(List<ChefInfo> chefList);
}
