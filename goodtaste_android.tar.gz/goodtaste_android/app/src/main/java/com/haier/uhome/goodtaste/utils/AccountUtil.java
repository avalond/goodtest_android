package com.haier.uhome.goodtaste.utils;


import com.haier.uhome.goodtaste.data.models.LoginType;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 账号相关工具类
 * <br>Created by Dallas on 2016/2/15.
 */
public class AccountUtil {
    /**
     * 判断是否为电话号码
     */
    public static boolean isMobileNum(String account) {
        Pattern p = Pattern.compile("^((13[0-9])|(15[0-9])|(18[0-9])|(17[0-9])|(14[0-9]))\\d{8}$");
        Matcher m = p.matcher(account);
        return m.matches();
    }

    // 邮箱合法判断
    public static boolean isEmail(String email) {
        String str = "^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)" +
                "|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$";
        Pattern p = Pattern.compile(str);
        Matcher m = p.matcher(email);
        return m.matches();
    }

    /**
     * 获取登录类型
     *
     * @param account 登录账号
     * @return 用户类型 {@link LoginType}
     */
    @LoginType.Type
    public static int getLoginType(String account) {
        if ((account.length() == 11) && isMobileNum(account)) {
            return LoginType.MOBILE;
        } else if (isEmail(account)) {
            return LoginType.EMAIL;
        }
        return LoginType.USER_NAME;
    }

    /**
     * 验证码规范
     */
    public static boolean getVerify(String verify) {
        if ((verify.length() == 6)) {
            try {
                int num = Integer.valueOf(verify);//把字符串强制转换为数字
                return true;//如果是数字，返回True
            } catch (Exception e) {
                return false;//如果抛出异常，返回False
            }
        } else {
            return false;
        }
    }

    /*
    判断字符串是否全为数字或者字母
     */
    public static boolean isLetterDigit(String str) {
        boolean isDigit = false;//定义一个boolean值，用来表示是否包含数字
        boolean isLetter = false;//定义一个boolean值，用来表示是否包含字母
        for (int i = 0; i < str.length(); i++) {
            if (Character.isDigit(str.charAt(i))) {     //用char包装类中的判断数字的方法判断每一个字符
                isDigit = true;
            }
            if (Character.isLetter(str.charAt(i))) {   //用char包装类中的判断字母的方法判断每一个字符
                isLetter = true;
            }
        }

        String regex = "^[a-zA-Z0-9]+$";
        boolean isRight = isDigit && isLetter && str.matches(regex);
        return isRight;
    }

}
