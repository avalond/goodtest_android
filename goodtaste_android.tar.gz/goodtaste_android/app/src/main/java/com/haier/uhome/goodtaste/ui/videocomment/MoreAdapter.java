package com.haier.uhome.goodtaste.ui.videocomment;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.data.models.VideoInfo;
import com.haier.uhome.goodtaste.utils.ImageDownLoader;

import java.util.List;

/**
 * Created by Administrator on 2016/5/18.
 */
public class MoreAdapter extends BaseAdapter {

    public List<VideoInfo> videolistbyalbumiddata;
    public Context cont;
    private VideoInfo videoInfo;
    private String videoNetUrl;

    public MoreAdapter(List<VideoInfo> dateList, Context context) {
        videolistbyalbumiddata = dateList;
        cont = context;
    }
    @Override
    public int getCount() {
        return videolistbyalbumiddata.size();
    }

    @Override
    public Object getItem(int position) {
        return videolistbyalbumiddata.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        videoInfo = videolistbyalbumiddata.get(position);
        if(convertView == null){
            viewHolder = new ViewHolder();
            convertView = View.inflate(cont, R.layout.item_more_video, null);
            viewHolder.ivVideoImage = (ImageView) convertView.findViewById(R.id.iv_user_image);
            viewHolder.ivVideoPleric = (ImageView) convertView.findViewById(R.id.iv_video_pleric);
            viewHolder.tvPlayCount = (TextView) convertView.findViewById(R.id.tv_play_count);
            viewHolder.tvText = (TextView) convertView.findViewById(R.id.tv_text);
            viewHolder.tvVideoName = (TextView) convertView.findViewById(R.id.tv_video_name);
            viewHolder.tvVideoClassify = (TextView) convertView.findViewById(R.id.tv_video_classify);

            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();

            String thumbnail = videoInfo.getData().getThumbnail();
            ImageDownLoader.get(cont).display(thumbnail,
                    (ImageView) convertView.findViewById(R.id.iv_video_pleric));

            viewHolder.tvVideoName.setText(videoInfo.getData().getName());
            viewHolder.tvVideoClassify.setText("类别:"+videoInfo.getData().getAlbumName());
            videoNetUrl = videoInfo.getData().getVideoNetUrl();

            int playNum = videoInfo.getData().getPlayNum();
            String play = String.valueOf(playNum);
            viewHolder.tvPlayCount.setText(play);
            viewHolder.tvText.setText(R.string.video_play_text);
        }
        return convertView;
    }
    static class ViewHolder{
        TextView tvVideoName;
        ImageView ivVideoPleric;
        TextView tvVideoClassify;
        TextView tvPlayCount;
        ImageView ivVideoImage;
        TextView tvText;
    }
}
