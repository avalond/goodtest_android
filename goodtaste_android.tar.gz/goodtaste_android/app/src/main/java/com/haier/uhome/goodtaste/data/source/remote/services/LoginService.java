package com.haier.uhome.goodtaste.data.source.remote.services;

import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.data.models.BaseEntity;
import com.haier.uhome.goodtaste.data.models.LoginInfo;

import retrofit2.http.Body;
import retrofit2.http.POST;
import rx.Observable;

/**
 * 登录
 * <br>Created by Dallas.
 */
public interface LoginService {
    String DEBUG_BASE_URL = "http://" + BaseService.DEBUG_HOST + ":7480/";
    String DEBUG_VERIFY_BASE_URL = "https://" + BaseService.DEBUG_VERIFY_HOST + ":7480/";
    String PRE_PRODUCT_BASE_RUL = "https://" + BaseService.PRE_PRODUCT_HOST + ":7480/";
    String PRODUCT_BASE_RUL = "https://" + BaseService.PRODUCT_HOST + ":7480/";

    @POST("foodStreetData/recipe/user/login")
    Observable<BaseEntity<LoginInfo>> login(@Body JsonObject req);
}
