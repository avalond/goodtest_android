package com.haier.uhome.goodtaste.data.source.remote.services;

import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.data.models.BaseEntity;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.ChefInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;

import java.util.List;

import retrofit2.http.Body;
import retrofit2.http.POST;
import rx.Observable;

/**
 * 主厨
 * <p>
 * Created by lijin on 16-5-7.
 */
public interface ChefService {
    String DEBUG_BASE_URL = "http://" + BaseService.DEBUG_HOST + ":7480/";
    String DEBUG_VERIFY_BASE_URL = "http://" + BaseService.DEBUG_VERIFY_HOST + ":7480/";
    String PRE_PRODUCT_BASE_RUL = "http://" + BaseService.PRE_PRODUCT_HOST + ":7480/";
    String PRODUCT_BASE_RUL = "http://" + BaseService.PRODUCT_HOST + ":7480/";

    @POST("foodStreetData/recipe/chef/findChefRank")
    Observable<BaseEntity<List<ChefInfo>>> findChefRank(@Body JsonObject req);

    @POST("foodStreetData/recipe/chef/findFansByUserId")
    Observable<BaseEntity<List<UserInfo>>> findFansByUserId(@Body JsonObject req);

    @POST("foodStreetData/recipe/chef/findFansNumByUserId")
    Observable<BaseEntity<JsonObject>> findFansNumByUserId(@Body JsonObject req);

    @POST("foodStreetData/recipe/chef/findFocusByUserId")
    Observable<BaseEntity<List<UserInfo>>> findFocusByUserId(@Body JsonObject req);

    @POST("foodStreetData/recipe/chef/findFocusNumByUserId")
    Observable<BaseEntity<JsonObject>> findFocusNumByUserId(@Body JsonObject req);

    @POST("foodStreetData/recipe/chef/addPraise")
    Observable<BaseResult> addPraise(@Body JsonObject req);

    @POST("foodStreetData/recipe/chef/subscribe")
    Observable<BaseResult> subscribe(@Body JsonObject req);

    @POST("foodStreetData/recipe/chef/unsubscribe")
    Observable<BaseResult> unsubscribe(@Body JsonObject req);

    @POST("foodStreetData/recipe/chef/issubscribe")
    Observable<BaseEntity<JsonObject>> isSubscribe(@Body JsonObject req);

    @POST("foodStreetData/recipe/chef/collectRecipe")
    Observable<BaseResult> collectRecipe(@Body JsonObject req);

    @POST("foodStreetData/recipe/chef/uncollectRecipe")
    Observable<BaseResult> uncollectRecipe(@Body JsonObject req);

    @POST("foodStreetData/recipe/chef/commentRecipe")
    Observable<BaseResult> commentRecipe(@Body JsonObject req);

    @POST("foodStreetData/recipe/chef/delCommentRecipe")
    Observable<BaseResult> delCommentRecipe(@Body JsonObject req);
}
