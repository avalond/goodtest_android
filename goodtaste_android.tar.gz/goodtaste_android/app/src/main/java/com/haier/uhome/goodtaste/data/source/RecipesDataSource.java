package com.haier.uhome.goodtaste.data.source;

import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.CommentInfo;
import com.haier.uhome.goodtaste.data.models.HotKey;
import com.haier.uhome.goodtaste.data.models.Material;
import com.haier.uhome.goodtaste.data.models.RecipeData;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;
import com.haier.uhome.goodtaste.data.models.RecomRecipe;
import com.haier.uhome.goodtaste.data.models.req.CreateRecipeReq;
import com.haier.uhome.goodtaste.data.models.req.CreateRecipeStepReq;

import java.util.List;

import rx.Observable;

/**
 * 菜谱数据源
 */
public interface RecipesDataSource {
    /**
     * 根据关键字获取菜谱列表，没有结果返回推荐菜谱
     *
     * @param recipeKey  查询关键字
     * @param recipeType 1：表示根据关键字查询；2：表示查询推荐菜谱 ，推荐菜谱才会返回点赞数否则点赞数位空
     * @param pageNum    页数
     * @param orderType  1：表示更新时间排序
     * @param updateTime 时间戳
     * @return Observable
     */
    Observable<List<RecipeWithUser>> getRecipeInfoList(String recipeKey, int recipeType, int pageNum, int orderType,
        String updateTime);

    /**
     * 根据关键字查询菜谱
     *
     * @param recipeKey 查询关键字
     * @param pageNum   页数
     * @return Observable
     */
    Observable<List<RecipeWithUser>> queryRecipe(String recipeKey, int pageNum);

    /**
     * 获取所有菜谱
     *
     * @param pageNum    页数
     * @param updateTime 时间戳
     * @return Observable
     */
    Observable<List<RecipeWithUser>> getRecipeInfoList(int pageNum, String updateTime);

    /**
     * 获取推荐菜谱
     *
     * @param pageNum    页数
     * @param updateTime 时间戳
     * @return Observable
     */
    Observable<List<RecomRecipe>> getRecommendRecipeInfoList(int pageNum, String updateTime);

    /**
     * 根据菜谱ID获取菜谱详情
     *
     * @param id 菜谱ID
     * @return Observable
     */
    Observable<RecipeData> getRecipeDetail(String id);

    /**
     * 根据用户ID获取用户发布菜谱列表
     *
     * @param userId    用户ID
     * @param recipeKey 查询关键字
     * @param state     0：全部；1：待审核；2：审核中3审核通过；4：审核不通过
     * @param pageNum   页数
     * @return Observable
     */
    Observable<List<RecipeData>> getUserPubRecipeList(String userId, String recipeKey, int state, int pageNum);

    /**
     * 根据用户ID获取用户收藏菜谱列表
     *
     * @param userId  用户ID
     * @param pageNum 页数
     * @return Observable
     */
    Observable<List<RecipeData>> getUserFavRecipeList(String userId, int pageNum);

    /**
     * 根据用户ID获取用户保存的草稿菜谱列表
     *
     * @param userId  用户ID
     * @param pageNum 页数
     * @return Observable
     */
    Observable<List<RecipeData>> getUserDraftRecipeList(String userId, int pageNum);

    /**
     * 根据菜谱ID获取菜谱评论列表
     *
     * @param recipeId 菜谱ID
     * @param pageNum  页数
     * @return Observable
     */
    Observable<List<CommentInfo>> getRecipeCommentList(String recipeId, int pageNum);

    /**
     * 获取食材列表
     *
     * @param pageNum 页数
     * @return Observable
     */
    Observable<List<Material>> getMaterialList(int pageNum);

    /**
     * 创建菜谱
     *
     * @param recipe 菜谱信息
     * @return Observable
     */
    Observable<String> createRecipe(CreateRecipeReq recipe);

    /**
     * 菜谱添加步骤
     *
     * @param step 步骤信息
     * @return Observable
     */
    Observable<BaseResult> createRecipeStep(CreateRecipeStepReq step);

    /**
     * 上传菜谱添加步骤图片
     *
     * @return Observable
     * @deprecated
     */
    Observable<BaseResult> uploadRecipeStepPic();

    /**
     * 热搜关键字查询接口
     *
     * @return Observable
     */
    Observable<List<HotKey>> getRecipeHotKey();

    /**
     * 保存推荐菜谱
     *
     * @param recipeList 推荐菜谱列表
     * @return Observable
     */
    Observable<List<RecomRecipe>> saveRecomRecipe(List<RecomRecipe> recipeList);

    /**
     * 保存菜谱
     *
     * @param recipeList 菜谱列表
     * @return Observable
     */
    Observable<List<RecipeWithUser>> saveRecipe(List<RecipeWithUser> recipeList);

    /**
     * 保存热搜关键字
     *
     * @param hotKeyList 热搜关键字列表
     * @return 关键字列表
     */
    Observable<List<HotKey>> saveHotKey(List<HotKey> hotKeyList);
}
