package com.haier.uhome.goodtaste.data.source.remote;

import android.support.annotation.NonNull;

import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.data.models.AccType;
import com.haier.uhome.goodtaste.data.models.AppVersionResult;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.GatewayResult;
import com.haier.uhome.goodtaste.data.models.ResourceResult;
import com.haier.uhome.goodtaste.data.models.UploadResult;
import com.haier.uhome.goodtaste.data.models.UvcResult;
import com.haier.uhome.goodtaste.data.models.Validate;
import com.haier.uhome.goodtaste.data.source.CommonDataSource;
import com.haier.uhome.goodtaste.data.source.remote.services.CommonService;
import com.haier.uhome.goodtaste.data.source.remote.services.LogoutService;
import com.haier.uhome.goodtaste.data.source.remote.services.PmsService;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Authenticator;
import okhttp3.Credentials;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.Route;
import rx.Observable;
import rx.Subscriber;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

/**
 * <p>Created by dallas on 16-4-18.
 */
public class CommonRemoteDataSource extends AbsRemoteDataSource implements CommonDataSource {

    private final LogoutService mLogoutService;
    private final PmsService mPmsService;
    private final CommonService mCommonService;

    public CommonRemoteDataSource(@EnvironmentMode int mode, @NonNull OkHttpClient httpClient) {
        super(mode, httpClient);

        switch (mode) {
            case DEBUG:
                mLogoutService = createService(LogoutService.DEBUG_BASE_URL, LogoutService.class);
                mPmsService = createService(PmsService.DEBUG_BASE_URL, PmsService.class);
                mCommonService = createService(CommonService.DEBUG_BASE_URL, CommonService.class);
                break;
            case DEBUG_VERIFY:
                mLogoutService = createService(LogoutService.DEBUG_VERIFY_BASE_URL, LogoutService.class);
                mPmsService = createService(PmsService.DEBUG_VERIFY_BASE_URL, PmsService.class);
                mCommonService = createService(CommonService.DEBUG_VERIFY_BASE_URL, CommonService.class);
                break;
            case PRE_PRODUCT:
                mLogoutService = createService(LogoutService.PRE_PRODUCT_BASE_RUL, LogoutService.class);
                mPmsService = createService(PmsService.PRE_PRODUCT_BASE_RUL, PmsService.class);
                mCommonService = createService(CommonService.PRE_PRODUCT_BASE_RUL, CommonService.class);
                break;
            case PRODUCT:
            default:
                mLogoutService = createService(LogoutService.PRODUCT_BASE_RUL, LogoutService.class);
                mPmsService = createService(PmsService.PRODUCT_BASE_RUL, PmsService.class);
                mCommonService = createService(CommonService.PRODUCT_BASE_RUL, CommonService.class);
                break;
        }
    }


    @Override
    public Observable<BaseResult> logout() {
        JsonObject req = new JsonObject();
        req.addProperty("sequenceId", getSequenceId());
        return mLogoutService.logout(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<GatewayResult> getDeviceGateWay(String userId, String sdkVer, String platform, String model) {
        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("appId", getHeaders().get("appId"));
        req.addProperty("usdkVers", sdkVer);
        req.addProperty("platform", platform);
        req.addProperty("model", model);
        return mPmsService.getDeviceGateWay(req).compose(this.<GatewayResult>getTransformer());
    }

    @Override
    public Observable<AppVersionResult> getAppVersionInfo(String appId) {
        return mCommonService.getAppVersionInfo(appId).compose(this.<AppVersionResult>getTransformer());
    }

    @Override
    public Observable<UvcResult> postUserVerificationCode(String account, @Validate.Type int type,
        @Validate.Scene int scene, String sendTo, @AccType.Type int accType) {
        JsonObject req = new JsonObject();
        req.addProperty("loginName", account);
        req.addProperty("validateType", type);
        req.addProperty("validateScene", scene);
        req.addProperty("sendTo", sendTo);
        req.addProperty("accType", accType);
        req.addProperty("sequenceId", getSequenceId());

        return mCommonService.postUserVerificationCode(req).compose(this.<UvcResult>getTransformer());
    }

    @Override
    public Observable<UvcResult> postUvcMobile(String account, String mobile, @Validate.Scene int scene) {
        return postUserVerificationCode(account, Validate.TYPE_MOBILE, scene, mobile, AccType.HAIER);
    }

    @Override
    public Observable<UvcResult> postUvcEmail(String account, String email, @Validate.Scene int scene) {
        return postUserVerificationCode(account, Validate.TYPE_EMAIL, scene, email, AccType.HAIER);
    }

    @Override
    public Observable<BaseResult> verifyUserVerificationCode(String uvc, String account, @Validate.Type int type,
        @Validate.Scene int scene, String transactionId, @AccType.Type int accType) {
        JsonObject req = new JsonObject();
        req.addProperty("loginName", account);
        req.addProperty("validateType", type);
        req.addProperty("validateScene", scene);
        req.addProperty("transactionId", transactionId);
        req.addProperty("accType", accType);
        req.addProperty("sequenceId", getSequenceId());

        return mCommonService.verifyUserVerificationCode(uvc, req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<BaseResult> verifyUvcMobile(String uvc, String account, String transactionId,
        @Validate.Scene int scene) {
        return verifyUserVerificationCode(uvc, account, Validate.TYPE_MOBILE, scene, transactionId, AccType.HAIER);
    }

    @Override
    public Observable<BaseResult> verifyUvcEmail(String uvc, String account, String transactionId,
        @Validate.Scene int scene) {
        return verifyUserVerificationCode(uvc, account, Validate.TYPE_EMAIL, scene, transactionId, AccType.HAIER);
    }

    @Override
    public Observable<ResourceResult> assignResource(String useType, String id, String type, String ext, String name,
        String description) {
        JsonObject req = new JsonObject();
        req.addProperty("id", id);
        req.addProperty("type", type);
        req.addProperty("ext", ext);
        req.addProperty("name", name);
        req.addProperty("description", description);
        return mCommonService.assignResource(useType, req).compose(this.<ResourceResult>getTransformer());
    }

    @Override
    public Observable<String> uploadAvatar(String userId, final File file) {
        return assignResource("U", userId, "avatar", ".jpg", "123", "123").flatMap(
            new Func1<ResourceResult, Observable<UploadResult>>() {
                @Override
                public Observable<UploadResult> call(ResourceResult resourceResult) {
                    return uploadFile(resourceResult.getUri(), file);
                }
            })  .map(new Func1<UploadResult, String>() {
                @Override
                public String call(UploadResult uploadResult) {
                    return uploadResult.getUrl();
                }
            });
    }

    private Observable<UploadResult> uploadFile(final String url, final File file) {
        return Observable.create(new Observable.OnSubscribe<UploadResult>() {
            @Override
            public void call(Subscriber<? super UploadResult> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }

                OkHttpClient newClient = httpClient.newBuilder()
                    .authenticator(new Authenticator() {
                        @Override
                        public Request authenticate(Route route, Response response) throws IOException {
                            String credential = Credentials.basic("admin", "admin1881");
                            return response.request().newBuilder().header("Authorization", credential).build();
                        }
                    })
                    .connectTimeout(600000, TimeUnit.MILLISECONDS)
                    .readTimeout(600000, TimeUnit.MILLISECONDS)
                    .writeTimeout(600000, TimeUnit.MILLISECONDS)
                    .build();

                RequestBody requestBody = RequestBody.create(MediaType.parse("application/octet-stream"), file);

                Request request = new Request.Builder().url(url)
                    .header("Content-Type", "image/jpeg")
                    .put(requestBody)
                    .build();

                try {
                    Response response = newClient.newCall(request).execute();

                    if (!response.isSuccessful()) {
                        subscriber.onError(new IOException("Unexpected code " + response));
                    } else {
                        UploadResult result = new UploadResult();
                        result.setRetCode(BaseResult.RET_OK);
                        result.setRetInfo("upload success!");
                        result.setUrl(url);

                        subscriber.onNext(result);
                        subscriber.onCompleted();
                    }
                } catch (Exception e) {
                    subscriber.onError(e);
                }
            }
        }).subscribeOn(Schedulers.io());
    }

}
