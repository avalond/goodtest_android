package com.haier.uhome.goodtaste.data.models.req;

import java.io.Serializable;

public class RecipeStepReq implements Serializable {
    private static final long serialVersionUID = 5320018501676317893L;

    /**
     * picUrl : 图片地址
     * note  : 步骤描述
     * isTop : Y/N
     */

    private String picUrl;
    private String note;
    private String isTop;

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getIsTop() {
        return isTop;
    }

    public void setIsTop(String isTop) {
        this.isTop = isTop;
    }
}
