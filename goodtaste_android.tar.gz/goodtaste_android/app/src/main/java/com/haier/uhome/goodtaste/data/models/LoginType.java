package com.haier.uhome.goodtaste.data.models;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * 登录类型
 * <br>Created by Dallas on 2015/10/21.
 */
public final class LoginType {
    @IntDef({USER_NAME, MOBILE, EMAIL})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Type {}

    public static final int USER_NAME = 0;
    public static final int MOBILE = 1;
    public static final int EMAIL = 2;
}
