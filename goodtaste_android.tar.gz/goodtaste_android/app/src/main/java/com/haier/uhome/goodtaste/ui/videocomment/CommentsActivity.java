package com.haier.uhome.goodtaste.ui.videocomment;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.gmail.adffice.rxflux.RxFlux;
import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.actions.VideoCommentActions;
import com.haier.uhome.goodtaste.actions.VideoCommentActionsCreator;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.VideoCommentInfo;
import com.haier.uhome.goodtaste.data.models.VideoInfo;
import com.haier.uhome.goodtaste.data.models.req.VideoCommentReq;
import com.haier.uhome.goodtaste.stores.UserStore;
import com.haier.uhome.goodtaste.stores.VideoCommentStores;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.utils.ErrorHandler;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.utils.ImageDownLoader;
import com.haier.uhome.goodtaste.widgets.HomePtrClassicFrameLayout;
import com.haier.uhome.goodtaste.widgets.loadmore.FooterAdapter;
import com.haier.uhome.goodtaste.widgets.loadmore.LoadMoreListener;
import com.haier.uhome.goodtaste.widgets.ptr.PtrDefaultHandler;
import com.haier.uhome.goodtaste.widgets.ptr.PtrFrameLayout;
import com.haier.uhome.goodtaste.widgets.ptr.PtrHandler;

import java.util.List;

/**
 * Created by Administrator on 2016/5/15.
 */
public class CommentsActivity extends BaseActivity implements View.OnClickListener {

    //@Bind(R.id.lv_comment_video)
    ListView lvCommentEntry;
    //@Bind(R.id.et_comment_file)
    EditText etCommentFile;

    HomePtrClassicFrameLayout mPtrFrame;//下拉刷新层

    private TextView tvHint;
    private EditText etShowMessage;
    private Dialog dialog;
    private TextView tvNum;
    private TextView tvText;
    private CharSequence temp;
    private static final int CHARMAXNUM = 140;
    private static final int TEXTEND = 0;
    private VideoCommentActionsCreator mVideoCommentActoinCreator;
    private MyAdapter myAdapter;
    private VideoCommentStores mVideoCommentStores;
    private List<VideoCommentInfo> moreVideoData;
    private String userId;
    private int pageUum = 1;
    public final static String MSG_KEY = "VideoComment";
    private UserStore userStore;
    private VideoInfo videoInfoData;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);
        RxFlux mRxFlux = getApp().getRxFlux();
        DataManager mDataManager = getApp().getDataManager();
        mVideoCommentActoinCreator = new VideoCommentActionsCreator(this, mDataManager, mRxFlux.getDispatcher(),
                mRxFlux.getSubscriptionManager());
        showProgressDialog("数据加载中");
        initDate();
    }


    private void initDate() {
        lvCommentEntry = (ListView) findViewById(R.id.lv_comment_video);
        etCommentFile = (EditText) findViewById(R.id.et_comment_file);
        mPtrFrame = (HomePtrClassicFrameLayout) findViewById(R.id.menu_ptr_frame);
        mPtrFrame.setLastUpdateTimeRelateObject(this);
        mPtrFrame.setPtrHandler(mPtrHandler);
        // the following are default settings
        mPtrFrame.setResistance(1.7f);
        mPtrFrame.setRatioOfHeaderHeightToRefresh(1.2f);
        mPtrFrame.setDurationToClose(200);
        mPtrFrame.setDurationToCloseHeader(1000);
        mPtrFrame.setPullToRefresh(false);
        mPtrFrame.setKeepHeaderWhenRefresh(true);
        mPtrFrame.disableWhenHorizontalMove(true);

        setToolbarTitle(getResources().getString(R.string.video_comment));
        etCommentFile.setOnClickListener(this);
        Intent intent = getIntent();
        Bundle data = intent.getExtras();
        videoInfoData = (VideoInfo) data.getSerializable(MSG_KEY);
        videoInfoData.getUserInfo().getUserId();
        String videoId = videoInfoData.getData().getId();
        userId = userStore.getUserId();
        //获取视频评论全部信息
        mVideoCommentActoinCreator.moreVideoComment(videoId, userId, pageUum);
        //lvCommentEntry.addFooterView();
    }

    private PtrHandler mPtrHandler = new PtrHandler() {
        @Override
        public void onRefreshBegin(PtrFrameLayout frame) {
            //获取视频评论全部信息
            String videoId = videoInfoData.getData().getId();
            mVideoCommentActoinCreator.moreVideoComment(videoId, userId, pageUum);
        }

        @Override
        public boolean checkCanDoRefresh(PtrFrameLayout frame, View content, View header) {
            return PtrDefaultHandler.checkContentCanBePulledDown(frame, content, header);
        }
    };

    private boolean isLoadingData = false;
    //是否可加载更多
    private boolean canloadMore = true;
    //监听器
    private LoadMoreListener loadMoreListener;

    //设置是否可加载更多
    public void setCanloadMore(boolean flag) {
        canloadMore = flag;
    }


    private void showAdapter() {
        if (myAdapter == null) {
            myAdapter = new MyAdapter();
            lvCommentEntry.setAdapter(myAdapter);
        }
        myAdapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.et_comment_file:
                showDialog();
                toggleSoftInput(this, etShowMessage);
                break;
            case R.id.btn_video_send:
                //发送数据
                String cookeruserId = videoInfoData.getUserInfo().getUserId();
                String videoId = videoInfoData.getData().getId();
                String messageContent = etShowMessage.getText().toString().trim();
                VideoCommentReq videoCommentReq = new VideoCommentReq();
                videoCommentReq.setVideoId(videoId);
                videoCommentReq.setContent(messageContent);
                videoCommentReq.setToUser(cookeruserId);
                videoCommentReq.setFromUser(this.userId);
                mVideoCommentActoinCreator.commentVideo(videoCommentReq);
                dialog.dismiss();
                lvCommentEntry.deferNotifyDataSetChanged();
                break;
            case R.id.tv_user_delete:
                break;
            default:
                break;
        }
    }

    @Override
    public void onRxStoresRegister() {
        mVideoCommentStores = VideoCommentStores.get(this);
        mVideoCommentStores.register();
        userStore = UserStore.get(this);
        userStore.register();
    }

    @Override
    public void onRxStoresUnRegister() {
        mVideoCommentStores.unregister();
        userStore.unregister();
    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {
        switch (change.getStoreId()) {
            case VideoCommentStores.ID:
                switch (change.getRxAction().getType()) {
                    case VideoCommentActions.ID_MORE_VIDEO_COMMENT:
                        mPtrFrame.refreshComplete();
                        moreVideoData = (List<VideoCommentInfo>) change.getRxAction().getData();
                        HaierLoger.i("TAG", moreVideoData);
                        stopProgressDialog();
                        if (moreVideoData.size() <= 0) {
                            return;
                        }
                        showAdapter();
                        break;
                    case VideoCommentActions.ID_ALL_COMMENT:

                        break;
                    case VideoCommentActions.ID_COMMENT_VIDEO:
                        BaseResult commentVideoData = (BaseResult) change.getRxAction().getData();

                        break;
                    default:
                        break;
                }
                break;
            default:
                break;

        }
    }

    @Override
    public void onRxError(RxError error) {
        mPtrFrame.refreshComplete();
        showToast(ErrorHandler.handelError(error.getThrowable(), this));
    }

    private void showDialog() {
        dialog = new Dialog(this, R.style.dialog_video);
        View view = View.inflate(this, R.layout.layout_video_delog, null);
        dialog.setContentView(view); //设置dialog的布局
        Window dialogWindow = dialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        dialogWindow.setGravity(Gravity.BOTTOM);
        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = dialogWindow.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 0.28); // 高度设置为屏幕的0.6
        p.width = (int) (d.getWidth() * 1.0); // 宽度设置为屏幕的0.65
        dialogWindow.setAttributes(p);
        dialogWindow.setAttributes(lp);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();//显示dialog界面

        tvHint = (TextView) view.findViewById(R.id.tv_hint);
        tvNum = (TextView) view.findViewById(R.id.tv_num);
        tvText = (TextView) view.findViewById(R.id.tv_text);

        etShowMessage = (EditText) view.findViewById(R.id.et_show_message);
        Button btnVideoSend = (Button) view.findViewById(R.id.btn_video_send);
        btnVideoSend.setOnClickListener(this);
        etShowMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                temp = s;
            }

            @Override
            public void afterTextChanged(Editable s) {
                tvNum.setText(String.valueOf((CHARMAXNUM - s.length())));
                if (temp.length() >= CHARMAXNUM) {
                    tvNum.setText(String.valueOf(TEXTEND));
                    tvNum.setTextColor(getResources().getColor(R.color.red));
                    tvHint.setTextColor(getResources().getColor(R.color.red));
                    tvText.setTextColor(getResources().getColor(R.color.red));
                } else {
                    tvNum.setTextColor(getResources().getColor(R.color.black));
                    tvHint.setTextColor(getResources().getColor(R.color.home_rank_more_cooker));
                    tvText.setTextColor(getResources().getColor(R.color.home_rank_more_cooker));
                }
            }
        });
    }

    @Override
    protected View createToolbarView(LayoutInflater inflater, ViewGroup container) {
        View view = super.createToolbarView(inflater, container);
        TextView mLeftBack = (TextView) view.findViewById(R.id.toolbar_left_btn);
        TextView mRightBtn = (TextView) view.findViewById(R.id.toolbar_right_btn);
        mLeftBack.setCompoundDrawablesWithIntrinsicBounds(R.drawable.back_icon, 0, 0, 0);
        mRightBtn.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        return view;
    }

    public static void toggleSoftInput(Context context, EditText edit) {
        edit.setFocusable(true);
        edit.setFocusableInTouchMode(true);
        edit.requestFocus();
        InputMethodManager inputManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        inputManager.toggleSoftInput(InputMethodManager.SHOW_FORCED, 200);
    }


    private class MyAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return moreVideoData.size();
        }

        @Override
        public Object getItem(int position) {
            return moreVideoData.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            VideoCommentInfo info = moreVideoData.get(position);
            UserInfo userInfo = info.getCreaterUserInfo();
            VideoCommentInfo.Data data = info.getData();
            if (convertView == null) {
                viewHolder = new ViewHolder();
                convertView = View.inflate(getApplicationContext(), R.layout.item_comments_listview, null);
                viewHolder.userImage = (ImageView) convertView.findViewById(R.id.iv_user_image);
                viewHolder.userDate = (TextView) convertView.findViewById(R.id.tv_report_date);
                viewHolder.userName = (TextView) convertView.findViewById(R.id.tv_user_name);
                viewHolder.userMessage = (TextView) convertView.findViewById(R.id.tv_report_message);
                viewHolder.userDele = (TextView) convertView.findViewById(R.id.tv_user_delete);

                if (info.getData().isDelete()) {
                    viewHolder.userDele.setVisibility(View.VISIBLE);
                } else {
                    viewHolder.userDele.setVisibility(View.GONE);
                }

                viewHolder.userDele.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String commentUserId = moreVideoData.get(position).getCreaterUserInfo().getLoginId();
                        String commentVideoId = moreVideoData.get(position).getData().getId();
                        moreVideoData.get(position).getCreaterUserInfo().getId();
                        mVideoCommentActoinCreator.deleteVideoComment(commentVideoId, commentUserId);
                        notifyDataSetChanged();
                    }
                });

                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();

                String avater = userInfo.getAvater();
                ImageDownLoader.get(getApplicationContext()).display(avater, (ImageView)
                        convertView.findViewById(R.id.iv_user_image));
                //viewHolder.userImage.setBackgroundResource(R.drawable.ic_user_image);
                String createTimeStr = data.getCreateTimeStr();
                viewHolder.userDate.setText(createTimeStr);
                String content = data.getContent();
                viewHolder.userMessage.setText(content);
                String nickName = userInfo.getNickName();
                viewHolder.userName.setText(nickName);

            }
            return convertView;
        }
    }

    static class ViewHolder {
        ImageView userImage;
        TextView userName;
        TextView userDate;
        TextView userMessage;
        TextView userDele;
    }
}
