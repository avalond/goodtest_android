/*
* 文件名：ImageDownLoader
* 版权：〈版权〉
* 描述：〈描述〉
* 修改人： malm@haierubic.com
* 修改时间：2016-03-17 
* 修改单号：〈修改单号〉
* 修改内容：〈修改内容〉
*/


package com.haier.uhome.goodtaste.utils;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.DrawableRes;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.haier.uhome.goodtaste.R;

import java.io.File;

public class ImageDownLoader {
    private static ImageDownLoader sInstance;

    public static RequestManager with(Context context) {
        return Glide.with(context);
    }

    public static RequestManager with(Activity activity) {
        return Glide.with(activity);
    }

    public static RequestManager with(FragmentActivity activity) {
        return Glide.with(activity);
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public static RequestManager with(android.app.Fragment fragment) {
        return Glide.with(fragment);
    }

    public static RequestManager with(Fragment fragment) {
        return Glide.with(fragment);
    }

    public static ImageDownLoader get(Context context) {
        if (sInstance == null) {
            sInstance = new ImageDownLoader(context);
        }
        return sInstance;
    }

    private Context mContext;

    private ImageDownLoader(Context context) {
        mContext = context.getApplicationContext();
    }

    public void display(String url, Drawable holderDrawable, Drawable errorDrawable, ImageView imageView) {
        Glide.with(mContext)
            .load(url)
            .asBitmap()
            .animate(R.anim.fade_in)
            .diskCacheStrategy(DiskCacheStrategy.RESULT)
            .placeholder(holderDrawable)
            .error(errorDrawable)
            .into(imageView);
    }

    public void display(String url, Drawable holderDrawable, ImageView imageView) {
        Glide.with(mContext)
            .load(url)
            .asBitmap()
            .animate(R.anim.fade_in)
            .diskCacheStrategy(DiskCacheStrategy.RESULT)
            .placeholder(holderDrawable)
            .into(imageView);
    }

    public void display(String url, @DrawableRes int holderResId, @DrawableRes int errorResId, ImageView imageView) {
        Glide.with(mContext)
            .load(url)
            .asBitmap()
            .animate(R.anim.fade_in)
            .diskCacheStrategy(DiskCacheStrategy.RESULT)
            .placeholder(holderResId)
            .error(errorResId)
            .into(imageView);
    }

    public void display(String url, @DrawableRes int holderResId, ImageView imageView) {
        Glide.with(mContext)
            .load(url)
            .asBitmap()
            .animate(R.anim.fade_in)
            .diskCacheStrategy(DiskCacheStrategy.RESULT)
            .placeholder(holderResId)
            .into(imageView);
    }

    //===
    public void display(File file, Drawable holderDrawable, Drawable errorDrawable, ImageView imageView) {
        Glide.with(mContext)
            .load(file)
            .asBitmap()
            .animate(R.anim.fade_in)
            .diskCacheStrategy(DiskCacheStrategy.RESULT)
            .placeholder(holderDrawable)
            .error(errorDrawable)
            .into(imageView);
    }

    public void display(File file, Drawable holderDrawable, ImageView imageView) {
        Glide.with(mContext)
            .load(file)
            .asBitmap()
            .animate(R.anim.fade_in)
            .diskCacheStrategy(DiskCacheStrategy.RESULT)
            .placeholder(holderDrawable)
            .into(imageView);
    }

    public void display(File file, @DrawableRes int holderResId, @DrawableRes int errorResId, ImageView imageView) {
        Glide.with(mContext)
            .load(file)
            .asBitmap()
            .animate(R.anim.fade_in)
            .diskCacheStrategy(DiskCacheStrategy.RESULT)
            .placeholder(holderResId)
            .error(errorResId)
            .into(imageView);
    }

    public void display(File file, @DrawableRes int holderResId, ImageView imageView) {
        Glide.with(mContext)
            .load(file)
            .asBitmap()
            .animate(R.anim.fade_in)
            .diskCacheStrategy(DiskCacheStrategy.RESULT)
            .placeholder(holderResId)
            .into(imageView);
    }

    public void display(String url, ImageView imageView) {
        Glide.with(mContext)
            .load(url)
            .asBitmap()
            .animate(R.anim.fade_in)
            .diskCacheStrategy(DiskCacheStrategy.RESULT)
            .into(imageView);
    }

    public void fetchImage(String url, int width, int height) {
        if (!TextUtils.isEmpty(url)) {
            Glide.with(mContext).load(url).downloadOnly(width, height);
        }
    }
}
