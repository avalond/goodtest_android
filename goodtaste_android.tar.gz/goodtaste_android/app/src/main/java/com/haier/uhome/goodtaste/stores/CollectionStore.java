package com.haier.uhome.goodtaste.stores;

import android.content.Context;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.actions.CollectionActions;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.RecipeData;

import java.util.List;

/**
 * Created by Administrator on 2016/5/17.
 */
public class CollectionStore extends BaseStore {

    /*public CollectionStore(Dispatcher dispatcher) {
        super(dispatcher);
    }*/

    public static final String ID = "CollectionStore";

    private static CollectionStore instance;
    public static CollectionStore get(Context context) {
        //instance.context = context;
        if (instance == null) {
            HaierApplication app = (HaierApplication) context.getApplicationContext();
            instance = new CollectionStore(app.getRxFlux().getDispatcher());
        }
        return instance;
    }

    protected CollectionStore(Dispatcher dispatcher) {
        super(dispatcher);
    }

    @Override
    protected void onAction(RxAction action) {

        switch (action.getType()){
            case CollectionActions.ID_USER_COLLECTION:

                List<RecipeData> recipeDatas = (List<RecipeData>) action.getData();
                recipeDatas.size();
                break;
            case CollectionActions.ID_USER_DELETE_COLLECTION:

                BaseResult recipeData = (BaseResult) action.getData();

                break;
            default:
                break;
        }

        postStoreChange(new RxStoreChange(ID, action));

    }
}
