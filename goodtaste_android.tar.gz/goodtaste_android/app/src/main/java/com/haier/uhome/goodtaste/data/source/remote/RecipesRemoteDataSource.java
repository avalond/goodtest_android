package com.haier.uhome.goodtaste.data.source.remote;

import android.support.annotation.NonNull;

import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.data.models.BaseEntity;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.CommentInfo;
import com.haier.uhome.goodtaste.data.models.HotKey;
import com.haier.uhome.goodtaste.data.models.Material;
import com.haier.uhome.goodtaste.data.models.RecipeData;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;
import com.haier.uhome.goodtaste.data.models.RecomRecipe;
import com.haier.uhome.goodtaste.data.models.req.CreateRecipeReq;
import com.haier.uhome.goodtaste.data.models.req.CreateRecipeStepReq;
import com.haier.uhome.goodtaste.data.source.RecipesDataSource;
import com.haier.uhome.goodtaste.data.source.remote.services.RecipesService;

import java.util.List;

import okhttp3.OkHttpClient;
import rx.Observable;
import rx.functions.Func1;

/**
 */
public class RecipesRemoteDataSource extends AbsRemoteDataSource implements RecipesDataSource {
    private final RecipesService mRecipesService;

    public RecipesRemoteDataSource(@EnvironmentMode int mode, @NonNull OkHttpClient httpClient) {
        super(mode, httpClient);
        switch (mode) {
            case DEBUG:
                mRecipesService = createService(RecipesService.DEBUG_BASE_URL, RecipesService.class);
                break;
            case DEBUG_VERIFY:
                mRecipesService = createService(RecipesService.DEBUG_VERIFY_BASE_URL, RecipesService.class);
                break;
            case PRE_PRODUCT:
                mRecipesService = createService(RecipesService.PRE_PRODUCT_BASE_RUL, RecipesService.class);
                break;
            case PRODUCT:
            default:
                mRecipesService = createService(RecipesService.PRODUCT_BASE_RUL, RecipesService.class);
                break;
        }
    }

    @Override
    public Observable<List<RecipeWithUser>> getRecipeInfoList(String recipeKey, int recipeType, int pageNum,
        int orderType, String updateTime) {
        JsonObject req = new JsonObject();
        req.addProperty("recipeKey", recipeKey);
        req.addProperty("pageNum", pageNum + "");
        req.addProperty("orderType", orderType + "");
        req.addProperty("recipeType", recipeType);
        req.addProperty("time", updateTime);
        return mRecipesService.getRecipeInfoList(req)
            .compose(this.<BaseEntity<List<RecipeWithUser>>, List<RecipeWithUser>>getTransformer2());
    }

    @Override
    public Observable<List<RecipeWithUser>> queryRecipe(String recipeKey, int pageNum) {
        return getRecipeInfoList(recipeKey, 1, pageNum, 1, "");
    }

    @Override
    public Observable<List<RecipeWithUser>> getRecipeInfoList(int pageNum, String updateTime) {
        return getRecipeInfoList("", 1, pageNum, 1, updateTime);
    }

    @Override
    public Observable<List<RecomRecipe>> getRecommendRecipeInfoList(int pageNum, String updateTime) {
        return getRecipeInfoList("", 2, pageNum, 1, updateTime).flatMap(
            new Func1<List<RecipeWithUser>, Observable<RecipeWithUser>>() {
                @Override
                public Observable<RecipeWithUser> call(List<RecipeWithUser> recipeWithUsers) {
                    return Observable.from(recipeWithUsers);
                }
            })  .map(new Func1<RecipeWithUser, RecomRecipe>() {
                @Override
                public RecomRecipe call(RecipeWithUser recipeWithUser) {
                    RecomRecipe recipe = new RecomRecipe();
                    recipe.setId(recipeWithUser.getId());
                    recipe.setUpdateTime(recipeWithUser.getUpdateTime());
                    recipe.setRecipeInfo(recipeWithUser.getRecipeInfo());
                    recipe.setUserInfo(recipeWithUser.getUserInfo());
                    return recipe;
                }
            }).toList();
    }

    @Override
    public Observable<RecipeData> getRecipeDetail(String id) {
        JsonObject req = new JsonObject();
        req.addProperty("recipeId", id);
        return mRecipesService.getRecipeDetail(req).compose(this.<BaseEntity<RecipeData>, RecipeData>getTransformer2());
    }

    @Override
    public Observable<List<RecipeData>> getUserPubRecipeList(String userId, String recipeKey, int state, int pageNum) {
        JsonObject req = new JsonObject();
        req.addProperty("recipeKey", recipeKey);
        req.addProperty("pageNum", pageNum + 1);
        req.addProperty("state", state + "");
        req.addProperty("userId", userId);

        return mRecipesService.getUserPubRecipeList(req)
            .compose(this.<BaseEntity<List<RecipeData>>, List<RecipeData>>getTransformer2());
    }

    @Override
    public Observable<List<RecipeData>> getUserFavRecipeList(String userId, int pageNum) {
        JsonObject req = new JsonObject();
        req.addProperty("pageNum", pageNum + 1);
        req.addProperty("userId", userId);
        return mRecipesService.getUserFavRecipeList(req)
            .compose(this.<BaseEntity<List<RecipeData>>, List<RecipeData>>getTransformer2());
    }

    @Override
    public Observable<List<RecipeData>> getUserDraftRecipeList(String userId, int pageNum) {
        JsonObject req = new JsonObject();
        req.addProperty("pageNum", pageNum + 1);
        req.addProperty("userId", userId);

        return mRecipesService.getUserDraftRecipeList(req)
            .compose(this.<BaseEntity<List<RecipeData>>, List<RecipeData>>getTransformer2());
    }

    @Override
    public Observable<List<CommentInfo>> getRecipeCommentList(String recipeId, int pageNum) {
        JsonObject req = new JsonObject();
        req.addProperty("pageNum", pageNum + 1);
        req.addProperty("recipeId", recipeId);

        return mRecipesService.getRecipeCommentList(req)
            .compose(this.<BaseEntity<List<CommentInfo>>, List<CommentInfo>>getTransformer2());
    }

    @Override
    public Observable<List<Material>> getMaterialList(int pageNum) {
        JsonObject req = new JsonObject();
        req.addProperty("pageNum", pageNum + 1);

        return mRecipesService.getMaterialList(req)
            .compose(this.<BaseEntity<List<Material>>, List<Material>>getTransformer2());
    }

    @Override
    public Observable<String> createRecipe(CreateRecipeReq recipe) {
        JsonObject req = (JsonObject) gson.toJsonTree(recipe);

        return mRecipesService.createRecipe(req)
            .compose(this.<BaseEntity<JsonObject>, JsonObject>getTransformer2())
            .map(new Func1<JsonObject, String>() {
                @Override
                public String call(JsonObject object) {
                    if (object != null && object.has("recipeId")) {
                        return object.get("recipeId").getAsString();
                    }
                    return "";
                }
            });
    }

    @Override
    public Observable<BaseResult> createRecipeStep(CreateRecipeStepReq step) {
        JsonObject req = (JsonObject) gson.toJsonTree(step);

        return mRecipesService.createRecipeStep(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<BaseResult> uploadRecipeStepPic() {
        return null;
    }

    @Override
    public Observable<List<HotKey>> getRecipeHotKey() {
        JsonObject req = new JsonObject();
        return mRecipesService.getRecipeHotKey(req)
            .compose(this.<BaseEntity<List<HotKey>>, List<HotKey>>getTransformer2());
    }

    @Override
    public Observable<List<RecomRecipe>> saveRecomRecipe(List<RecomRecipe> recipeList) {
        return null;
    }

    @Override
    public Observable<List<RecipeWithUser>> saveRecipe(List<RecipeWithUser> recipeList) {
        return null;
    }

    @Override
    public Observable<List<HotKey>> saveHotKey(List<HotKey> hotKeyList) {
        return Observable.empty();
    }
}
