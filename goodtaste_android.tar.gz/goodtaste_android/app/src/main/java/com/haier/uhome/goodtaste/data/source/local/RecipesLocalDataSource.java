package com.haier.uhome.goodtaste.data.source.local;

import android.content.Context;

import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.CommentInfo;
import com.haier.uhome.goodtaste.data.models.HotKey;
import com.haier.uhome.goodtaste.data.models.Material;
import com.haier.uhome.goodtaste.data.models.RecipeData;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser_Table;
import com.haier.uhome.goodtaste.data.models.RecomRecipe;
import com.haier.uhome.goodtaste.data.models.RecomRecipe_Table;
import com.haier.uhome.goodtaste.data.models.req.CreateRecipeReq;
import com.haier.uhome.goodtaste.data.models.req.CreateRecipeStepReq;
import com.haier.uhome.goodtaste.data.source.RecipesDataSource;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;
import com.raizlabs.android.dbflow.runtime.transaction.process.ProcessModelInfo;
import com.raizlabs.android.dbflow.runtime.transaction.process.SaveModelTransaction;
import com.raizlabs.android.dbflow.sql.language.Delete;
import com.raizlabs.android.dbflow.sql.language.SQLite;

import java.util.List;

import rx.Observable;
import rx.Subscriber;
import rx.schedulers.Schedulers;

/**
 */
public class RecipesLocalDataSource extends AbsLocalDataSource implements RecipesDataSource {
    public RecipesLocalDataSource(RxPreference preference, Context context) {
        super(preference, context);
    }

    @Override
    public Observable<List<RecipeWithUser>> getRecipeInfoList(String recipeKey, int recipeType, int pageNum,
        int orderType, String updateTime) {
        return null;
    }

    @Override
    public Observable<List<RecipeWithUser>> queryRecipe(String recipeKey, int pageNum) {
        return null;
    }

    @Override
    public Observable<List<RecipeWithUser>> getRecipeInfoList(int pageNum, String updateTime) {
        return Observable.create(new Observable.OnSubscribe<List<RecipeWithUser>>() {
            @Override
            public void call(Subscriber<? super List<RecipeWithUser>> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                final int count = 100;
                List<RecipeWithUser> recipeList = SQLite.select()
                    .from(RecipeWithUser.class)
                    .orderBy(RecipeWithUser_Table.updateTime, false)
                    .limit(count)
                    .queryList();
                subscriber.onNext(recipeList);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());

    }

    @Override
    public Observable<List<RecomRecipe>> getRecommendRecipeInfoList(final int pageNum, String updateTime) {
        return Observable.create(new Observable.OnSubscribe<List<RecomRecipe>>() {
            @Override
            public void call(Subscriber<? super List<RecomRecipe>> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                final int count = (pageNum == -100 ? 100 : 10);
                List<RecomRecipe> recipeList = SQLite.select()
                    .from(RecomRecipe.class)
                    .orderBy(RecomRecipe_Table.updateTime, false)
                    .limit(count)
                    .queryList();
                subscriber.onNext(recipeList);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());
    }

    @Override
    public Observable<RecipeData> getRecipeDetail(String id) {
        return null;
    }

    @Override
    public Observable<List<RecipeData>> getUserPubRecipeList(String userId, String recipeKey, int state, int pageNum) {
        return null;
    }

    @Override
    public Observable<List<RecipeData>> getUserFavRecipeList(String userId, int pageNum) {
        return null;
    }

    @Override
    public Observable<List<RecipeData>> getUserDraftRecipeList(String userId, int pageNum) {
        return null;
    }

    @Override
    public Observable<List<CommentInfo>> getRecipeCommentList(String recipeId, int pageNum) {
        return null;
    }

    @Override
    public Observable<List<Material>> getMaterialList(int pageNum) {
        return null;
    }

    @Override
    public Observable<String> createRecipe(CreateRecipeReq recipe) {
        return null;
    }

    @Override
    public Observable<BaseResult> createRecipeStep(CreateRecipeStepReq step) {
        return null;
    }

    @Override
    public Observable<BaseResult> uploadRecipeStepPic() {
        return null;
    }

    @Override
    public Observable<List<HotKey>> getRecipeHotKey() {
        return Observable.create(new Observable.OnSubscribe<List<HotKey>>() {
            @Override
            public void call(Subscriber<? super List<HotKey>> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                List<HotKey> hotKeys = SQLite.select().from(HotKey.class).queryList();

                subscriber.onNext(hotKeys);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());
    }

    @Override
    public Observable<List<RecomRecipe>> saveRecomRecipe(final List<RecomRecipe> recipeList) {
        return Observable.create(new Observable.OnSubscribe<List<RecomRecipe>>() {
            @Override
            public void call(Subscriber<? super List<RecomRecipe>> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                // 设置主键
                for (RecomRecipe recipe : recipeList) {
                    recipe.setId(recipe.getRecipeInfo().getRecipeId());
                    recipe.setUpdateTime(recipe.getRecipeInfo().getUpdateTime());
                }
                // 插入数据
                new SaveModelTransaction<>(ProcessModelInfo.withModels(recipeList)).onExecute();

                subscriber.onNext(recipeList);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());
    }

    @Override
    public Observable<List<RecipeWithUser>> saveRecipe(final List<RecipeWithUser> recipeList) {
        return Observable.create(new Observable.OnSubscribe<List<RecipeWithUser>>() {
            @Override
            public void call(Subscriber<? super List<RecipeWithUser>> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                // 设置主键
                for (RecipeWithUser recipe : recipeList) {
                    recipe.setId(recipe.getRecipeInfo().getRecipeId());
                    recipe.setUpdateTime(recipe.getRecipeInfo().getUpdateTime());
                }
                // 插入数据
                new SaveModelTransaction<>(ProcessModelInfo.withModels(recipeList)).onExecute();

                subscriber.onNext(recipeList);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());
    }

    @Override
    public Observable<List<HotKey>> saveHotKey(final List<HotKey> hotKeyList) {
        return Observable.create(new Observable.OnSubscribe<List<HotKey>>() {
            @Override
            public void call(Subscriber<? super List<HotKey>> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }

                Delete.table(HotKey.class);

                // 插入数据
                new SaveModelTransaction<>(ProcessModelInfo.withModels(hotKeyList)).onExecute();

                subscriber.onNext(hotKeyList);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());
    }
}
