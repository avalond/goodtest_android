package com.haier.uhome.goodtaste.actions;

import android.content.Context;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.util.SubscriptionManager;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.data.models.RecipeData;
import com.haier.uhome.goodtaste.data.source.ChefDataSource;
import com.haier.uhome.goodtaste.data.source.RecipesDataSource;
import com.haier.uhome.goodtaste.data.source.UserDataSource;

import java.util.List;

import rx.Subscriber;
import rx.Subscription;

/**
 * Created by Administrator on 2016/5/17.
 */
public class CollectionActionCreator extends BaseActionCreator implements CollectionActions {

    public CollectionActionCreator(Context context, DataManager dataManager, Dispatcher dispatcher,
                                   SubscriptionManager subscriptionManager) {
        super(context, dataManager, dispatcher, subscriptionManager);
    }

    @Override
    public void getUserCollection(String userId, int pageNum) {

        final RxAction action = newRxAction(ID_USER_COLLECTION, null);
        if (hasRxAction(action)) {
            return;
        }

        RecipesDataSource repository = mDataManager.getRecipesRepository();
        Subscription subscription = repository.getUserFavRecipeList(userId, pageNum).
                subscribe(new Subscriber<List<RecipeData>>() {
                    @Override
                    public void onCompleted() {
                    }

                    @Override
                    public void onError(Throwable e) {
                        postError(action, e);
                    }

                    @Override
                    public void onNext(List<RecipeData> recipeInfos) {
                        RxAction<List<RecipeData>> resultAction = newRxAction(ID_USER_COLLECTION, recipeInfos);
                        postRxAction(resultAction);
                    }
                });
        addRxAction(action, subscription);

    }

    @Override
    public void deleteCollection(String userId, String recipeId) {

        final RxAction action = newRxAction(ID_USER_DELETE_COLLECTION, null);
        if (hasRxAction(action)) {
            return;
        }

        ChefDataSource repository = mDataManager.getChefRepository();
        Subscription subscription = repository.uncollectRecipe(userId, recipeId).
                subscribe(new Subscriber<BaseResult>() {
                    @Override
                    public void onCompleted() {
                    }

                    @Override
                    public void onError(Throwable e) {
                        postError(action, e);
                    }

                    @Override
                    public void onNext(BaseResult recipeInfos) {
                        RxAction<BaseResult> resultAction = newRxAction(ID_USER_DELETE_COLLECTION, recipeInfos);
                        postRxAction(resultAction);
                    }
                });
        addRxAction(action, subscription);

    }
}
