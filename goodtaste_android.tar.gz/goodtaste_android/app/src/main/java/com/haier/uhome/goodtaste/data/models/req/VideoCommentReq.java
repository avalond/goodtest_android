package com.haier.uhome.goodtaste.data.models.req;

import java.io.Serializable;
import java.util.List;

/**
 * Created by dallas on 16-5-7.
 */
public class VideoCommentReq implements Serializable {
    private static final long serialVersionUID = -2306771514666378318L;

    private String fromUser;
    private String toUser;
    private String videoId;
    private String content;
    private List<ResourceInfoReq> resourceInfo;

    public String getFromUser() {
        return fromUser;
    }

    public void setFromUser(String fromUser) {
        this.fromUser = fromUser;
    }

    public String getToUser() {
        return toUser;
    }

    public void setToUser(String toUser) {
        this.toUser = toUser;
    }

    public String getVideoId() {
        return videoId;
    }

    public void setVideoId(String videoId) {
        this.videoId = videoId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public List<ResourceInfoReq> getResourceInfo() {
        return resourceInfo;
    }

    public void setResourceInfo(List<ResourceInfoReq> resourceInfo) {
        this.resourceInfo = resourceInfo;
    }
}
