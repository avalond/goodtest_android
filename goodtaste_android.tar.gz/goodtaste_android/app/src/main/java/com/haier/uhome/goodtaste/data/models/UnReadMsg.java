package com.haier.uhome.goodtaste.data.models;

/**
 * Created by dallas on 16-5-14.
 */
public class UnReadMsg {
    private MessageInfo info;
    private int count;
}
