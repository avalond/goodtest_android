package com.haier.uhome.goodtaste.data.models;

import java.io.Serializable;

/**
 * 评论
 * <br>Created by dallas on 16-5-7.
 */
public class CommentInfo implements Serializable {
    private static final long serialVersionUID = -1765507522489940621L;

    /**
     * id : 主键Id
     * userId : 回复人ID
     * userName : 回复人名称
     * content : 回复内容
     * resourceUrl  : 资源文件地址
     * createTime  : 创建时间
     * userBpic :
     */

    private String id;
    private String userId;
    private String userName;
    private String content;
    private String resourceUrl;
    private String createTime;
    private String userBpic;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getResourceUrl() {
        return resourceUrl;
    }

    public void setResourceUrl(String resourceUrl) {
        this.resourceUrl = resourceUrl;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUserBpic() {
        return userBpic;
    }

    public void setUserBpic(String userBpic) {
        this.userBpic = userBpic;
    }
}
