package com.haier.uhome.goodtaste.ui.main;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.widget.Toast;

import com.flyco.tablayout.CommonTabLayout;
import com.flyco.tablayout.listener.CustomTabEntity;
import com.flyco.tablayout.listener.OnTabSelectListener;
import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;

import java.util.ArrayList;

import butterknife.Bind;

/**
 * <p>Created by dallas on 16-4-14.
 */
public class HomeMainActivity extends BaseActivity implements OnTabSelectListener {
    public static final String TAG = HomeMainActivity.class.getSimpleName();
    @Bind(R.id.tab_layout)
    CommonTabLayout tabLayout;

    private int[] mTitles = {R.string.today_chef, R.string.food_match, R.string.find, R.string.mine};
    private int[] mIconUnSelectIds = {R.drawable.tab_home_unselect, R.drawable.tab_speech_unselect,
        R.drawable.tab_contact_unselect, R.drawable.tab_more_unselect};
    private int[] mIconSelectIds = {R.drawable.tab_home_select, R.drawable.tab_speech_select,
        R.drawable.tab_contact_select, R.drawable.tab_more_select};

    private ArrayList<Fragment> mFragments = new ArrayList<>();
    private ArrayList<CustomTabEntity> mTabEntities = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_main);
        hideToolbar();
        initTabLayout();
    }

    private void initTabLayout() {
        for (int id : mTitles) {
            mFragments.add(SampleFragment.getInstance("Fragment #" + getString(id)));
        }

        for (int i = 0; i < mTitles.length; i++) {
            String title = getString(mTitles[i]);
            mTabEntities.add(new TabEntity(title, mIconSelectIds[i], mIconUnSelectIds[i]));
        }

        tabLayout.setTabData(mTabEntities, this, R.id.fl_content, mFragments);
        tabLayout.setOnTabSelectListener(this);
        tabLayout.setCurrentTab(0);
    }

    @Override
    public void onTabSelect(int position) {
        HaierLoger.d(TAG, "tab select = " + position);
    }

    @Override
    public void onTabReselect(int position) {
    }

    @Override
    public void onRxStoresRegister() {

    }

    @Override
    public void onRxStoresUnRegister() {

    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {

    }

    @Override
    public void onRxError(RxError error) {

    }

    static class TabEntity implements CustomTabEntity {
        public String title;
        public int selectedIcon;
        public int unSelectedIcon;

        public TabEntity(String title, int selectedIcon, int unSelectedIcon) {
            this.title = title;
            this.selectedIcon = selectedIcon;
            this.unSelectedIcon = unSelectedIcon;
        }

        @Override
        public String getTabTitle() {
            return title;
        }

        @Override
        public int getTabSelectedIcon() {
            return selectedIcon;
        }

        @Override
        public int getTabUnselectedIcon() {
            return unSelectedIcon;
        }
    }
    private long firstTime = 0;
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                long secondTime = System.currentTimeMillis();
                if (secondTime - firstTime > 2000) {
                    //如果两次按键时间间隔大于2秒，则不退出
                    Toast.makeText(this, "再按一次退出程序", Toast.LENGTH_SHORT).show();
                    firstTime = secondTime;//更新firstTime
                    return true;
                } else {
                    //两次按键小于2秒时，退出应用
                    System.exit(0);
                }
                break;
            default:
                break;
        }
        return super.onKeyUp(keyCode, event);
    }
}
