package com.haier.uhome.goodtaste.actions;

import android.content.Context;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.util.SubscriptionManager;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.RewardInfo;
import com.haier.uhome.goodtaste.data.models.UserScore;
import com.haier.uhome.goodtaste.data.source.UserDataSource;

import rx.Subscriber;
import rx.Subscription;


public class GiveRewardActionsCreator extends BaseActionCreator implements GiveRewardActions {

    public GiveRewardActionsCreator(Context context, DataManager dataManager, Dispatcher dispatcher,
                                    SubscriptionManager subscriptionManager) {
        super(context, dataManager, dispatcher, subscriptionManager);
    }

    @Override
    public void findUserPoint(String userId) {
        final RxAction action = newRxAction(ID_FIND_POINT, null);
        if (hasRxAction(action)) {
            return;
        }
        UserDataSource userRepository = mDataManager.getUserRepository();
        Subscription subscribe = userRepository.findUserPoint(userId).subscribe(new Subscriber<UserScore>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(UserScore userScore) {
                RxAction<UserScore> mUserScore = newRxAction(ID_FIND_POINT, userScore);
                postRxAction(mUserScore);
            }
        });
        addRxAction(action, subscribe);
    }

    @Override
    public void rewardUser(String userId, String rewardUserId, String rewardScore) {
        final RxAction action = newRxAction(ID_RAWARD_USER, null);
        if (hasRxAction(action)) {
            return;
        }
        UserDataSource userRepository = mDataManager.getUserRepository();
        Subscription subscribe = userRepository.rewardUser(userId, rewardUserId, rewardScore).
                subscribe(new Subscriber<RewardInfo>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        postError(action, e);
                    }

                    @Override
                    public void onNext(RewardInfo rewardInfo) {
                        RxAction<RewardInfo> rewardInfoRxAction = newRxAction(ID_RAWARD_USER, rewardInfo);
                        postRxAction(rewardInfoRxAction);
                    }
                });
        addRxAction(action, subscribe);
    }
}
