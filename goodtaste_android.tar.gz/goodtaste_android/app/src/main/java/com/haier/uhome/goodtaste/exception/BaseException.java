package com.haier.uhome.goodtaste.exception;

public class BaseException extends RuntimeException {
    private static final long serialVersionUID = -5037998666583915497L;
    public String code = "error";

    public BaseException(String detailMessage) {
        super(detailMessage);
    }

    public BaseException(String detailMessage, String code) {
        super(detailMessage);
        if (code != null && "".equals(code)) {
            this.code = code;
        }
    }

    public BaseException(String detailMessage, Throwable throwable, String code) {
        super(detailMessage, throwable);
        if (code != null && "".equals(code)) {
            this.code = code;
        }
    }

    public BaseException(Throwable throwable, String code) {
        super(throwable);
        if (code != null && "".equals(code)) {
            this.code = code;
        }
    }

    public String getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        if ("error".equals(getCode())) {
            return super.getMessage();
        } else {
            return super.getMessage() + "[" + getCode() + "]";
        }
    }
}
