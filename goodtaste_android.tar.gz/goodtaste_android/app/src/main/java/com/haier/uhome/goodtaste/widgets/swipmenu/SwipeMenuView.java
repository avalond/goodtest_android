package com.haier.uhome.goodtaste.widgets.swipmenu;

import java.util.List;

import android.graphics.Color;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.haier.uhome.goodtaste.widgets.CollectionListView;
import com.haier.uhome.goodtaste.widgets.DeleteCollectionLayout;
import com.haier.uhome.goodtaste.widgets.ptr.PtrFrameLayout;

public class SwipeMenuView extends LinearLayout implements OnClickListener {

    private CollectionListView mListView;
    private DeleteCollectionLayout mLayout;
    private SwipeMenu mMenu;
    private OnSwipeItemClickListener onItemClickListener;
    private int position;

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public SwipeMenuView(SwipeMenu menu, CollectionListView listView) {
        super(menu.getContext());
        mListView = listView;
        mMenu = menu;
        List<SwipeMenuItem> items = menu.getMenuItems();
        int id = 0;
        for (SwipeMenuItem item : items) {
            addItem(item, id++);
        }
    }

    private void addItem(SwipeMenuItem item, int id) {
        LayoutParams params = new LayoutParams(item.getWidth(),
                LayoutParams.MATCH_PARENT);
        LinearLayout parent = new LinearLayout(getContext());
        parent.setId(id);
        parent.setGravity(Gravity.CENTER);
        //parent.setGravity(Gravity.CENTER_HORIZONTAL);
        parent.setOrientation(LinearLayout.VERTICAL);
        parent.setLayoutParams(params);
        parent.setBackgroundDrawable(item.getBackground());
        parent.setOnClickListener(this);
        addView(parent);

        /*if (item.getIcon() != null) {
            parent.addView(createIcon(item));
        }*/
        if (!TextUtils.isEmpty(item.getTitle())) {
            parent.addView(createDelete(item));
        }

    }

    private TextView createDelete(SwipeMenuItem item) {
        // LinearLayout.LayoutParams layoutParams = new LayoutParams
        // (LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        //layoutParams.gravity = Gravity.CENTER;
        TextView tv = new TextView(getContext());
        tv.setText(item.getTitle());
        tv.setGravity(Gravity.CENTER);
        //tv.setText("删除");
        //tv.setBackgroundColor(Color.RED);
        //tv.setGravity(TextView.TEXT_ALIGNMENT_CENTER);
        tv.setTextSize(15);
        tv.setTextColor(Color.WHITE);
        //tv.setLayoutParams(layoutParams);
        return tv;
    }

    /*private TextView createTitle(SwipeMenuItem item) {
        TextView tv = new TextView(getContext());
        tv.setText("删除");
        tv.setBackgroundColor(Color.RED);
        tv.setTextSize(15);
        tv.setTextColor(Color.WHITE);
        return tv;
    }*/

    @Override
    public void onClick(View v) {
        if (onItemClickListener != null && mLayout.isOpen()) {
            onItemClickListener.onItemClick(this, mMenu, v.getId());
        }
    }

    public OnSwipeItemClickListener getOnSwipeItemClickListener() {
        return onItemClickListener;
    }

    public void setOnSwipeItemClickListener(OnSwipeItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setLayout(DeleteCollectionLayout mLayout) {
        this.mLayout = mLayout;
    }

    public static interface OnSwipeItemClickListener {
        void onItemClick(SwipeMenuView view, SwipeMenu menu, int index);
    }
}
