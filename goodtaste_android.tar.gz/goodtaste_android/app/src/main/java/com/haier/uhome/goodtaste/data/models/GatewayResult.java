package com.haier.uhome.goodtaste.data.models;

public class GatewayResult extends BaseResult {
    private static final long serialVersionUID = -4918296160047450617L;
    /**
     * 应用的appId
     */
    private String appId;
    /**
     * 用户接入网关信息，报告接入地址
     */
    private AppAdapter appAdapter;
    /**
     * 网关接入地址（uSDK2.3版及以后版本使用）
     */
    private String agAddr;

    public GatewayResult() {}

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public AppAdapter getAppAdapter() {
        return appAdapter;
    }

    public void setAppAdapter(AppAdapter appAdapter) {
        this.appAdapter = appAdapter;
    }

    public String getAgAddr() {
        return agAddr;
    }

    public void setAgAddr(String agAddr) {
        this.agAddr = agAddr;
    }
}
