package com.haier.uhome.goodtaste.data.source;

/**
 * 设备数据源
 * <p>Created by dallas on 16-4-19.
 */
public interface DeviceDataSource {}
