package com.haier.uhome.goodtaste.data.models;

import java.io.Serializable;
import java.util.List;

/**
 * Created by sharp on 16-5-9.
 */
public class MainRefreshInfo implements Serializable {

    private static final long serialVersionUID = -1495297042083411421L;
    private List<ChefInfo> chefInfoList;
    private List<RecipeWithUser> recipeWithUserList;

    public MainRefreshInfo(List<ChefInfo> chefInfos, List<RecipeWithUser> recipeWithUsers) {

        chefInfoList = chefInfos;
        recipeWithUserList = recipeWithUsers;
    }

    public List<RecipeWithUser> getRecipeWithUserList() {
        return recipeWithUserList;
    }

    public List<ChefInfo> getChefInfoList() {
        return chefInfoList;
    }
}
