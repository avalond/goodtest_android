package com.haier.uhome.goodtaste.data;

/**
 * Created by Dallas on 2016/3/15.
 */
public final class HaierPreference {
    public static final String KEY_TOKEN = "token";
    public static final String KEY_USERID = "userId";
    public static final String REMERBER_PASSWORD = "remerber_password";
    public static final String USERNAME = "usename";
    public static final String PASSWORD = "password";
    public static final String LOGINSTATUS = "loginstatus";
    public static final String IS_FIRST_OPEN = "is_first_open";
    public static final String LOGINID ="loginId" ;
    public static final String SAVESTATUS ="savestatus" ;

}
