package com.haier.uhome.goodtaste.data.source;

import android.content.Context;

import com.haier.uhome.goodtaste.data.models.AccType;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.LoginInfo;
import com.haier.uhome.goodtaste.data.models.LoginType;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.data.models.MessageInfo_Table;
import com.haier.uhome.goodtaste.data.models.RewardInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.UserProfileType;
import com.haier.uhome.goodtaste.data.models.UserScore;
import com.haier.uhome.goodtaste.data.source.remote.AbsRemoteDataSource;
import com.haier.uhome.goodtaste.data.source.remote.AccessTokenInterceptor;
import com.haier.uhome.goodtaste.utils.AccountUtil;
import com.haier.uhome.goodtaste.utils.DateUtil;
import com.haier.uhome.goodtaste.utils.NetWorkUtils;
import com.raizlabs.android.dbflow.sql.language.SQLite;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

/**
 * <p>Created by dallas on 16-4-18.
 */
public class UserRepository implements UserDataSource {
    private final UserDataSource mLocalDataSource;
    private final UserDataSource mRemoteDataSource;
    private final Context mContext;

    public UserRepository(Context context, UserDataSource localDataSource, UserDataSource remoteDataSource) {
        mContext = context;
        mLocalDataSource = localDataSource;
        mRemoteDataSource = remoteDataSource;
    }

    @Override
    public Observable<BaseResult> register(String account, String password, String uvc, String inviteCode) {
        return mRemoteDataSource.register(account, password, uvc, inviteCode);
    }

    @Override
    public Observable<BaseResult> applyRegMsgCode(String mobile) {
        return mRemoteDataSource.applyRegMsgCode(mobile);
    }

    @Override
    public Observable<LoginInfo> login(String loginId, String password, @AccType.Type int accType,
        @LoginType.Type int loginType, String thirdPartyAppId, String thirdPartyAccessToken) {
        return mRemoteDataSource.login(loginId, password, accType, loginType, thirdPartyAppId, thirdPartyAccessToken)
            .doOnNext(new Action1<LoginInfo>() {
                @Override
                public void call(LoginInfo loginInfo) {
                    updateToken(loginInfo.getAccessToken());
                    saveAccessToken(loginInfo.getAccessToken());
                    saveUserId(loginInfo.getUserId());
                }
            });
    }

    @Override
    public Observable<LoginInfo> login(String loginId, @AccType.Type int accType, String thirdPartyAppId,
        String thirdPartyAccessToken) {
        return this.login(loginId, "password", accType, LoginType.USER_NAME, thirdPartyAppId, thirdPartyAccessToken);
    }

    @Override
    public Observable<LoginInfo> login(String loginId, String password) {
        int loginType = AccountUtil.getLoginType(loginId);
        return this.login(loginId, password, AccType.HAIER, loginType, null, null);
    }

    @Override
    public Observable<UserInfo> findUserInfoById(final String userId) {
        if (!NetWorkUtils.isNetworkAvailable(mContext)) {
            return mLocalDataSource.findUserInfoById(userId).observeOn(AndroidSchedulers.mainThread());
        }
        return mRemoteDataSource.findUserInfoById(userId).flatMap(new Func1<UserInfo, Observable<UserInfo>>() {
            @Override
            public Observable<UserInfo> call(UserInfo userInfo) {
                return saveUserInfo(userInfo);
            }
        }).onErrorResumeNext(mLocalDataSource.findUserInfoById(userId));
    }

    @Override
    public Observable<BaseResult> updateUserInfoById(String userId, @UserProfileType.Type int type, String content) {
        return mRemoteDataSource.updateUserInfoById(userId, type, content);
    }

    @Override
    public Observable<MessageInfo> sendMsgToUser(final String fromUserId, final String toUserId,
                                                 final String msg  , final String nickname, final String avter) {
        return mRemoteDataSource.sendMsgToUser(fromUserId, toUserId, msg ,nickname ,avter)
            // 指定之后的操作在IO线程
            .observeOn(Schedulers.io())
            // 保存发送私信到数据库
            .flatMap(new Func1<MessageInfo, Observable<List<MessageInfo>>>() {
                @Override
                public Observable<List<MessageInfo>> call(MessageInfo messageInfo) {
                    MessageInfo temp = SQLite.select()
                        .from(MessageInfo.class)
                        .where(MessageInfo_Table.targetUid.eq(toUserId))
                        .querySingle();
                    List<MessageInfo> list = new ArrayList<>();
                    if (temp == null){
                        temp = new MessageInfo();
                    }
                    temp.setId(messageInfo.getId());
                    temp.setAvater(avter);
                    temp.setNickName(nickname);
                    temp.setFromUid(fromUserId);
                    temp.setTargetUid(toUserId);
                    temp.setMsg(msg);
                    temp.setTime(DateUtil.getFormatDateTime(new Date().getTime()));//事件格式化下和服务器返回的一样
                    list.add(temp);

                    return saveMessageInfo(list);
                }
            }).map(new Func1<List<MessageInfo>, MessageInfo>() {
                @Override
                public MessageInfo call(List<MessageInfo> messageInfoList) {
                    return messageInfoList.get(0);
                }
            }).observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadPersonMsg(String userId) {
        return mRemoteDataSource.getUnReadPersonMsg(userId);
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadMsgState(String userId) {
        return mRemoteDataSource.getUnReadMsgState(userId);
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadMsgList(final String userId) {
        return mRemoteDataSource.getUnReadMsgList(userId)
            // 指定之后的操作在IO线程
            .observeOn(Schedulers.io())
            // 保存私信到数据库
            .flatMap(new Func1<List<MessageInfo>, Observable<List<MessageInfo>>>() {
                @Override
                public Observable<List<MessageInfo>> call(List<MessageInfo> messageInfoList) {
                    return saveMessageInfo(messageInfoList);
                }
            })
            // 从数据库中获取私信
            .flatMap(new Func1<List<MessageInfo>, Observable<List<MessageInfo>>>() {
                @Override
                public Observable<List<MessageInfo>> call(List<MessageInfo> messageInfoList) {
                    return mLocalDataSource.getUnReadMsgList(userId);
                }
            }).observeOn(AndroidSchedulers.mainThread());// 指定之后的操作在主线程
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadMsgListLocal(String userId) {
        return mLocalDataSource.getUnReadMsgListLocal(userId);
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadMsgContent(String userId, String targetUid, int maxIndex) {

        return mLocalDataSource.getUnReadMsgContent(userId, targetUid, maxIndex);
    }

    @Override
    public Observable<BaseResult> updateMsgStatus(String userId, String time) {
        return mRemoteDataSource.updateMsgStatus(userId, time);
    }

    @Override
    public Observable<List<MessageInfo>> saveMessageInfo(List<MessageInfo> messageInfoList) {
        return mLocalDataSource.saveMessageInfo(messageInfoList);
    }

    @Override
    public Observable<UserScore> findUserPoint(String userId) {
        return mRemoteDataSource.findUserPoint(userId);
    }

    @Override
    public Observable<RewardInfo> rewardUser(String userId, String rewardUserId, String rewardScore) {
        return mRemoteDataSource.rewardUser(userId, rewardUserId, rewardScore);
    }

    @Override
    public void saveAccessToken(String token) {
        mLocalDataSource.saveAccessToken(token);
    }

    @Override
    public void saveUserId(String userId) {
        mLocalDataSource.saveUserId(userId);
    }

    @Override
    public Observable<UserInfo> saveUserInfo(UserInfo userInfo) {
        return mLocalDataSource.saveUserInfo(userInfo);
    }

    private void updateToken(String token) {
        AbsRemoteDataSource remoteDataSource = (AbsRemoteDataSource) mRemoteDataSource;
        OkHttpClient httpClient = remoteDataSource.getHttpClient();
        for (Interceptor interceptor : httpClient.interceptors()) {
            if (interceptor instanceof AccessTokenInterceptor) {
                ((AccessTokenInterceptor) interceptor).updateToken(token);
                break;
            }
        }
    }
}
