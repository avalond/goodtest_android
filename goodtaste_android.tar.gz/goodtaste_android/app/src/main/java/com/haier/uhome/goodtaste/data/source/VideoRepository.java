package com.haier.uhome.goodtaste.data.source;

import android.content.Context;

import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.TopVideoInfo;
import com.haier.uhome.goodtaste.data.models.VideoCommentInfo;
import com.haier.uhome.goodtaste.data.models.VideoInfo;
import com.haier.uhome.goodtaste.data.models.req.VideoCommentReq;

import java.util.List;

import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;

public class VideoRepository implements VideoDataSource {
    private static final String TAG = VideoRepository.class.getSimpleName();
    private final VideoDataSource mLocalDataSource;
    private final VideoDataSource mRemoteDataSource;
    private final Context mContext;

    public VideoRepository(Context context, VideoDataSource localDataSource, VideoDataSource remoteDataSource) {
        mContext = context;
        mLocalDataSource = localDataSource;
        mRemoteDataSource = remoteDataSource;
    }

    @Override
    public Observable<List<TopVideoInfo>> getTopVideo(String userId, String updateTime) {
        Observable<List<TopVideoInfo>> localData = mLocalDataSource.getTopVideo(userId, updateTime)
            .observeOn(AndroidSchedulers.mainThread());

        Observable<List<TopVideoInfo>> remoteData = mRemoteDataSource.getTopVideo(userId, updateTime)
            .flatMap(new Func1<List<TopVideoInfo>, Observable<List<TopVideoInfo>>>() {
                @Override
                public Observable<List<TopVideoInfo>> call(List<TopVideoInfo> videoInfoList) {
                    return saveTopVideoInfo(videoInfoList);
                }
            });

        return Observable.concat(localData, remoteData);

    }

    @Override
    public Observable<BaseResult> postLike(String userId, String videoId) {
        return mRemoteDataSource.postLike(userId, videoId);
    }

    @Override
    public Observable<BaseResult> commentVideo(VideoCommentReq comment) {
        return mRemoteDataSource.commentVideo(comment);
    }

    @Override
    public Observable<List<VideoInfo>> getVideoList(String albumId, int pageNum) {
        return mRemoteDataSource.getVideoList(albumId, pageNum);
    }

    @Override
    public Observable<List<VideoInfo>> getVideoListByAlbumId(String albumId) {
        return mRemoteDataSource.getVideoListByAlbumId(albumId);
    }

    @Override
    public Observable<List<VideoCommentInfo>> getVideoComment(String videoId, String userId, String size) {
        return mRemoteDataSource.getVideoComment(videoId, userId, size);
    }

    @Override
    public Observable<List<VideoCommentInfo>> getMoreVideoComment(String videoId, String userId, int pageNum) {
        return mRemoteDataSource.getMoreVideoComment(videoId, userId, pageNum);
    }

    @Override
    public Observable<BaseResult> deleteVideoComment(String commentId, String videoId, String userId) {
        return mRemoteDataSource.deleteVideoComment(commentId, videoId, userId);
    }

    @Override
    public Observable<VideoInfo> getVideoInfo(String videoId) {
        return mRemoteDataSource.getVideoInfo(videoId);
    }

    @Override
    public Observable<List<TopVideoInfo>> saveTopVideoInfo(List<TopVideoInfo> videoInfoList) {
        return mLocalDataSource.saveTopVideoInfo(videoInfoList);
    }
}
