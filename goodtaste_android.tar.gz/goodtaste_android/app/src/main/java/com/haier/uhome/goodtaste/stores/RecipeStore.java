package com.haier.uhome.goodtaste.stores;

import android.content.Context;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.actions.HomePageActions;
import com.haier.uhome.goodtaste.actions.RecipeActions;
import com.haier.uhome.goodtaste.data.models.HotKey;
import com.haier.uhome.goodtaste.data.models.MainRefreshInfo;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;
import com.haier.uhome.goodtaste.data.models.RecomRecipe;

import java.util.List;

/**
 * Created by sharp on 16-5-10.
 */
public class RecipeStore extends BaseStore {

    private static RecipeStore instance;

    public synchronized static RecipeStore get(Context context) {
        if (instance == null) {
            HaierApplication app = (HaierApplication) context.getApplicationContext();
            instance = new RecipeStore(app.getRxFlux().getDispatcher());
        }
        return instance;
    }


    public static final String ID = "RecipeStore";

    private List<RecipeWithUser> recipeWithUserList;
    private List<RecomRecipe> recomRecipeList;
    private List<HotKey> hotKeyList;


    protected RecipeStore(Dispatcher dispatcher) {
        super(dispatcher);
    }

    @Override
    protected void onAction(RxAction action) {
        switch (action.getType()) {
            case HomePageActions.ID_PAGE_REFRESH:
                recipeWithUserList = ((MainRefreshInfo) action.getData()).getRecipeWithUserList();
                break;
            case HomePageActions.ID_DISH_REFRESH:
                //                recomRecipeList = (List<RecomRecipe>) action.getData();
                recipeWithUserList = (List<RecipeWithUser>) action.getData();
                break;
            case HomePageActions.ID_DISH_MORE_REFRESH:
                recipeWithUserList = (List<RecipeWithUser>) action.getData();
                break;
            case RecipeActions.ID_ALL_RECIPE://全部菜谱
                recipeWithUserList = (List<RecipeWithUser>) action.getData();
                break;
            case RecipeActions.ID_KEY_RECIPE://关键词菜谱
                recipeWithUserList = (List<RecipeWithUser>) action.getData();
                break;
            case RecipeActions.ID_HOT_KEY://关键词菜谱
                hotKeyList = (List<HotKey>) action.getData();
                break;
            default: // 重要！！！重要！！！重要！！！ 如果不需要处理那么就要忽略该事件
                return;
        }
        postStoreChange(new RxStoreChange(ID, action));
    }

    public List<RecipeWithUser> getRecipeWithUserList() {
        return recipeWithUserList;
    }

    /**
     * 推荐菜谱的获取
     *
     * @return
     */
    public List<RecomRecipe> getRecomRecipeList() {
        return recomRecipeList;
    }

    public List<HotKey> getHotKeyList() {
        return hotKeyList;
    }
}
