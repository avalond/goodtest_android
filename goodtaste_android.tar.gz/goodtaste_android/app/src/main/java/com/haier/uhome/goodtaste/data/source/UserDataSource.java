package com.haier.uhome.goodtaste.data.source;

import com.haier.uhome.goodtaste.data.models.AccType;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.LoginInfo;
import com.haier.uhome.goodtaste.data.models.LoginType;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.data.models.RewardInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.UserProfileType;
import com.haier.uhome.goodtaste.data.models.UserScore;

import java.util.List;

import rx.Observable;

/**
 * Created by lijin on 16-5-6.
 * <p/>
 * 用户数据源
 */
public interface UserDataSource {
    /**
     * 一步注册
     *
     * @param mobile     账号
     * @param password   密码
     * @param uvc        动态码
     * @param inviteCode 邀请码（可以为空）
     * @return Observable
     */
    Observable<BaseResult> register(String mobile, String password, String uvc, String inviteCode);

    /**
     * 一步注册验证码申请
     *
     * @param mobile 手机号
     * @return
     */
    Observable<BaseResult> applyRegMsgCode(String mobile);

    /**
     * @param loginId               登录用户名
     * @param password              密码
     * @param accType               用户类型 {@link AccType}
     * @param loginType             登录类型 {@link LoginType}
     * @param thirdPartyAppId       选填  第三方平台应用ID，根据第三方平台验证需要，输入具体值，可以为空。
     * @param thirdPartyAccessToken 选填  第三方平台安全令牌
     */
    Observable<LoginInfo> login(String loginId, String password, @AccType.Type int accType,
        @LoginType.Type int loginType, String thirdPartyAppId, String thirdPartyAccessToken);

    /**
     * 第三方登录
     *
     * @param loginId               登录用户名
     * @param accType               用户类型 {@link AccType}
     * @param thirdPartyAppId       第三方平台应用ID，根据第三方平台验证需要，输入具体值
     * @param thirdPartyAccessToken 第三方平台安全令牌
     */
    Observable<LoginInfo> login(String loginId, @AccType.Type int accType, String thirdPartyAppId,
        String thirdPartyAccessToken);

    /**
     * 默认是海尔官网用户登录
     *
     * @param loginId  登录用户名
     * @param password 密码
     */
    Observable<LoginInfo> login(String loginId, String password);


    /**
     * 根据用户ID获取用户相关信息
     *
     * @param userId 用户id
     * @return Observable
     */
    Observable<UserInfo> findUserInfoById(String userId);

    /**
     * 修改用户信息
     *
     * @param userId  用户id
     * @param type    1 修改昵称2 修改性别 3 修改城市 4修改简介5修改邮箱6修改电话7修改生日
     *                （当type为某种类型时，入参其它属性可以为空，json字段保持完整）
     * @param content
     * @return
     */
    Observable<BaseResult> updateUserInfoById(String userId, @UserProfileType.Type int type, String content);


    /**
     * 给好友发送私信
     *
     * @param fromUserId 发送用户ID
     * @param toUserId   接收用户ID
     * @param msg        发送消息
     * @return
     */
    Observable<MessageInfo> sendMsgToUser(String fromUserId, String toUserId, String msg ,
                                          String nickname,String avter);

    /**
     * 获取未读私信接口
     *
     * @param userId 用户ID
     * @return
     */
    Observable<List<MessageInfo>> getUnReadPersonMsg(String userId);

    /**
     * 获取未读私信状态
     *
     * @param userId 用户ID
     * @return Observable
     */
    Observable<List<MessageInfo>> getUnReadMsgState(String userId);

    /**
     * 从服务器获取未读私信列表
     *
     * @param userId 用户ID
     * @return Observable
     */
    Observable<List<MessageInfo>> getUnReadMsgList(String userId);

    /**
     * 从数据库获取未读私信列表
     *
     * @param userId 用户ID
     * @return Observable
     */
    Observable<List<MessageInfo>> getUnReadMsgListLocal(String userId);

    /**
     * 获取未读私信内容
     *
     * @param userId    用户ID
     * @param targetUid 对方用户ID
     * @return Observable
     */
    Observable<List<MessageInfo>> getUnReadMsgContent(String userId, String targetUid, int maxIndex);

    /**
     * 更新未读私信为已读
     *
     * @param userId 用户ID
     * @param time   时间
     * @return Observable
     */
    Observable<BaseResult> updateMsgStatus(String userId, String time);

    /**
     * 需要查询积分的业务在处调用此接口
     *
     * @param userId 用户ID
     * @return
     */
    Observable<UserScore> findUserPoint(String userId);

    /**
     * 当前登录用户给某个用户打赏
     *
     * @param userId       用户ID
     * @param rewardUserId 打赏userId"
     * @param rewardScore  打赏积分
     * @return
     */
    Observable<RewardInfo> rewardUser(String userId, String rewardUserId, String rewardScore);

    /**
     * 保存用户token
     *
     * @param token 用户token
     */
    void saveAccessToken(String token);

    /**
     * 保存用户ID
     *
     * @param userId 用户ID
     */
    void saveUserId(String userId);

    /**
     * 保存用户信息
     *
     * @param userInfo 用户信息
     */
    Observable<UserInfo> saveUserInfo(UserInfo userInfo);

    /**
     * 保存私信至数据库
     *
     * @param messageInfoList 私信信息列表
     * @return Observable
     */
    Observable<List<MessageInfo>> saveMessageInfo(List<MessageInfo> messageInfoList);


}
