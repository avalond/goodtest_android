package com.haier.uhome.goodtaste.data.models;

import java.io.Serializable;

/**
 * Created by Dallas on 2015/10/21.
 */
public class BaseResult implements Serializable {
    public static final String RET_OK = "00000";

    private static final long serialVersionUID = 5327787989626038942L;

    private String retCode;
    private String retInfo;

    public BaseResult() {
    }

    public BaseResult(String retCode, String retInfo) {
        this.retCode = retCode;
        this.retInfo = retInfo;
    }

    public String getRetCode() {
        return retCode;
    }

    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    public String getRetInfo() {
        return retInfo;
    }

    public void setRetInfo(String retInfo) {
        this.retInfo = retInfo;
    }

    @Override
    public String toString() {
        return "BaseResult{" +
            "retCode='" + retCode + '\'' +
            ", retInfo='" + retInfo + '\'' +
            '}';
    }
}
