package com.haier.uhome.goodtaste.data.source.remote.services;

import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.data.models.AppVersionResult;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.ResourceResult;
import com.haier.uhome.goodtaste.data.models.UvcResult;

import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import rx.Observable;

/**
 * 通用
 * <br>Created by Dallas.
 */
public interface CommonService {
    String DEBUG_BASE_URL = "http://" + BaseService.DEBUG_HOST + ":40000/commonapp/";
    String DEBUG_VERIFY_BASE_URL = "http://" + BaseService.DEBUG_VERIFY_HOST + ":40000/commonapp/";
    String PRE_PRODUCT_BASE_RUL = "http://" + BaseService.PRE_PRODUCT_HOST + ":6000/commonapp/";
    String PRODUCT_BASE_RUL = "http://" + BaseService.PRODUCT_HOST + ":6000/commonapp/";

    @GET("appVersion/{appId}/latest")
    Observable<AppVersionResult> getAppVersionInfo(@Path("appId") String appId);

    @POST("uvcs")
    Observable<UvcResult> postUserVerificationCode(@Body JsonObject req);

    @POST("uvcs/{uvc}/verify")
    Observable<BaseResult> verifyUserVerificationCode(@Path("uvc") String uvc, @Body JsonObject req);

    @POST("resources/{useType}/assignUri")
    Observable<ResourceResult> assignResource(@Path("useType") String useType, @Body JsonObject req);
}
