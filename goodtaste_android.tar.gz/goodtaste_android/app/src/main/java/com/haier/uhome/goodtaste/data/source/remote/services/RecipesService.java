package com.haier.uhome.goodtaste.data.source.remote.services;

import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.data.models.BaseEntity;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.CommentInfo;
import com.haier.uhome.goodtaste.data.models.HotKey;
import com.haier.uhome.goodtaste.data.models.Material;
import com.haier.uhome.goodtaste.data.models.RecipeData;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;

import java.util.List;

import retrofit2.http.Body;
import retrofit2.http.POST;
import rx.Observable;

/**
 * 菜谱
 */
public interface RecipesService {
    String DEBUG_BASE_URL = "http://" + BaseService.DEBUG_HOST + ":7480/";
    String DEBUG_VERIFY_BASE_URL = "http://" + BaseService.DEBUG_VERIFY_HOST + ":7480/";
    String PRE_PRODUCT_BASE_RUL = "http://" + BaseService.PRE_PRODUCT_HOST + ":7480/";
    String PRODUCT_BASE_RUL = "http://" + BaseService.PRODUCT_HOST + ":7480/";

    @POST("foodStreetData/recipe/main/findRecipeByKey")
    Observable<BaseEntity<List<RecipeWithUser>>> getRecipeInfoList(@Body JsonObject req);

    @POST("foodStreetData/recipe/main/findRecipeInfoById")
    Observable<BaseEntity<RecipeData>> getRecipeDetail(@Body JsonObject req);

    @POST("foodStreetData/recipe/main/findPubRecipeByUserId")
    Observable<BaseEntity<List<RecipeData>>> getUserPubRecipeList(@Body JsonObject req);

    @POST("foodStreetData/recipe/main/findCollRecipeByUserId")
    Observable<BaseEntity<List<RecipeData>>> getUserFavRecipeList(@Body JsonObject req);

    @POST("foodStreetData/recipe/main/findDraftRecipeByUserId")
    Observable<BaseEntity<List<RecipeData>>> getUserDraftRecipeList(@Body JsonObject req);

    @POST("foodStreetData/recipe/main/findCommRecipeById")
    Observable<BaseEntity<List<CommentInfo>>> getRecipeCommentList(@Body JsonObject req);

    @POST("foodStreetData/recipe/main/findMaterial")
    Observable<BaseEntity<List<Material>>> getMaterialList(@Body JsonObject req);

    @POST("foodStreetData/recipe/main/createRecipe")
    Observable<BaseEntity<JsonObject>> createRecipe(@Body JsonObject req);

    @POST("foodStreetData/recipe/main/createRecipeStep")
    Observable<BaseResult> createRecipeStep(@Body JsonObject req);

    @POST("foodStreetData/recipe/main/uploadRecipeStepPic")
    Observable<BaseResult> uploadRecipeStepPic(@Body JsonObject req);

    @POST("foodStreetData/recipe/main/findRecipeHotKey")
    Observable<BaseEntity<List<HotKey>>> getRecipeHotKey(@Body JsonObject req);
}
