package com.haier.uhome.goodtaste.data.source;

import android.content.Context;

import com.haier.uhome.goodtaste.data.models.AccType;
import com.haier.uhome.goodtaste.data.models.AppVersionResult;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.GatewayResult;
import com.haier.uhome.goodtaste.data.models.ResourceResult;
import com.haier.uhome.goodtaste.data.models.UvcResult;
import com.haier.uhome.goodtaste.data.models.Validate;

import java.io.File;

import rx.Observable;
import rx.functions.Func1;

/**
 * <p>Created by dallas on 16-4-18.
 */
public class CommonRepository implements CommonDataSource {
    private final CommonDataSource mLocalDataSource;
    private final CommonDataSource mRemoteDataSource;
    private final Context mContext;

    public CommonRepository(Context context, CommonDataSource localDataSource, CommonDataSource remoteDataSource) {
        mContext = context;
        mLocalDataSource = localDataSource;
        mRemoteDataSource = remoteDataSource;
    }

    @Override
    public Observable<BaseResult> logout() {
        return mRemoteDataSource.logout().flatMap(new Func1<BaseResult, Observable<BaseResult>>() {
            @Override
            public Observable<BaseResult> call(BaseResult baseResult) {
                return mLocalDataSource.logout();
            }
        });
    }

    @Override
    public Observable<GatewayResult> getDeviceGateWay(String userId, String sdkVer, String platform, String model) {
        return mRemoteDataSource.getDeviceGateWay(userId, sdkVer, platform, model);
    }

    @Override
    public Observable<AppVersionResult> getAppVersionInfo(String appId) {
        return mRemoteDataSource.getAppVersionInfo(appId);
    }

    @Override
    public Observable<UvcResult> postUserVerificationCode(String account, @Validate.Type int type,
        @Validate.Scene int scene, String sendTo, @AccType.Type int accType) {
        return mRemoteDataSource.postUserVerificationCode(account, type, scene, sendTo, accType);
    }

    @Override
    public Observable<UvcResult> postUvcMobile(String account, String mobile, @Validate.Scene int scene) {
        return mRemoteDataSource.postUvcMobile(account, mobile, scene);
    }

    @Override
    public Observable<UvcResult> postUvcEmail(String account, String email, @Validate.Scene int scene) {
        return mRemoteDataSource.postUvcEmail(account, email, scene);
    }

    @Override
    public Observable<BaseResult> verifyUserVerificationCode(String uvc, String account, @Validate.Type int type,
        @Validate.Scene int scene, String transactionId, @AccType.Type int accType) {
        return mRemoteDataSource.verifyUserVerificationCode(uvc, account, type, scene, transactionId, accType);
    }

    @Override
    public Observable<BaseResult> verifyUvcMobile(String uvc, String account, String transactionId,
        @Validate.Scene int scene) {
        return mRemoteDataSource.verifyUvcMobile(uvc, account, transactionId, scene);
    }

    @Override
    public Observable<BaseResult> verifyUvcEmail(String uvc, String account, String transactionId,
        @Validate.Scene int scene) {
        return mRemoteDataSource.verifyUvcEmail(uvc, account, transactionId, scene);
    }

    @Override
    public Observable<ResourceResult> assignResource(String useType, String id, String type, String ext, String name,
        String description) {
        return mRemoteDataSource.assignResource(useType, id, type, ext, name, description);
    }

    @Override
    public Observable<String> uploadAvatar(String userId, File file) {
        return mRemoteDataSource.uploadAvatar(userId, file);
    }
}
