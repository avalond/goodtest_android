package com.haier.uhome.goodtaste.data;

import android.content.Context;
import android.text.TextUtils;

import com.haier.uhome.goodtaste.BuildConfig;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.data.source.ChefDataSource;
import com.haier.uhome.goodtaste.data.source.ChefRepository;
import com.haier.uhome.goodtaste.data.source.CommonDataSource;
import com.haier.uhome.goodtaste.data.source.CommonRepository;
import com.haier.uhome.goodtaste.data.source.DeviceDataSource;
import com.haier.uhome.goodtaste.data.source.DeviceRepository;
import com.haier.uhome.goodtaste.data.source.RecipesDataSource;
import com.haier.uhome.goodtaste.data.source.RecipesRepository;
import com.haier.uhome.goodtaste.data.source.UserDataSource;
import com.haier.uhome.goodtaste.data.source.UserRepository;
import com.haier.uhome.goodtaste.data.source.VideoDataSource;
import com.haier.uhome.goodtaste.data.source.VideoRepository;
import com.haier.uhome.goodtaste.data.source.local.ChefLocalDataSource;
import com.haier.uhome.goodtaste.data.source.local.CommonLocalDataSource;
import com.haier.uhome.goodtaste.data.source.local.DeviceLocalDataSource;
import com.haier.uhome.goodtaste.data.source.local.RecipesLocalDataSource;
import com.haier.uhome.goodtaste.data.source.local.UserLocalDataSource;
import com.haier.uhome.goodtaste.data.source.local.VideoLocalDataSource;
import com.haier.uhome.goodtaste.data.source.remote.AbsRemoteDataSource;
import com.haier.uhome.goodtaste.data.source.remote.AccessTokenInterceptor;
import com.haier.uhome.goodtaste.data.source.remote.ChefRemoteDataSource;
import com.haier.uhome.goodtaste.data.source.remote.CommonRemoteDataSource;
import com.haier.uhome.goodtaste.data.source.remote.DeviceRemoteDataSource;
import com.haier.uhome.goodtaste.data.source.remote.HttpsTrustManager;
import com.haier.uhome.goodtaste.data.source.remote.RecipesRemoteDataSource;
import com.haier.uhome.goodtaste.data.source.remote.UserRemoteDataSource;
import com.haier.uhome.goodtaste.data.source.remote.VideoRemoteDataSource;
import com.haier.uhome.goodtaste.data.source.remote.services.H5HybirdUrl;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;
import com.haier.uhome.usdk.api.uSDKManager;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;

/**
 * Created by dallas on 16-4-18.
 */
public final class DataManager {
    private static DataManager instance;

    public synchronized static DataManager instance() {
        if (instance == null) {
            throw new RuntimeException("you must call DataManager.init(Context context) first!");
        }
        return instance;
    }

    public synchronized static DataManager init(Context context) {
        if (instance != null) {
            throw new RuntimeException("DataManager already init!");
        }
        return instance = new DataManager(context.getApplicationContext());
    }

    private Context mContext;
    private RxPreference mPreference;

    private CommonDataSource mCommonRepository;
    private UserDataSource mUserRepository;
    private ChefDataSource mChefRepository;
    private RecipesDataSource mRecipesRepository;
    private VideoDataSource mVideoRepository;
    private DeviceDataSource mDeviceRepository;

    private DataManager(Context context) {
        mContext = context;

        mPreference = new RxPreference(context);

        initRepositories(AbsRemoteDataSource.DEBUG);
    }

    public RxPreference getPreference() {
        return mPreference;
    }

    public CommonDataSource getCommonRepository() {
        return mCommonRepository;
    }

    public UserDataSource getUserRepository() {
        return mUserRepository;
    }

    public ChefDataSource getChefRepository() {
        return mChefRepository;
    }

    public RecipesDataSource getRecipesRepository() {
        return mRecipesRepository;
    }

    public VideoDataSource getVideoRepository() {
        return mVideoRepository;
    }

    public DeviceDataSource getDeviceRepository() {
        return mDeviceRepository;
    }

    private void initRepositories(@AbsRemoteDataSource.EnvironmentMode int mode) {
        OkHttpClient httpClient = createHttpClient();

        CommonDataSource commonLocalDataSource = new CommonLocalDataSource(mPreference, mContext);
        CommonDataSource commonRemoteDataSource = new CommonRemoteDataSource(mode, httpClient);
        mCommonRepository = new CommonRepository(mContext, commonLocalDataSource, commonRemoteDataSource);

        UserDataSource userLocalDataSource = new UserLocalDataSource(mPreference, mContext);
        UserDataSource userRemoteDataSource = new UserRemoteDataSource(mode, httpClient);
        mUserRepository = new UserRepository(mContext, userLocalDataSource, userRemoteDataSource);

        ChefDataSource chefLocalDataSource = new ChefLocalDataSource(mPreference, mContext);
        ChefDataSource chefRemoteDataSource = new ChefRemoteDataSource(mode, httpClient);
        mChefRepository = new ChefRepository(mContext, chefLocalDataSource, chefRemoteDataSource);

        RecipesDataSource recipesLocalDataSource = new RecipesLocalDataSource(mPreference, mContext);
        RecipesDataSource recipesRemoteDataSource = new RecipesRemoteDataSource(mode, httpClient);
        mRecipesRepository = new RecipesRepository(mContext, recipesLocalDataSource, recipesRemoteDataSource);

        VideoDataSource videoLocalDataSource = new VideoLocalDataSource(mPreference, mContext);
        VideoDataSource videoRemoteDataSource = new VideoRemoteDataSource(mode, httpClient);
        mVideoRepository = new VideoRepository(mContext, videoLocalDataSource, videoRemoteDataSource);

        DeviceDataSource deviceLocalDataSource = new DeviceLocalDataSource(mPreference, mContext);
        DeviceDataSource deviceRemoteDataSource = new DeviceRemoteDataSource(mode, httpClient);
        mDeviceRepository = new DeviceRepository(mContext, deviceLocalDataSource, deviceRemoteDataSource);

        initH5HybirdUrl(mode);
    }

    private void initH5HybirdUrl(@AbsRemoteDataSource.EnvironmentMode int mode) {
        H5HybirdUrl.init(mContext, mode);
    }

    private OkHttpClient createHttpClient() {
        Map<String, String> headers = new HashMap<>();
        headers.put("appId", getAppId());
        headers.put("appVersion", getAppVersion());
        headers.put("clientId", getClientId());
        headers.put("appKey", getAppKey());
        String token = mPreference.getString(HaierPreference.KEY_TOKEN, "");
        headers.put("accessToken", token);
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        if (BuildConfig.DEBUG) {
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        } else {
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BASIC);
        }
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.addInterceptor(new AccessTokenInterceptor(headers))
            .addInterceptor(loggingInterceptor)
            .sslSocketFactory(HttpsTrustManager.getSsLSocketFactory())
            .hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            })
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS);
        Interceptor stethoInterceptor = getStethoInterceptor();
        if (stethoInterceptor != null) {
            builder.addNetworkInterceptor(stethoInterceptor);
        }
        return builder.build();
    }

    private String getAppId() {
        return ((HaierApplication) mContext).getAppId();
    }

    private String getAppKey() {
        return ((HaierApplication) mContext).getAppKey();
    }

    private String getAppVersion() {
        return ((HaierApplication) mContext).getAppVersion();
    }

    private String getClientId() {
        return ((HaierApplication) mContext).getClientId();
    }

    private Interceptor getStethoInterceptor() {
        try {
            Class<?> cls = Class.forName("com.facebook.stetho.okhttp3.StethoInterceptor");
            return (Interceptor) cls.newInstance();
        } catch (ClassNotFoundException ignored) {
            ;// ignored
        } catch (InstantiationException ignored) {
            ;// ignored
        } catch (IllegalAccessException ignored) {
            ;// ignored
        }
        return null;
    }

}
