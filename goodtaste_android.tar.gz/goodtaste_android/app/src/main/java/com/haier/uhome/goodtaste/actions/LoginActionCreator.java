package com.haier.uhome.goodtaste.actions;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.util.SubscriptionManager;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.AccType;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.LoginInfo;
import com.haier.uhome.goodtaste.data.source.CommonDataSource;
import com.haier.uhome.goodtaste.data.source.UserDataSource;
import com.haier.uhome.goodtaste.exception.BaseException;
import com.haier.uhome.goodtaste.utils.AccountUtil;

import rx.Subscriber;
import rx.Subscription;

/**
 * Created by Administrator on 2016/5/13.
 */
public class LoginActionCreator extends BaseActionCreator implements LoginActions{
    public LoginActionCreator(Context context, DataManager dataManager,
                              Dispatcher dispatcher, SubscriptionManager subscriptionManager) {
        super(context, dataManager, dispatcher, subscriptionManager);
    }

    @Override
    public void login(final String loginId, final String password) {
        final RxAction action = newRxAction(ID_LOGIN, null);
        if (hasRxAction(action)) {
            return;
        }
        if (TextUtils.isEmpty(loginId)) {
            postError(action, new BaseException(mContext.getResources().getString(R.string.check_account)));
            return;
        }
        if (!AccountUtil.isMobileNum(loginId)) {
            postError(action, new BaseException(mContext.getString(R.string.check_account_invalid)));
            return;
        }
        if (TextUtils.isEmpty(password)) {
            postError(action, new BaseException(mContext.getResources().getString(R.string.please_input_password)));
            return;
        }

        UserDataSource repository = mDataManager.getUserRepository();
        Subscription subscription = repository.login(loginId, password).subscribe(new Subscriber<LoginInfo>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(LoginInfo loginResult) {
                Bundle data = new Bundle();
                data.putString("loginId",loginId);
                data.putSerializable("resultAction",loginResult);

                RxAction<Bundle> resultAction = newRxAction(ID_LOGIN, data);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    @Override
    public void login(String loginId, @AccType.Type int accType, String thirdPartyAppId, String thirdPartyAccessToken) {
        final RxAction action = newRxAction(ID_3RD_PARTY_LOGIN, null);
        if (hasRxAction(action)) {
            return;
        }
        UserDataSource repository = mDataManager.getUserRepository();
        Subscription subscription = repository.login(loginId, accType, thirdPartyAppId, thirdPartyAccessToken)
                .subscribe(new Subscriber<LoginInfo>() {
                    @Override
                    public void onCompleted() {
                    }

                    @Override
                    public void onError(Throwable e) {
                        postError(action, e);
                    }

                    @Override
                    public void onNext(LoginInfo loginResult) {
                        RxAction<LoginInfo> resultAction = newRxAction(ID_3RD_PARTY_LOGIN, loginResult);
                        postRxAction(resultAction);
                    }
                });
        addRxAction(action, subscription);
    }

    @Override
    public void logout() {
        final RxAction action = newRxAction(ID_LOGOUT, null);
        if (hasRxAction(action)) {
            return;
        }
        CommonDataSource repository = mDataManager.getCommonRepository();
        Subscription subscription = repository.logout().subscribe(new Subscriber<BaseResult>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(BaseResult baseResult) {
                RxAction<BaseResult> resultAction = newRxAction(ID_LOGOUT, baseResult);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    @Override
    public void savePassword(Boolean savestatus, String pwd) {
        Bundle data = new Bundle();
        data.putBoolean("savestatus", savestatus);
        data.putString("pwd", pwd);
        RxAction<Bundle> action = newRxAction(ID_SAVE_PASSWORD, data);
        //        if (hasRxAction(action)) {
        //            return;
        //        }
        postRxAction(action);
    }
}
