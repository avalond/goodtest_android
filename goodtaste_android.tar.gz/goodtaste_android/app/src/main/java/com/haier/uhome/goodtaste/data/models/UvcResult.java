package com.haier.uhome.goodtaste.data.models;

// uvc:User Verification Code
public class UvcResult extends BaseResult {
    private static final long serialVersionUID = 6750298196424736000L;

    private String transactionId;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
}
