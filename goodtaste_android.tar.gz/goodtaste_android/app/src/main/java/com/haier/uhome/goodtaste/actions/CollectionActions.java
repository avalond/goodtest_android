package com.haier.uhome.goodtaste.actions;

/**
 * Created by Administrator on 2016/5/17.
 */
public interface CollectionActions {

    String ID_USER_COLLECTION = "id_user_collection";
    String ID_USER_DELETE_COLLECTION = "id_user_delete_collection";


    void getUserCollection(String userId, int pageNum);
    void deleteCollection(String userId, String recipeId);
}
