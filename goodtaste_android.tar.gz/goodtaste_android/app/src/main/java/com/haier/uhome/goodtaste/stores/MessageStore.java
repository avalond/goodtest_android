package com.haier.uhome.goodtaste.stores;

import android.content.Context;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.actions.MessageActions;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.utils.DateUtil;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by Administrator on 2016/5/6.
 */
public class MessageStore extends BaseStore {

    private static MessageStore instance;
    private MessageInfo messageInfo;
    private String receive;
    public static final String ID = "MessageStore";

    protected MessageStore(Dispatcher dispatcher) {
        super(dispatcher);
    }

    public static MessageStore get(Context context) {
        //instance.context = context;
        if (instance == null) {
            HaierApplication app = (HaierApplication) context.getApplicationContext();
            instance = new MessageStore(app.getRxFlux().getDispatcher());
        }
        return instance;
    }

   /* public synchronized static MessageStore get(Dispatcher dispatcher) {
>>>>>>> [Feature]代码优化，个人中心部分功能实现。
        if (instance == null) {
            instance = new MessageStore(dispatcher);
        }
        return instance;
<<<<<<< HEAD
    }


    protected MessageStore(Dispatcher dispatcher) {
=======
    }*/


    /*public MessageStore(Dispatcher dispatcher) {
        super(dispatcher);
    }*/

    @Override
    protected void onAction(RxAction action) {

        switch (action.getType()) {
            case MessageActions.SEND_MESSAGE:
                messageInfo = (MessageInfo) action.getData();
               // String msgId = messageInfo.getId();
               // String msg = messageInfo.getMsg();
//                MessageInfo message = new MessageInfo("20032", msgId, msgId,
//                        DateUtil.getFormatCurrentTime(), "乐哥", "13526230630.2336");
                //messageInfo.save();
                break;
            case MessageActions.RECEIVE_MESSAGE:
                receive = (String) action.getData();
                break;
            case MessageActions.SEND_MESSAGE_SUCCESS:
                receive = (String) action.getData();
                break;
            case MessageActions.SEND_MESSAGE_ERRO:
                receive = (String) action.getData();
                break;
            case MessageActions.GET_UNREAD_MESSAGE_CURRENT:
                List<MessageInfo> list = (List<MessageInfo>) action.getData();


                break;
            default:
                return;
        }
        postStoreChange(new RxStoreChange(ID, action));

    }

}
