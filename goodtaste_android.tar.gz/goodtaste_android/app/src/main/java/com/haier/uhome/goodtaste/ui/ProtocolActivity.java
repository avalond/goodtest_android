package com.haier.uhome.goodtaste.ui;


import android.app.ActionBar;
import android.content.Context;
import android.os.Bundle;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.R;


import java.io.IOException;
import java.io.InputStream;

public class ProtocolActivity extends BaseActivity {
    public static final String ENCODING = "UTF-8";
    private static final String TAG = "ProtocolActivity";
    private TextView mTextView;
    private ActionBar mActionBar;
    private TextView mRightBtn;//ActionBar左侧按钮
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_protocol_layout);
        showToolbar();
        setToolbarTitle(getString(R.string.string_user_protocol));
        mTextView = (TextView)this.findViewById(R.id.protocol);
        mTextView.setText(getFromAssets("protoco.txt"));
    }
    @Override
    protected View createToolbarView(LayoutInflater inflater, ViewGroup container) {
        View view = super.createToolbarView(inflater, container);
        mRightBtn = (TextView) view.findViewById(R.id.toolbar_right_btn);
        mRightBtn.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        return view;
    }

  //从assets 文件夹中获取文件并读取数据
    public String getFromAssets(String fileName){
        String result = null;
        try {
            InputStream in = getResources().getAssets().open(fileName);
            //获取文件的字节数
            int lenght = in.available();
            //创建byte数组
            byte[]  buffer = new byte[lenght];
            //将文件中的数据读到byte数组中
            in.read(buffer);

            result=new String(buffer,0,buffer.length);
//            result = EncodingUtils.getString(buffer, ENCODING);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void onRxStoresRegister() {

    }

    @Override
    public void onRxStoresUnRegister() {

    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {

    }

    @Override
    public void onRxError(RxError error) {

    }
}
