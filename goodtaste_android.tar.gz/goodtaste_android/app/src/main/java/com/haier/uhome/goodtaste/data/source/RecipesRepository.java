package com.haier.uhome.goodtaste.data.source;

import android.content.Context;

import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.CommentInfo;
import com.haier.uhome.goodtaste.data.models.HotKey;
import com.haier.uhome.goodtaste.data.models.Material;
import com.haier.uhome.goodtaste.data.models.RecipeData;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;
import com.haier.uhome.goodtaste.data.models.RecomRecipe;
import com.haier.uhome.goodtaste.data.models.req.CreateRecipeReq;
import com.haier.uhome.goodtaste.data.models.req.CreateRecipeStepReq;
import com.haier.uhome.goodtaste.utils.NetWorkUtils;

import java.util.List;

import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

/**
 * Created by lijin on 16-5-7.
 */
public class RecipesRepository implements RecipesDataSource {
    private final RecipesDataSource mLocalDataSource;
    private final RecipesDataSource mRemoteDataSource;
    private final Context mContext;

    public RecipesRepository(Context context, RecipesDataSource localDataSource, RecipesDataSource remoteDataSource) {
        mContext = context;
        mLocalDataSource = localDataSource;
        mRemoteDataSource = remoteDataSource;
    }

    @Override
    public Observable<List<RecipeWithUser>> getRecipeInfoList(String recipeKey, int recipeType, int pageNum,
        int orderType, String updateTime) {
        return mRemoteDataSource.getRecipeInfoList(recipeKey, recipeType, pageNum, orderType != 1 ? 1 : orderType,
            updateTime);
    }

    @Override
    public Observable<List<RecipeWithUser>> queryRecipe(String recipeKey, int pageNum) {
        return mRemoteDataSource.queryRecipe(recipeKey, pageNum);
    }

    @Override
    public Observable<List<RecipeWithUser>> getRecipeInfoList(int pageNum, String updateTime) {
        // 菜谱获取逻辑：
        // 1、如果网络访问无效并且是获取第一页数据，则从数据库获取(默认获取最新的100条数据)
        if (pageNum == 1 && !NetWorkUtils.isNetworkAvailable(mContext)) {
            return mLocalDataSource.getRecipeInfoList(pageNum, updateTime)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
        }
        // 2、其他情况则无脑从服务器获取，如果获取成功则保存至数据库
        return mRemoteDataSource.getRecipeInfoList(pageNum, updateTime)
            .observeOn(Schedulers.io())
            .flatMap(new Func1<List<RecipeWithUser>, Observable<List<RecipeWithUser>>>() {
                @Override
                public Observable<List<RecipeWithUser>> call(List<RecipeWithUser> recipeWithUsers) {
                    return saveRecipe(recipeWithUsers);
                }
            })
            .observeOn(AndroidSchedulers.mainThread()); // 发送数据至主线程;
    }

    @Override
    public Observable<List<RecomRecipe>> getRecommendRecipeInfoList(int pageNum, String updateTime) {
        // 推荐菜谱获取逻辑：
        // 1、 如果是获取第一页数据
        if (pageNum == 1) {
            // 1.1、 如果网络无效，则从数据库获取(默认获取最新的100条数据)
            if (!NetWorkUtils.isNetworkAvailable(mContext)) {
                // 参数pageNum=-100，表示获取最新的100条数据。
                return mLocalDataSource.getRecommendRecipeInfoList(-100, updateTime)
                    .observeOn(AndroidSchedulers.mainThread());
            }
            Observable<List<RecomRecipe>> localData = mLocalDataSource.getRecommendRecipeInfoList(pageNum, updateTime)
                .observeOn(AndroidSchedulers.mainThread());
            Observable<List<RecomRecipe>> remoteData = mRemoteDataSource.getRecommendRecipeInfoList(pageNum, updateTime)
                .flatMap(new Func1<List<RecomRecipe>, Observable<List<RecomRecipe>>>() {
                    @Override
                    public Observable<List<RecomRecipe>> call(List<RecomRecipe> recipeList) {
                        return saveRecomRecipe(recipeList);
                    }
                })
                .observeOn(AndroidSchedulers.mainThread()); // 发送数据至主线程
            // 1.2、 如果网络有效，先从从数据库获取(默认获取最新的10条数据)， 然后从服务器获取。
            return Observable.concat(localData, remoteData);
        }
        // 2、其他情况则无脑从服务器获取，如果获取成功则保存至数据库
        return mRemoteDataSource.getRecommendRecipeInfoList(pageNum, updateTime)
            .observeOn(Schedulers.io()) // 指定flatMap运行在IO线程
            .flatMap(new Func1<List<RecomRecipe>, Observable<List<RecomRecipe>>>() {
                @Override
                public Observable<List<RecomRecipe>> call(List<RecomRecipe> recipeList) {
                    return saveRecomRecipe(recipeList);
                }
            })
            .observeOn(AndroidSchedulers.mainThread()); // 发送数据至主线程
    }

    @Override
    public Observable<RecipeData> getRecipeDetail(String id) {
        return mRemoteDataSource.getRecipeDetail(id);
    }

    @Override
    public Observable<List<RecipeData>> getUserPubRecipeList(String userId, String recipeKey, int state, int pageNum) {
        return mRemoteDataSource.getUserPubRecipeList(userId, recipeKey, state, pageNum);
    }

    @Override
    public Observable<List<RecipeData>> getUserFavRecipeList(String userId, int pageNum) {
        return mRemoteDataSource.getUserFavRecipeList(userId, pageNum);
    }

    @Override
    public Observable<List<RecipeData>> getUserDraftRecipeList(String userId, int pageNum) {
        return mRemoteDataSource.getUserDraftRecipeList(userId, pageNum);
    }

    @Override
    public Observable<List<CommentInfo>> getRecipeCommentList(String recipeId, int pageNum) {
        return mRemoteDataSource.getRecipeCommentList(recipeId, pageNum);
    }

    @Override
    public Observable<List<Material>> getMaterialList(int pageNum) {
        return mRemoteDataSource.getMaterialList(pageNum);
    }

    @Override
    public Observable<String> createRecipe(CreateRecipeReq recipe) {
        return mRemoteDataSource.createRecipe(recipe);
    }

    @Override
    public Observable<BaseResult> createRecipeStep(CreateRecipeStepReq step) {
        return mRemoteDataSource.createRecipeStep(step);
    }

    @Override
    public Observable<BaseResult> uploadRecipeStepPic() {
        return mRemoteDataSource.uploadRecipeStepPic();
    }


    @Override
    public Observable<List<HotKey>> getRecipeHotKey() {
        final Observable<List<HotKey>> localData = mLocalDataSource.getRecipeHotKey();
        Observable<List<HotKey>> remoteData = mRemoteDataSource.getRecipeHotKey()
            .flatMap(new Func1<List<HotKey>, Observable<List<HotKey>>>() {
                @Override
                public Observable<List<HotKey>> call(List<HotKey> hotKeys) {
                    return saveHotKey(hotKeys);
                }
            });
        return Observable.concat(localData, remoteData);
    }

    @Override
    public Observable<List<RecomRecipe>> saveRecomRecipe(List<RecomRecipe> recipeList) {
        return mLocalDataSource.saveRecomRecipe(recipeList);
    }

    @Override
    public Observable<List<RecipeWithUser>> saveRecipe(List<RecipeWithUser> recipeList) {
        return mLocalDataSource.saveRecipe(recipeList);
    }

    @Override
    public Observable<List<HotKey>> saveHotKey(List<HotKey> hotKeyList) {
        return mLocalDataSource.saveHotKey(hotKeyList);
    }
}
