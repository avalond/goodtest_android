package com.haier.uhome.goodtaste.widgets.pickerview.view;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import android.content.Context;
import android.view.View;

import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.widgets.pickerview.TimePickerView.Type;
import com.haier.uhome.goodtaste.widgets.pickerview.adapter.NumericWheelAdapter;
import com.haier.uhome.goodtaste.widgets.pickerview.lib.WheelView;
import com.haier.uhome.goodtaste.widgets.pickerview.listener.OnItemSelectedListener;


public class WheelTime {
    public static DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    private View view;
    private WheelView wheelView;
    private WheelView wvMonth;
    private WheelView wvDay;
    private WheelView wvHours;
    private WheelView wvMins;

    private Type type;
    public static final int DEFULT_START_YEAR = 1990;
    public static final int DEFULT_END_YEAR = 2100;
    private int startYear = DEFULT_START_YEAR;
    private int endYear = DEFULT_END_YEAR;


    public WheelTime(View view) {
        super();
        this.view = view;
        type = Type.ALL;
        setView(view);
    }

    public WheelTime(View view, Type type) {
        super();
        this.view = view;
        this.type = type;
        setView(view);
    }

    public void setPicker(int year, int month, int day) {
        this.setPicker(year, month, day, 0, 0);
    }

    /**
     * @Description: TODO 弹出日期时间选择器
     */
    public void setPicker(int year, int month, int day, int h, int m) {
        // 添加大小月月份并将其转换为list,方便之后的判断
        String[] monthsBig = {"1", "3", "5", "7", "8", "10", "12"};
        String[] monthsLittle = {"4", "6", "9", "11"};

        final List<String> listBig = Arrays.asList(monthsBig);
        final List<String> listLittle = Arrays.asList(monthsLittle);

        Context context = view.getContext();
        // 年
        wheelView = (WheelView) view.findViewById(R.id.year);
        wheelView.setAdapter(new NumericWheelAdapter(startYear, endYear));// 设置"年"的显示数据
        wheelView.setLabel(context.getString(R.string.pickerview_year));// 添加文字
        wheelView.setCurrentItem(year - startYear);// 初始化时显示的数据

        // 月
        wvMonth = (WheelView) view.findViewById(R.id.month);
        wvMonth.setAdapter(new NumericWheelAdapter(1, 12));
        wvMonth.setLabel(context.getString(R.string.pickerview_month));
        wvMonth.setCurrentItem(month);

        // 日
        wvDay = (WheelView) view.findViewById(R.id.day);
        // 判断大小月及是否闰年,用来确定"日"的数据
        if (listBig.contains(String.valueOf(month + 1))) {
            wvDay.setAdapter(new NumericWheelAdapter(1, 31));
        } else if (listLittle.contains(String.valueOf(month + 1))) {
            wvDay.setAdapter(new NumericWheelAdapter(1, 30));
        } else {
            // 闰年
            if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
                wvDay.setAdapter(new NumericWheelAdapter(1, 29));
            } else {
                wvDay.setAdapter(new NumericWheelAdapter(1, 28));
            }
        }
        wvDay.setLabel(context.getString(R.string.pickerview_day));
        wvDay.setCurrentItem(day - 1);


        wvHours = (WheelView) view.findViewById(R.id.hour);
        wvHours.setAdapter(new NumericWheelAdapter(0, 23));
        wvHours.setLabel(context.getString(R.string.pickerview_hours));// 添加文字
        wvHours.setCurrentItem(h);

        wvMins = (WheelView) view.findViewById(R.id.min);
        wvMins.setAdapter(new NumericWheelAdapter(0, 59));
        wvMins.setLabel(context.getString(R.string.pickerview_minutes));// 添加文字
        wvMins.setCurrentItem(m);

        // 添加"年"监听
        OnItemSelectedListener wheelListenerYear = new OnItemSelectedListener() {
            @Override
            public void onItemSelected(int index) {
                int yearNum = index + startYear;
                // 判断大小月及是否闰年,用来确定"日"的数据
                int maxItem = 30;
                if (listBig
                        .contains(String.valueOf(wvMonth.getCurrentItem() + 1))) {
                    wvDay.setAdapter(new NumericWheelAdapter(1, 31));
                    maxItem = 31;
                } else if (listLittle.contains(String.valueOf(wvMonth
                        .getCurrentItem() + 1))) {
                    wvDay.setAdapter(new NumericWheelAdapter(1, 30));
                    maxItem = 30;
                } else {
                    if ((yearNum % 4 == 0 && yearNum % 100 != 0)
                            || yearNum % 400 == 0) {
                        wvDay.setAdapter(new NumericWheelAdapter(1, 29));
                        maxItem = 29;
                    } else {
                        wvDay.setAdapter(new NumericWheelAdapter(1, 28));
                        maxItem = 28;
                    }
                }
                if (wvDay.getCurrentItem() > maxItem - 1) {
                    wvDay.setCurrentItem(maxItem - 1);
                }
            }
        };
        // 添加"月"监听
        OnItemSelectedListener wheelListenerMonth = new OnItemSelectedListener() {
            @Override
            public void onItemSelected(int index) {
                int monthNum = index + 1;
                int maxItem = 30;
                // 判断大小月及是否闰年,用来确定"日"的数据
                if (listBig.contains(String.valueOf(monthNum))) {
                    wvDay.setAdapter(new NumericWheelAdapter(1, 31));
                    maxItem = 31;
                } else if (listLittle.contains(String.valueOf(monthNum))) {
                    wvDay.setAdapter(new NumericWheelAdapter(1, 30));
                    maxItem = 30;
                } else {
                    if (((wheelView.getCurrentItem() + startYear) % 4 == 0 && (wheelView
                            .getCurrentItem() + startYear) % 100 != 0)
                            || (wheelView.getCurrentItem() + startYear) % 400 == 0) {
                        wvDay.setAdapter(new NumericWheelAdapter(1, 29));
                        maxItem = 29;
                    } else {
                        wvDay.setAdapter(new NumericWheelAdapter(1, 28));
                        maxItem = 28;
                    }
                }
                if (wvDay.getCurrentItem() > maxItem - 1) {
                    wvDay.setCurrentItem(maxItem - 1);
                }

            }
        };
        wheelView.setOnItemSelectedListener(wheelListenerYear);
        wvMonth.setOnItemSelectedListener(wheelListenerMonth);

        // 根据屏幕密度来指定选择器字体的大小(不同屏幕可能不同)
        int textSize = 6;
        switch (type) {
            case ALL:
                textSize = textSize * 3;
                break;
            case YEAR_MONTH_DAY:
                textSize = textSize * 3;
                wvHours.setVisibility(View.GONE);
                wvMins.setVisibility(View.GONE);
                break;
            case HOURS_MINS:
                textSize = textSize * 3;
                wheelView.setVisibility(View.GONE);
                wvMonth.setVisibility(View.GONE);
                wvDay.setVisibility(View.GONE);
                break;
            case MONTH_DAY_HOUR_MIN:
                textSize = textSize * 3;
                wheelView.setVisibility(View.GONE);
                break;
            case YEAR_MONTH:
                textSize = textSize * 3;
                wvDay.setVisibility(View.GONE);
                wvHours.setVisibility(View.GONE);
                wvMins.setVisibility(View.GONE);
                break;
            default:
                return;
        }
        wvDay.setTextSize(textSize);
        wvMonth.setTextSize(textSize);
        wheelView.setTextSize(textSize);
        wvHours.setTextSize(textSize);
        wvMins.setTextSize(textSize);

    }

    /**
     * 设置是否循环滚动
     *
     * @param cyclic
     */
    public void setCyclic(boolean cyclic) {
        wheelView.setCyclic(cyclic);
        wvMonth.setCyclic(cyclic);
        wvDay.setCyclic(cyclic);
        wvHours.setCyclic(cyclic);
        wvMins.setCyclic(cyclic);
    }

    public String getTime() {
        StringBuffer sb = new StringBuffer();
        sb.append((wheelView.getCurrentItem() + startYear)).append("-")
                .append((wvMonth.getCurrentItem() + 1)).append("-")
                .append((wvDay.getCurrentItem() + 1)).append(" ")
                .append(wvHours.getCurrentItem()).append(":")
                .append(wvMins.getCurrentItem());
        return sb.toString();
    }

    public View getView() {
        return view;
    }

    public void setView(View view) {
        this.view = view;
    }

    public int getStartYear() {
        return startYear;
    }

    public void setStartYear(int startYear) {
        this.startYear = startYear;
    }

    public int getEndYear() {
        return endYear;
    }

    public void setEndYear(int endYear) {
        this.endYear = endYear;
    }
}
