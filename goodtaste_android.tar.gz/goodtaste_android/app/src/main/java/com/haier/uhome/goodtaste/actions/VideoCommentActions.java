package com.haier.uhome.goodtaste.actions;

import com.haier.uhome.goodtaste.data.models.req.VideoCommentReq;

import java.net.URI;

/**
 * Created by Administrator on 2016/5/6.
 */
public interface VideoCommentActions {
    String ID_FIVE_MESSAGE = "five_message"; //五条信息
    String ID_SEND = "user_send";//发送内容的ID
    String ID_ALL_COMMENT = "all_message";//全部评论
    String ID_SEND_FAIL = "send_fail";//失败
    String ID_SEND_SUCCEE = "send_success";//成功
    String ID_VIDEO_MORE = "video_more";//更多视频
    String ID_VIDEO_INFO = "video_info";//视频信息
    String ID_LIKE = "like";//点赞
    String ID_COMMENT_VIDEO = "ommentvideo";//视频评论
    String ID_MORE_VIDEO_COMMENT = "more_video_comment";//根据当前的视频ID获取当前视频的全部评论信息
    String ID_VIDEO_LIST_BY_ALBUMID ="video_list_by_albumid";//获取相关视频的
    String ID_DELE_VIDEO_ITEM = "dele_video_item";//删除
    /**
     * 发送消息
     * @param message 信息的内容
     * @param fromUserId  用户ID
     * @param toUserId  发送消息的ID
     */
    void send(String fromUserId,String toUserId,String message);
    /**
     * 获取视频评论的首5条数据
     *
     * @param userId  用户ID
     * @param videoId 视频ID
     */
    void videoComment(String userId, String videoId,String size);

    /**
     * 获取视频信息
     *
     * @param videoId 视频ID
     */
    void videoInfo(String videoId);

    /**
     * 获取当前视频的全部评论信息
     * @param videoId 视频ID
     * @param userId  用户ID
     * @param pageNum 展示数据页数
     */
    void moreVideoComment(String videoId, String userId, int pageNum);

    /**
     * 获取更多视频信息
     *
     * @param userId  用户ID
     * @param videoId 视频ID
     */
    void videoMoreComment(String userId, String videoId);

    /**
     * 查看点赞数量
     *
     * @param userId  用户ID
     * @param videoId 视频ID
     */
    void postLike(String userId, String videoId);

    /**
     * 视频评论
     * @param comment 评论信息
     */
    void commentVideo(VideoCommentReq comment);

    /**
     * 获取相关视频的方法
     * @param albumId
     */
    void videoListByAlbumId(String albumId);

    /**
     * 删除视频评论
     * @param videoId  视屏ID
     * @param userId   用户ID
     */
    void deleteVideoComment(String videoId, String userId);
}
