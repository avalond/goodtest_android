package com.haier.uhome.goodtaste.actions;

/**
 * Created by Administrator on 2016/5/8.
 */
public interface DirectMessageActions {

    public String ID_GETUNREAD_MESSAGE = "id_unread_message";
    public String ID_UNREAD_SAVE_MESSAGE_LIST = "id_unread_save_message_list";
    public String ID_UNREAD_MESSAGE_STATUS = "id_unread_message_status";
    public String ID_REMAVE_STATUS = "id_remave_status";
    public String ID_UPDATA_MESSAGE_STATUS = "id_updata_message_status";

    /**
     * 将未读消息标记为已读
     * @param userid
     */
    void updateMsgStatus(String userid , String time);

    /**
     * 获取未读消息联系人，及对应的消息个数
     * @param userid
     */
    void getUnReadMessStatus(String userid);

    /**
     * 从服务器获取未读私信列表
     * @param userid
     */
    void getUnReadMessageList(final String userid);

    /**
     * 移除本地保存的状态
     * @param targetid
     */
    void removeSp(String targetid);


}
