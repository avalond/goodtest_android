package com.haier.uhome.goodtaste.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by dallas on 15/11/16.
 */
public class BitmapUtil {
    /**
     * 解析图片
     *
     * @param imageFile 图片文件
     * @param reqWidth  要解析图片的宽度
     * @param reqHeight 要解析图片的高度
     * @return Bitmap
     */
    public static Bitmap decodeBitmap(File imageFile, int reqWidth, int reqHeight) {
        // 第一次解析将inJustDecodeBounds设置为true，来获取图片大小
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(imageFile.getPath(), options);
        // 调用上面定义的方法计算inSampleSize值
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        // 使用获取到的inSampleSize值再次解析图片
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(imageFile.getPath(), options);
    }

    /**
     * 解析图片
     *
     * @param res        资源句柄
     * @param imageResId 图片资源id
     * @param reqWidth   要解析图片的宽度
     * @param reqHeight  要解析图片的高度
     * @return Bitmap
     */
    public static Bitmap decodeBitmap(Resources res, int imageResId, int reqWidth, int reqHeight) {
        // 第一次解析将inJustDecodeBounds设置为true，来获取图片大小
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(res, imageResId, options);
        // 调用上面定义的方法计算inSampleSize值
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        // 使用获取到的inSampleSize值再次解析图片
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(res, imageResId, options);
    }

    /**
     * 根据传入的宽和高，计算出合适的inSampleSize值
     *
     * @param options   options
     * @param reqWidth  要解析图片的宽度
     * @param reqHeight 要解析图片的高度
     * @return Size
     */
    public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // 源图片的高度和宽度
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            // 计算出实际宽高和目标宽高的比率
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);
            // 选择宽和高中最小的比率作为inSampleSize的值，这样可以保证最终图片的宽和高
            // 一定都会大于等于目标的宽和高。
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }
        return inSampleSize;
    }

    /**
     * 保存图片
     *
     * @param bitmap  位图
     * @param format  保存格式
     * @param quality 保存质量
     * @param path    路径
     * @param name    名字
     * @return 图片文件
     */
    public static File saveBitmap(Bitmap bitmap, Bitmap.CompressFormat format, int quality, String path, String name) {
        File f = new File(path, name);
        if (f.exists()) {
            f.delete();
        }
        try {
            FileOutputStream out = new FileOutputStream(f);
            bitmap.compress(format, quality, out);
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return f;
    }

    /**
     * 保存图片，默认格式为JPEG， 质量为60.
     *
     * @param bitmap 位图
     * @param path   路径
     * @param name   名字
     * @return 图片文件
     */
    public static File saveBitmap(Bitmap bitmap, String path, String name) {
        return saveBitmap(bitmap, Bitmap.CompressFormat.JPEG, 60, path, name);
    }

    /**
     * 获取图片缓存的路径
     *
     * @param context {@link Context}
     * @return 缓存的路径
     */
    public static File getImageCacheDir(Context context) {
        File dir = new File(context.getApplicationContext().getCacheDir(), "Images");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }
}
