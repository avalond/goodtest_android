package com.haier.uhome.goodtaste.data.models;

import com.google.gson.annotations.SerializedName;
import com.haier.uhome.goodtaste.data.source.local.GoodTasteDataBase;
import com.raizlabs.android.dbflow.annotation.ColumnIgnore;
import com.raizlabs.android.dbflow.annotation.ModelContainer;
import com.raizlabs.android.dbflow.annotation.OneToMany;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.sql.language.SQLite;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.io.Serializable;
import java.util.List;

/**
 * 菜谱信息
 * <br>Created by dallas on 16-5-7.
 */
@ModelContainer
@Table(database = GoodTasteDataBase.class, allFields = true)
public class RecipeData extends BaseModel implements Serializable {

    private static final long serialVersionUID = -2240614374570678368L;
    /**
     * id : ”主键Id”
     * recipeId : 菜谱ID
     * subject  : 长标题
     * title  : 短标题
     * message  : 菜谱介绍
     * level  : 难度
     * during  : 用时
     * cuisine  : 口味
     * technics  : 工艺
     * cookers  : 厨具
     * mainIngredient  : 材料汇总
     * tips  : 小贴士
     * path  : 菜谱原图路径
     * picName  : 菜谱原图片名称
     * supportNumber : 点赞数
     * favoriteNumber : 收藏数
     * replyNumber : 回复数/评论数
     * shareNumber : 分享数
     * clickCount : 点击数/浏览量
     * recomNumber : 推荐度
     * “ingredients” :
     * “steps” :
     */

    private String id;
    @PrimaryKey
    private String recipeId;
    private String uid;
    private String title;
    private String level;
    private String during;
    private String cuisine;
    private String tips;
    private String path;
    @SerializedName("picname")
    private String picName;
    private String pic ;
    private String subject;
    private String message;
    private String technics;
    private String cookers;
    @SerializedName("mainingredient")
    private String mainIngredient;
    private String supportNumber;
    private String favoriteNumber;
    private String replyNumber;
    private String shareNumber;
    private String clickCount;
    private String recomNumber;
    @SerializedName("dateline")
    private String updateTime;

    @ColumnIgnore
    List<Ingredients> ingredients;

    @ColumnIgnore
    List<RecipeStep> steps;

    private boolean isPraise = false;

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRecipeId() {
        return recipeId;
    }

    public void setRecipeId(String recipeId) {
        this.recipeId = recipeId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getDuring() {
        return during;
    }

    public void setDuring(String during) {
        this.during = during;
    }

    public String getCuisine() {
        return cuisine;
    }

    public void setCuisine(String cuisine) {
        this.cuisine = cuisine;
    }

    public String getTechnics() {
        return technics;
    }

    public void setTechnics(String technics) {
        this.technics = technics;
    }

    public String getCookers() {
        return cookers;
    }

    public void setCookers(String cookers) {
        this.cookers = cookers;
    }

    public String getMainIngredient() {
        return mainIngredient;
    }

    public void setMainIngredient(String mainIngredient) {
        this.mainIngredient = mainIngredient;
    }

    public String getTips() {
        return tips;
    }

    public void setTips(String tips) {
        this.tips = tips;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getPicName() {
        return picName;
    }

    public void setPicName(String picName) {
        this.picName = picName;
    }

    public String getSupportNumber() {
        return supportNumber;
    }

    public void setSupportNumber(String supportNumber) {
        this.supportNumber = supportNumber;
    }

    public String getFavoriteNumber() {
        return favoriteNumber;
    }

    public void setFavoriteNumber(String favoriteNumber) {
        this.favoriteNumber = favoriteNumber;
    }

    public String getReplyNumber() {
        return replyNumber;
    }

    public void setReplyNumber(String replyNumber) {
        this.replyNumber = replyNumber;
    }

    public String getShareNumber() {
        return shareNumber;
    }

    public void setShareNumber(String shareNumber) {
        this.shareNumber = shareNumber;
    }

    public String getClickCount() {
        return clickCount;
    }

    public void setClickCount(String clickCount) {
        this.clickCount = clickCount;
    }

    public String getRecomNumber() {
        return recomNumber;
    }

    public void setRecomNumber(String recomNumber) {
        this.recomNumber = recomNumber;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    @OneToMany(methods = {OneToMany.Method.SAVE, OneToMany.Method.DELETE}, variableName = "ingredients")
    public List<Ingredients> getIngredients() {
        if (ingredients == null || ingredients.isEmpty()) {
            ingredients = SQLite.select()
                .from(Ingredients.class)
                .where(Ingredients_Table.recipeDataForeignKeyContainer_recipeId.eq(id))
                .queryList();
        }
        return ingredients;
    }

    public void setIngredients(List<Ingredients> ingredients) {
        this.ingredients = ingredients;
    }

    @OneToMany(methods = {OneToMany.Method.SAVE, OneToMany.Method.DELETE}, variableName = "steps")
    public List<RecipeStep> getSteps() {
        if (steps == null || steps.isEmpty()) {
            steps = SQLite.select()
                .from(RecipeStep.class)
                .where(RecipeStep_Table.recipeDataForeignKeyContainer_recipeId.eq(id))
                .queryList();
        }
        return steps;
    }


    public void setSteps(List<RecipeStep> steps) {
        this.steps = steps;
    }

    public boolean getIsPraise() {
        return isPraise;
    }

    public void setIsPraise(boolean isPraise) {
        this.isPraise = isPraise;
    }
}
