package com.haier.uhome.goodtaste.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.data.HaierPreference;
import com.haier.uhome.goodtaste.ui.BaseFragment;
import com.haier.uhome.goodtaste.ui.login.LoginActivity;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;

import butterknife.ButterKnife;
import butterknife.OnClick;


public class SampleFragment extends BaseFragment {
    private String mTitle;
    private RxPreference mPreference;


    public static SampleFragment getInstance(String title) {
        SampleFragment sf = new SampleFragment();
        sf.mTitle = title;
        return sf;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_sample, null);
        TextView cardTitleTv = (TextView) v.findViewById(R.id.fragment_title);
        cardTitleTv.setText(mTitle);
        ButterKnife.bind(this, v);
        mPreference = new RxPreference(getActivity());
        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }


    @Override
    public void onRxStoresRegister() {

    }

    @Override
    public void onRxStoresUnRegister() {

    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {


    }

    @Override
    public void onRxError(RxError error) {

    }


}