package com.haier.uhome.goodtaste.data.source.remote.services;

/**
 * 设备
 *
 * Created by lijin on 16-5-7.
 */
public interface DeviceService {
    String DEBUG_BASE_URL = "http://" + BaseService.DEBUG_HOST + ":7260/";
    String DEBUG_VERIFY_BASE_URL = "http://" + BaseService.DEBUG_VERIFY_HOST + ":7260/";
    String PRE_PRODUCT_BASE_RUL = "http://" + BaseService.PRE_PRODUCT_HOST + ":7260/";
    String PRODUCT_BASE_RUL = "http://" + BaseService.PRODUCT_HOST + ":7260/";
}
