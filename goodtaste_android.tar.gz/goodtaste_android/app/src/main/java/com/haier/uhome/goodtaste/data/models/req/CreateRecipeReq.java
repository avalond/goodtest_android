package com.haier.uhome.goodtaste.data.models.req;

import java.io.Serializable;

/**
 * 创建菜谱参数
 * <br>Created by dallas on 16-5-7.
 */
public class CreateRecipeReq implements Serializable {
    private static final long serialVersionUID = 9142084670129189159L;

    /**
     * recipeId : 菜谱ID
     * recipeName : 菜谱名称
     * recipeMessage : 菜谱介绍
     * userId : 用户ID
     * level : 难度
     * during : 用时
     * imgUrl : 菜谱效果图
     * cuisine  : 口味
     */

    private String recipeId;
    private String recipeName;
    private String recipeMessage;
    private String userId;
    private String level;
    private String during;
    private String imgUrl;
    private String cuisine;

    public String getRecipeId() {
        return recipeId;
    }

    public void setRecipeId(String recipeId) {
        this.recipeId = recipeId;
    }

    public String getRecipeName() {
        return recipeName;
    }

    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    public String getRecipeMessage() {
        return recipeMessage;
    }

    public void setRecipeMessage(String recipeMessage) {
        this.recipeMessage = recipeMessage;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getDuring() {
        return during;
    }

    public void setDuring(String during) {
        this.during = during;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getCuisine() {
        return cuisine;
    }

    public void setCuisine(String cuisine) {
        this.cuisine = cuisine;
    }
}
