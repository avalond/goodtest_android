package com.haier.uhome.goodtaste.ui.register;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.actions.UserActionCreator;
import com.haier.uhome.goodtaste.actions.UserActions;
import com.haier.uhome.goodtaste.stores.BaseStore;
import com.haier.uhome.goodtaste.stores.UserRegisStore;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.ui.ProtocolActivity;
import com.haier.uhome.goodtaste.ui.login.LoginActivity;
import com.haier.uhome.goodtaste.utils.AccountUtil;
import com.haier.uhome.goodtaste.widgets.ImageEditText;
import com.haier.uhome.goodtaste.utils.ErrorHandler;

import java.lang.ref.WeakReference;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by Administrator on 2016/4/28.
 */
public class RegisterActivity extends BaseActivity implements View.OnClickListener,
        CompoundButton.OnCheckedChangeListener {

    @Bind(R.id.et_mobile)
    ImageEditText etMobile;
    @Bind(R.id.et_verify)
    ImageEditText etVerify;
    @Bind(R.id.et_repassword)
    ImageEditText etRepassword;
    @Bind(R.id.readme)
    TextView mReadme;
    @Bind(R.id.btn_regis)
    Button btnRegis;
    @Bind(R.id.verify_time1)
    Button verifyTime;
    @Bind(R.id.regis_password_nosee)
    ImageView pwNosee;
    @Bind(R.id.cb_Remember)
    CheckBox cbRember;

    private UserActionCreator mUserActionCreator;
    private UserRegisStore regisStore;
    private String account;
    private String verifynum;
    private String password;
    private String mSendText = "秒后重发";
    int num=60;
    private static final int GET_TIME = 1;
    private  Boolean noPw=true;
    private  Boolean verifystatus=true;
    private TextView mLeftBack;//ActionBar左侧按钮
    private TextView mRightBtn;//ActionBar左侧按钮
    private MyCountTimer mTimer;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regis);
        hideToolbar();

        initViews();
        showToolbar();
        setToolbarDividerEnable(true);
        setToolbarTitle(getString(R.string.regis_btn));
        mUserActionCreator = getApp().getUserActionCreator();
        btnRegis.setEnabled(false);
        verifyTime.setText(getString(R.string.verify_btntext));
        etMobile.addTextChangedListener(textWatcher);
        etMobile.addTextChangedListener(textWatcher1);
        etRepassword.addTextChangedListener(textWatcher);
        etVerify.addTextChangedListener(textWatcher);
        mTimer = new MyCountTimer(61000, 1000, verifyTime, R.string.reverify_btntext);
        cbRember.setOnCheckedChangeListener(this);
        btnRegis.setBackgroundResource(R.drawable.red_button_pressed);
        verifyTime.setEnabled(false);
        verifyTime.setOnClickListener(this);
    }

    @Override
    protected View createToolbarView(LayoutInflater inflater, ViewGroup container) {
        View view = super.createToolbarView(inflater, container);
        mLeftBack = (TextView) view.findViewById(R.id.toolbar_left_btn);
        mLeftBack.setCompoundDrawablesWithIntrinsicBounds(R.drawable.back_icon, 0, 0, 0);
        mRightBtn = (TextView) view.findViewById(R.id.toolbar_right_btn);
        mRightBtn.setVisibility(View.INVISIBLE);
//        mRightBtn.setText(R.string.login_btn);
//        mRightBtn.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
//        mRightBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
//                finish();
//            }
//        });
        return view;
    }
    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void onTextChanged(CharSequence text, int arg1, int arg2, int arg3) {
            if (etRepassword.getText().length() > 5 && etMobile.getText().length() == 11 &&
                    AccountUtil.isMobileNum(etMobile.getText().toString())&&
                    etVerify.getText().length() == 6&& cbRember.isChecked()) {
                btnRegis.setEnabled(true);
                btnRegis.setBackgroundResource(R.drawable.red_button_normal);

            }
        }

        @Override
        public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
        }
        @Override
        public void afterTextChanged(Editable arg0) {
        }
    };
    private TextWatcher textWatcher1 = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence text, int arg1, int arg2, int arg3) {
            if (etMobile.getText().length() == 11 &&
                    AccountUtil.isMobileNum(etMobile.getText().toString())&&verifystatus) {
                verifyTime.setEnabled(true);
                verifyTime.setBackgroundResource(R.drawable.red_verify_normal);
            } else  {
                verifyTime.setEnabled(false);
                verifyTime.setBackgroundResource(R.drawable.post_verify_ing);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }

    };

    @Override
    public void onRxStoresRegister() {
        regisStore = UserRegisStore.get(this);
        regisStore.register();
    }

    @Override
    public void onRxStoresUnRegister() {
        regisStore.unregister();
    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {
        switch (change.getStoreId()){

            case BaseStore.ID_SHOW_LOADING:
                break;
            case BaseStore.ID_STOP_LOADING:
                break;
            case UserRegisStore.ID:
                switch (change.getRxAction().getType()) {
                    case UserActions.ID_POST_UVC_MOBILE:
                        Boolean postSucceed = regisStore.postSucceed();
                        if (postSucceed) {
                            Toast.makeText(this, getString(R.string.verifynum_succeed),Toast.LENGTH_LONG).show();
//                          num = 60;
//                          handler.sendEmptyMessage(GET_TIME);
                            mTimer.start();
                            verifyTime.setBackgroundResource(R.drawable.post_verify_ing);
                        }
                        break;
                    case UserActions.ID_REGISTER:
                        Boolean succeed = regisStore.isVerifySucceed();
                        if(succeed){
                            stopProgressDialog();
                            showToast(R.string.regis_success);
                            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                            finish();
                        }
                        break;

                    default:
                        break;
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onRxError(RxError error) {
        stopProgressDialog();
        showToast(ErrorHandler.handelError(error.getThrowable(), this));
    }

    private void initViews() {
        initReadme(mReadme);
    }

    @Override
    public void onClick(View v) {
        account = etMobile.getText().toString();
        mUserActionCreator.postUvcMobile(account, "", "");
    }


    @OnClick(R.id.regis_password_nosee)
    public void seePassword(){
        if(noPw){
            pwNosee.setImageResource(R.drawable.password_see);
            // 显示为普通文本
            etRepassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            noPw=false;
            initPw();
        }else{
            //显示为密码
            etRepassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            pwNosee.setImageResource(R.drawable.password_nosee);
            noPw=true;
            initPw();
        }
    }
    private void initPw(){
        etRepassword.setCompoundDrawablesWithIntrinsicBounds(
                getResources().getDrawable(R.drawable.regis_password_icon),
                null, null, null);
    }
    @OnClick(R.id.btn_regis)
    public void onRegis(){
        account = etMobile.getText().toString();
        verifynum = etVerify.getText().toString();
        password = etRepassword.getText().toString();
        if(AccountUtil.isLetterDigit(password)) {
            showProgressDialog(getString(R.string.regis_btning));
            mUserActionCreator.register(account, password, verifynum);
        }else{
            Toast.makeText(this,getString(R.string.passwordtype_error),Toast.LENGTH_LONG).show();
        }
    }

    private void initReadme(TextView textView) {
        SpannableString readme = new SpannableString(this.getResources().getString(R.string.readme_register));
        textView.setHighlightColor(getResources().getColor(android.R.color.transparent));
        readme.setSpan(new ForegroundColorSpan(Color.RED), 7, 17, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        readme.setSpan(new ClickableSpan() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(RegisterActivity.this, ProtocolActivity.class);
                RegisterActivity.this.startActivity(intent);
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setUnderlineText(false);
            }
        }, 7, 17, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(readme);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if(etRepassword.getText().length() > 5 && etMobile.getText().length() == 11 &&
                AccountUtil.isMobileNum(etMobile.getText().toString())&&
                etVerify.getText().length() == 6&&isChecked){
            btnRegis.setEnabled(true);
            btnRegis.setBackgroundResource(R.drawable.red_button_normal);
        } else {
            btnRegis.setEnabled(false);
            btnRegis.setBackgroundResource(R.drawable.red_button_pressed);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mTimer.cancel();
    }

    public class MyCountTimer extends CountDownTimer {
        public static final int TIME_COUNT = 61000;//时间防止从61s开始显示
        private TextView btn;
        private int endStrRid;

        /**
         * 参数 millisInFuture         倒计时总时间
         * 参数 countDownInterval    渐变时间（每次倒计1s）
         * 参数 endStrRid   倒计时结束后，按钮对应显示的文字
         */
        public MyCountTimer (long millisInFuture, long countDownInterval, Button btn, int endStrRid) {
            super(millisInFuture, countDownInterval);
            this.btn = btn;
            this.endStrRid = endStrRid;
        }

        /**
         *参数上面有注释
         */
        public  MyCountTimer (TextView btn, int endStrRid) {
            super(TIME_COUNT, 1000);
            this.btn = btn;
            this.endStrRid = endStrRid;
        }

        public MyCountTimer (TextView btn) {
            super(TIME_COUNT, 1000);
            this.btn = btn;
            this.endStrRid = R.string.reverify_btntext;
        }


        // 计时完毕时触发
        @Override
        public void onFinish() {
            btn.setTextColor(getResources().getColor(R.color.red));
            btn.setText(endStrRid);
            verifystatus=true;
            btn.setEnabled(true);
            btn.setBackgroundResource(R.drawable.red_verify_normal);
        }

        // 计时过程显示
        @Override
        public void onTick(long millisUntilFinished) {
            btn.setTextColor(getResources().getColor(R.color.home_header_frame_bar_bg));
            btn.setEnabled(false);
            verifystatus=false;
            btn.setBackgroundResource(R.drawable.post_verify_ing);
            btn.setText(millisUntilFinished / 1000 + getString(R.string.reverify_text));

        }
    }

//    final Handler handler = new Handler() {
//        public void handleMessage(Message msg) { // handle message
//            switch (msg.what) {
//                case GET_TIME:
//                    if (num == 60) {
//                        verifyTime.setEnabled(false);
//                    }
//                    num--;
//                    verifyTime.setText("" + num + mSendText);
//                    verifyTime.setTextColor(getResources().getColor(R.color.home_header_frame_bar_bg));
//                    if (num > 0) {// 输入验证码
//                        Message message = handler.obtainMessage(GET_TIME);
//                        handler.sendMessageDelayed(message, 1000);
//                    } else {
//                        // 重新获取
//                        verifyTime.setText(R.string.reverify_btntext);
//                        verifyTime.setTextColor(getResources().getColor(R.color.red));
//                        if (etMobile.getText().length() == 11 &&
//                                AccountUtil.isMobileNum(etMobile.getText().toString())) {
//                            verifyTime.setEnabled(true);
//                            verifyTime.setBackgroundResource(R.drawable.red_verify_normal);
//                        } else {
//                            verifyTime.setEnabled(false);
//                            verifyTime.setBackgroundResource(R.drawable.post_verify_ing);
//                        }
//                    }
//                    break;
//                default:
//                    break;
//            }
//
//            super.handleMessage(msg);
//        }
//    };
}
