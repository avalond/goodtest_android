package com.haier.uhome.goodtaste.data.models;

/**
 * Created by sharp on 16-5-6.
 */
public class CookerStarVideoItem extends Item {



}
