package com.haier.uhome.goodtaste.data.models;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * 海尔用户类型
 * <br>Created by Dallas on 2015/10/21.
 */
public final class AccType {
    @IntDef({HAIER, QQ, WEI_XIN, SINA, DOU_BAN, REN_REN, BAI_DU, ALI, JD, WEI_XIN_GZ, UHOME})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Type {}

    public static final int HAIER = 0;//海尔官网
    public static final int QQ = 1;//QQ
    public static final int WEI_XIN = 2;//微信
    public static final int SINA = 3;//新浪
    public static final int DOU_BAN = 4;//豆瓣
    public static final int REN_REN = 5;//人人
    public static final int BAI_DU = 8;//百度
    public static final int ALI = 9;//阿里
    public static final int JD = 10;//京东
    public static final int WEI_XIN_GZ = 11;//微信公众
    public static final int UHOME = 99;//UHome

}
