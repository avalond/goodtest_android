package com.haier.uhome.goodtaste.data.source.remote.services;

import android.content.Context;

import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.data.source.remote.AbsRemoteDataSource;
import com.haier.uhome.goodtaste.stores.UserStore;

/**
 * Created by lijin on 16-5-21.
 */
public class H5HybirdUrl implements BaseService {
    private static final String DEBUG_BASE_URL = "http://" + BaseService.DEBUG_HOST + ":8140/";
    private static final String DEBUG_VERIFY_BASE_URL = "http://" + BaseService.DEBUG_VERIFY_HOST + ":8140/";
    private static final String PRE_PRODUCT_BASE_RUL = "http://" + BaseService.PRE_PRODUCT_HOST + ":8140/";
    private static final String PRODUCT_BASE_RUL = "http://" + BaseService.PRODUCT_HOST + ":8140/";

    private static Context mContext;
    private static H5HybirdUrl instance;
    private static int mMode;

    public synchronized static H5HybirdUrl init(Context context, @AbsRemoteDataSource.EnvironmentMode int mode) {
        mMode = mode;
        if (instance != null) {
            throw new RuntimeException("DataManager already init!");
        }
        return instance = new H5HybirdUrl(context.getApplicationContext());
    }

    public synchronized static H5HybirdUrl instance() {
        if (instance == null) {
            throw new RuntimeException("you must call DataManager.init(Context context) first!");
        }
        return instance;
    }

    private H5HybirdUrl(Context context) {
        mContext = context;
    }

    private static String getBaseUrl() {
        String mode = "";
        switch (mMode) {
            case AbsRemoteDataSource.DEBUG:
                mode = DEBUG_BASE_URL;
                break;
            case AbsRemoteDataSource.DEBUG_VERIFY:
                mode = DEBUG_VERIFY_BASE_URL;
                break;
            case AbsRemoteDataSource.PRE_PRODUCT:
                mode = PRE_PRODUCT_BASE_RUL;
                break;
            case AbsRemoteDataSource.PRODUCT:
            default:
                mode = PRODUCT_BASE_RUL;
                break;
        }
        return mode;
    }

    /**
     * APP调用菜谱详情页页入口
     *
     * @param recipeId
     * @param userId
     * @return
     */
    public static String getDishDetailH5Url(String recipeId, String userId) {
        return getBaseUrl() + "foodStreetCms/H5/web/foodStreet/" +
            "recipeDetail/index.html?recipeId=" + recipeId + "&usrId=" + userId + getCommonParam();
    }

    /**
     * APP调用厨咖主页入口
     *
     * @param cookerId
     * @param userId
     * @return
     */
    public static String getCookerPersonalH5Url(String cookerId, String userId) {
        return getBaseUrl() + "foodStreetCms/H5/web/foodStreet/cookerPersonal/index.html?" +
            "cookerId=" + cookerId + "&usrId=" + userId + getCommonParam();
    }

    /**
     * APP调用厨咖列表入口
     *
     * @param userId
     * @return
     */
    public static String getCookersH5Url(String userId) {
        return getBaseUrl() + "foodStreetCms/H5/web/foodStreet/cookerList/index.html?usrId=" + userId +
            getCommonParam();
    }

    /**
     * 视频报名页入口
     *
     * @param userId
     * @return
     */
    public static String getSignUpH5Url(String userId) {
        return getBaseUrl() + "foodStreetCms/H5/web/foodStreet/signUp/index.html?userid=" + userId + getCommonParam();
    }

    /**
     * APP调用查询关注列表入口
     *
     * @param cookerId
     * @param userId
     * @return
     */
    public static String getSocialH5Url(String cookerId, String userId) {
        return getBaseUrl() + "foodStreetCms/H5/web/foodStreet/socialList/index.html?" +
            "userType=follow" + "&usrId=" + userId + "&cookerId=" + cookerId + getCommonParam();
    }

    /**
     * APP调用查询粉丝列表入口
     *
     * @param cookerId
     * @param userId
     * @return
     */
    public static String getSocialFanH5Url(String cookerId, String userId) {
        return getBaseUrl() + "foodStreetCms/H5/web/foodStreet/socialList/index.html?" +
            "userType=fan" + "&usrId=" + userId + "&cookerId=" + cookerId + getCommonParam();
    }

    /**
     * 获取邀请好友链接
     * @return
     */
    public static String getInviteShareH5Url() {
        return getBaseUrl() + "foodStreetCms/shareHtmlUploadFile/download/fs_download.html";
    }


    private static String getCommonParam() {
        HaierApplication app = ((HaierApplication) mContext);
        return "&appId=" + app.getAppId() + "&appVersion=" + app.getAppVersion() + "&clientId=" + app.getClientId() +
            "&accessToken=" + UserStore.get(mContext).getAccessToken() + "&appKey=" + app.getAppKey();
    }

}
