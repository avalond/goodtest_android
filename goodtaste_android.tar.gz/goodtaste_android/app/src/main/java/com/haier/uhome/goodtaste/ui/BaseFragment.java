package com.haier.uhome.goodtaste.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

import com.gmail.adffice.rxflux.RxFlux;
import com.gmail.adffice.rxflux.dispatcher.RxViewDispatch;
import com.gmail.adffice.rxflux.store.RxStoresRegister;

public abstract class BaseFragment extends Fragment implements RxStoresRegister, RxViewDispatch {
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        onRxStoresRegister();
        // 因为Fragment会多次创建，所以先取消注册StoreChange，再注册。这样保证注册StoreChange是最新的实例
        RxFlux.instance().getDispatcher().unRegisterRxStoreChanged(this);
        RxFlux.instance().getDispatcher().registerRxStoreChanged(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        RxFlux.instance().getDispatcher().registerRxStoreChanged(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        RxFlux.instance().getDispatcher().unRegisterRxStoreChanged(this);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        onRxStoresUnRegister();
    }


}