package com.haier.uhome.goodtaste.ui;

import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.annotation.Nullable;
import android.support.annotation.StyleableRes;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.gmail.adffice.rxflux.RxFlux;
import com.gmail.adffice.rxflux.dispatcher.RxViewDispatch;
import com.gmail.adffice.rxflux.store.RxStoresRegister;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.widgets.ProgressDialog;

import butterknife.ButterKnife;

/**
 * <p>Created by dallas on 16-4-12.
 */
public abstract class BaseActivity extends AppCompatActivity implements RxViewDispatch, RxStoresRegister {
    protected View mRootView;
    protected View mContentView;
    private LayoutInflater mInflater;
    protected Toolbar mToolbar;
    protected ProgressDialog mProgressDialog;

    /**
     * 两个属性
     * 1、toolbar是否悬浮在窗口之上
     * 2、toolbar的高度获取
     */
    private static final int[] ATTRS = {R.attr.windowActionBarOverlay, R.attr.actionBarSize};

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mInflater = LayoutInflater.from(this);
        mProgressDialog = new ProgressDialog(this, R.style.AppTheme_ProgressDialog);
        mProgressDialog.setCanceledOnTouchOutside(false);

        // 先调用子类Store的注册方法，以保证Action能够及时被Store类接收到。
        onRxStoresRegister();
        // 注册StoreChanged事件，以保证StoreChanged事件及时发送到UI层。
        RxFlux.instance().getDispatcher().registerRxStoreChanged(this);
    }

    @Override
    public void setContentView(@LayoutRes int layoutResID) {
        mRootView = initRootView(layoutResID);
        super.setContentView(mRootView);
        ButterKnife.bind(this);
    }

    @Override
    public void setContentView(View view) {
        mRootView = initRootView(view);
        super.setContentView(mRootView);
        ButterKnife.bind(this);
    }

    @Override
    public void setContentView(View view, ViewGroup.LayoutParams params) {
        mRootView = initRootView(view);
        super.setContentView(mRootView, params);
        ButterKnife.bind(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 再次注册StoreChanged事件，以保证StoreChanged事件在页面返回时能够被注册上。
        RxFlux.instance().getDispatcher().registerRxStoreChanged(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 取消注册StoreChanged事件
        RxFlux.instance().getDispatcher().unRegisterRxStoreChanged(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public void onRxStoresUnRegister() {

    }

    public HaierApplication getApp() {
        return (HaierApplication) this.getApplication();
    }

    /**
     * 显示进度框
     *
     * @param message        提示信息
     * @param cancelListener 取消进度框监听器(当cancelable==true, 会调用)
     * @param cancelable     进度框是否可取消
     */
    public void showProgressDialog(String message, DialogInterface.OnCancelListener cancelListener,
        boolean cancelable) {
        if (mProgressDialog.isShowing()) {
            return;
        }
        if (cancelListener != null) {
            mProgressDialog.setOnCancelListener(cancelListener);
        }
        mProgressDialog.setCancelable(cancelable);
        mProgressDialog.setMessage(message);
        mProgressDialog.show();
    }

    /**
     * 显示进度框
     *
     * @param message    提示信息
     * @param cancelable 进度框是否可取消
     */
    public void showProgressDialog(String message, boolean cancelable) {
        showProgressDialog(message, null, cancelable);
    }

    /**
     * 显示进度框
     *
     * @param message 提示信息
     */
    public void showProgressDialog(String message) {
        showProgressDialog(message, false);
    }

    /**
     * 显示进度框
     */
    public void showProgressDialog() {
        showProgressDialog("");
    }

    /**
     * 停止显示进度框
     */
    public void stopProgressDialog() {
        if (mProgressDialog.isShowing()) {
            mProgressDialog.cancel();
        }
    }

    /**
     * 显示Toast
     *
     * @param message 提示信息
     */
    public void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    /**
     * 显示Toast
     *
     * @param messageId 提示信息资源ID
     */
    public void showToast(int messageId) {
        Toast.makeText(this, messageId, Toast.LENGTH_SHORT).show();
    }


    protected View getContentView() {
        return mContentView;
    }

    protected View getRootView() {
        return mRootView;
    }

    /**
     * 隐藏toolbar
     */
    protected void hideToolbar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
    }

    /**
     * 显示toolbar
     */
    protected void showToolbar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.show();
        }
    }

    /**
     * toolbar是否显示
     */
    protected boolean isToolbarShowing() {
        ActionBar actionBar = getSupportActionBar();
        return actionBar != null && actionBar.isShowing();
    }

    /**
     * Toolbar左侧按钮点击事件（默认退出当前页面）
     *
     * @param v view
     */
    protected void onToolbarLeftButtonClicked(View v) {
        finish();
    }

    /**
     * Toolbar右侧按钮点击事件
     *
     * @param v view
     */
    protected void onToolbarRightButtonClicked(View v) {

    }

    /**
     * 设置toolbar标题
     *
     * @param title 标题
     */
    protected void setToolbarTitle(String title) {
        if (mToolbar != null) {
            TextView titleView = (TextView) mToolbar.findViewById(R.id.toolbar_title);
            titleView.setText(title);
        }
    }

    /**
     * 设置toolbar的分割线是否有效， 默认有效。
     *
     * @param enable 分割线是否有效
     */
    protected void setToolbarDividerEnable(boolean enable) {
        if (mToolbar != null) {
            View divider = mToolbar.findViewById(R.id.toolbar_divider_line);
            if (enable) {
                divider.setVisibility(View.VISIBLE);
            } else {
                divider.setVisibility(View.GONE);
            }
        }
    }

    /**
     * 创建toolbar
     *
     * @param inflater  inflater
     * @param container container
     * @return 创建toolbar, 如果返回null则不显示toolbar
     */
    protected View createToolbarView(LayoutInflater inflater, ViewGroup container) {
        View view = inflater.inflate(R.layout.layout_toolbar, container);
        view.findViewById(R.id.toolbar_left_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onToolbarLeftButtonClicked(v);
            }
        });
        view.findViewById(R.id.toolbar_right_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onToolbarRightButtonClicked(v);
            }
        });
        return view;
    }

    private View initRootView(View contentView) {
        /*直接创建一个相对布局，作为视图容器的父容器*/
        RelativeLayout rootView = new RelativeLayout(this);
        rootView.setLayoutParams(
            new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rootView.setFitsSystemWindows(true);

        /*实际的内容布局*/
        mContentView = contentView;
        RelativeLayout.LayoutParams contentLayoutParams = new RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        /*通过inflater获取toolbar的布局文件*/
        View toolbarLayout = createToolbarView(mInflater, null);
        if (toolbarLayout != null) {
            TypedArray typedArray = getTheme().obtainStyledAttributes(ATTRS);
            /*获取主题中定义的悬浮标志*/
            boolean overly = typedArray.getBoolean(0, false);
            /*获取主题中定义的toolbar的高度*/
            @StyleableRes int index = 1;
            int toolBarSize = (int) typedArray.getDimension(index,
                (int) getResources().getDimension(R.dimen.action_bar_default_height));
            typedArray.recycle();

            if (!overly) {
                contentLayoutParams.addRule(RelativeLayout.BELOW, toolbarLayout.getId());
            }
            rootView.addView(mContentView, contentLayoutParams);
            RelativeLayout.LayoutParams toolbarLayoutParams = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, toolBarSize);
            rootView.addView(toolbarLayout, toolbarLayoutParams);

            mToolbar = (Toolbar) toolbarLayout.findViewById(R.id.toolbar);
            if (mToolbar != null) {
                setSupportActionBar(mToolbar);
            }
        } else {
            rootView.addView(mContentView, contentLayoutParams);
        }
        return rootView;
    }

    private View initRootView(@LayoutRes int contentViewResID) {
        return initRootView(mInflater.inflate(contentViewResID, null));
    }


}
