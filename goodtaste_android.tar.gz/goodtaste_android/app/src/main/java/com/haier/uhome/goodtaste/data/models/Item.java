/**
 * Created by sharp on 16-5-5.
 */

package com.haier.uhome.goodtaste.data.models;

public abstract class Item {
}
