package com.haier.uhome.goodtaste.utils;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;

import java.util.List;

public class GetPacketRunning {

    public static boolean isRunningForeground(Context mContext) {
        String packageName = getPackageName(mContext);
        String topActivityClassName = getTopActivityName(mContext);
        return (packageName != null && topActivityClassName != null
                && topActivityClassName.startsWith(packageName));

    }

    public static String getTopActivityName(Context context) {
        String topActivityClassName = null;
        if (context != null) {
            ActivityManager activityManager = (ActivityManager) (context
                .getSystemService(Context.ACTIVITY_SERVICE));
            List<RunningTaskInfo> runningTaskInfos = activityManager
                .getRunningTasks(1);
            if (runningTaskInfos != null) {
                ComponentName f = runningTaskInfos.get(0).topActivity;
                topActivityClassName = f.getClassName();
            }
        }
        return topActivityClassName;
    }

    public static String getPackageName(Context context) {
        String packageName = null;
        if (context != null) {
            packageName = context.getPackageName();
        }
        return packageName;
    }

}
