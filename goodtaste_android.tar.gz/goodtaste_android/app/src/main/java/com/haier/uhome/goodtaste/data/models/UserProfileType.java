package com.haier.uhome.goodtaste.data.models;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * 修改用户属性类型
 */
public final class UserProfileType {
    @IntDef({NIKE_NAME, SEX, CITY, ABOUT, EMAIL, PHONE, BIRTHDAY, AVATAR})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Type {}

    public static final int NIKE_NAME = 1;
    public static final int SEX = 2;
    public static final int CITY = 3;
    public static final int ABOUT = 4;
    public static final int EMAIL = 5;
    public static final int PHONE = 6;
    public static final int BIRTHDAY = 7;

    public static final int AVATAR = 99;

}
