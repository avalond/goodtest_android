package com.haier.uhome.goodtaste.utils;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;


public final class DateUtil implements Serializable {

    private static final long serialVersionUID = -3098985139095632110L;
    public static final String DEFAULT_FORMAT_STRING = "yyyy-MM-dd HH:mm:ss";

    private DateUtil() {
    }

    /**
     * 取得给定字符串描述的日期对象，描述模式采用pattern指定的格式.
     *
     * @param dateStr 日期字串
     * @param pattern 日期模式
     * @return 给定字符串描述的日期对象。
     */
    public static Date getDateFromString(String dateStr, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.getDefault());
        Date resDate = null;
        try {
            resDate = sdf.parse(dateStr);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resDate;
    }


    /**
     * 格式化日期显示格式为默认显示格式：yyyy-MM-dd HH:mm:ss
     *
     * @param originalDate   原始日期
     * @param originalFormat 原始日期格式
     * @return 格式化后的日期显示, 如果格式话失败则返回原始日期字串
     */
    public static String dateFormat(String originalDate, String originalFormat) {
        return dateFormat(originalDate, originalFormat, DEFAULT_FORMAT_STRING);
    }

    /**
     * 格式化日期显示格式
     *
     * @param originalDate 原始日期格式
     * @param format       格式化后日期格式
     * @return 格式化后的日期显示
     */
    /**
     * 格式化日期显示格式
     *
     * @param originalDate   原始日期
     * @param originalFormat 原始日期格式
     * @param destFormat     格式化后日期格式
     * @return 格式化后的日期显示, 如果格式话失败则返回原始日期字串
     */
    public static String dateFormat(String originalDate, String originalFormat, String destFormat) {
        if (originalFormat != null && destFormat != null) {
            if (originalFormat.equals(destFormat)) {
                return originalDate;
            }

            SimpleDateFormat formatter = new SimpleDateFormat(originalFormat, Locale.getDefault());
            try {
                // 先根据原始格式化字串格式化时间
                Date oriDate = formatter.parse(originalDate);
                // 创建目标格式化对象
                formatter = new SimpleDateFormat(destFormat, Locale.getDefault());
                // 将原始时间格式化成目标格式化类型时间
                return formatter.format(oriDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return originalDate;
    }

    /**
     * 返回给定时间字符串。
     * <p>
     * 格式：yyyy-MM-dd HH:mm:ss
     *
     * @return String 格式：yyyy-MM-dd HH:mm:ss的日期字符串.
     */
    public static String getFormatCurrentTime() {
        return getFormatCurrentTime(DEFAULT_FORMAT_STRING);
    }

    /**
     * 根据给定的格式，返回时间字符串。
     * <p>
     * 格式参照类描绘中说明.
     *
     * @param format 日期格式字符串
     * @return String 指定格式的日期字符串.
     */
    public static String getFormatCurrentTime(String format) {
        return getFormatDateTime(new Date(), format);
    }

    /**
     * 根据给定的格式与时间(毫秒数)，返回时间字符串
     * <p>
     * 格式：yyyy-MM-dd HH:mm:ss
     *
     * @param microsecond 指定日期的毫秒数
     * @return 格式：yyyy-MM-dd HH:mm:ss的日期字符串.
     */
    public static String getFormatDateTime(long microsecond) {
        return getFormatDateTime(new Date(microsecond));
    }

    /**
     * 根据给定的格式与时间(毫秒数)，返回时间字符串<br>
     *
     * @param microsecond 指定日期的毫秒数
     * @param format      日期格式字符串
     * @return String 指定格式的日期字符串.
     */
    public static String getFormatDateTime(long microsecond, String format) {
        return getFormatDateTime(new Date(microsecond), format);
    }

    /**
     * 根据给定的格式与时间(Date类型的)，返回时间字符串
     * <p>
     * 格式：yyyy-MM-dd HH:mm:ss
     *
     * @param date 指定的日期
     * @return String 格式：yyyy-MM-dd HH:mm:ss的日期字符串.
     */
    public static String getFormatDateTime(Date date) {
        return getFormatDateTime(date, DEFAULT_FORMAT_STRING);
    }

    /**
     * 根据给定的格式与时间(Date类型的)，返回时间字符串<br>
     *
     * @param date   指定的日期
     * @param format 日期格式字符串
     * @return String 指定格式的日期字符串.
     */
    public static String getFormatDateTime(Date date, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.getDefault());
        return sdf.format(date);
    }


    /**
     * 根据指定的毫秒数返回当前是星期几。1表示星期天、2表示星期一、7表示星期六。
     *
     * @param milliseconds 毫秒数
     * @return 星期的第几天
     * @see Calendar#SUNDAY
     * @see Calendar#MONDAY
     * @see Calendar#TUESDAY
     * @see Calendar#WEDNESDAY
     * @see Calendar#THURSDAY
     * @see Calendar#FRIDAY
     * @see Calendar#SATURDAY
     */
    public static int getDayOfWeek(long milliseconds) {
        Calendar c = new GregorianCalendar(Locale.getDefault());
        c.setTimeInMillis(milliseconds);
        return c.get(Calendar.DAY_OF_WEEK);
    }

    /**
     * 取得给定字符串描述的日期是星期几。1表示星期天、2表示星期一、7表示星期六。<br>
     * <b>NOTE：如果指定日期无法解析则返回当前日期是星期几。</b>
     *
     * @param dateStr 日期字串
     * @param pattern 日期模式
     * @return 星期的第几天
     * @see #getDayOfWeek
     */
    public static int getDayOfWeek(String dateStr, String pattern) {
        Date resDate = getDateFromString(dateStr, pattern);
        if (resDate != null) {
            return getDayOfWeek(resDate.getTime());
        }
        return getDayOfWeek(System.currentTimeMillis());
    }


}
