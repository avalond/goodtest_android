package com.haier.uhome.goodtaste.ui.collection;


import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.actions.CollectionActionCreator;
import com.haier.uhome.goodtaste.actions.CollectionActions;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.RecipeData;
import com.haier.uhome.goodtaste.data.source.remote.services.H5HybirdUrl;
import com.haier.uhome.goodtaste.stores.CollectionStore;
import com.haier.uhome.goodtaste.stores.UserStore;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.ui.WebActivity;
import com.haier.uhome.goodtaste.utils.ErrorHandler;
import com.haier.uhome.goodtaste.utils.ImageDownLoader;
import com.haier.uhome.goodtaste.widgets.CollectionListView;
import com.haier.uhome.goodtaste.widgets.DialogHelper;
import com.haier.uhome.goodtaste.widgets.roundedimageview.RoundedImageView;
import com.haier.uhome.goodtaste.widgets.swipmenu.BaseSwipListAdapter;
import com.haier.uhome.goodtaste.widgets.swipmenu.SwipeMenu;
import com.haier.uhome.goodtaste.widgets.swipmenu.SwipeMenuCreator;
import com.haier.uhome.goodtaste.widgets.swipmenu.SwipeMenuItem;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;

;


/**
 * Created by Administrator on 2016/5/10.
 */
public class MyCollectionActivity extends BaseActivity {

    private AppAdapter mAdapter;
    private CollectionListView mListView;
    private CollectionStore mCollectionStore;
    private List<RecipeData> recipeDatas;

    private int pages = 0;

    @Bind(R.id.ll_nothing_collection)
    LinearLayout nothingToShow;
    private CollectionActionCreator mCollectionActionCreator;
    private String userid;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_collection);
        showToolbar();
        setToolbarTitle(getString(R.string.information_collection));
        recipeDatas = new ArrayList<>();
        mCollectionActionCreator = new CollectionActionCreator(this, getApp().getDataManager(),
            getApp().getRxFlux().getDispatcher(), getApp().getRxFlux().getSubscriptionManager());
        userid = UserStore.get(this).getUserId();
        showProgressDialog();
        mCollectionActionCreator.getUserCollection(userid, pages);
        mListView = (CollectionListView) findViewById(R.id.lv_collection);

    }


    @Override
    protected View createToolbarView(LayoutInflater inflater, ViewGroup container) {
        View v = super.createToolbarView(inflater, container);
        TextView mRightBtn = (TextView) v.findViewById(R.id.toolbar_right_btn);
        mRightBtn.setVisibility(View.INVISIBLE);
        return v;
    }

    //用于删除收藏条目的标记
    private int delCollect = 0;

    private void initData() {

        mAdapter = new AppAdapter();
        mListView.setAdapter(mAdapter);
        //mAdapter = new AppAdapter();

        // step 1. create a MenuCreator
        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {
                // create "open" item
               /* SwipeMenuItem openItem = new SwipeMenuItem(
                        getApplicationContext());
                // set item background
                openItem.setBackground(new ColorDrawable(Color.rgb(0xC9, 0xC9,
                        0xCE)));
                // set item width
                openItem.setWidth(dp2px(90));
                // set item title
                openItem.setTitle("Open");
                // set item title fontsize
                openItem.setTitleSize(18);
                // set item title font color
                openItem.setTitleColor(Color.WHITE);
                // add to menu
                menu.addMenuItem(openItem);*/

                // create "delete" item
                SwipeMenuItem deleteItem = new SwipeMenuItem(getApplicationContext());
                // set item background
                deleteItem.setBackground(new ColorDrawable(Color.rgb(255, 0, 0)));
                // set item width
                deleteItem.setWidth(dp2px(70));
                // set a icon
                deleteItem.setTitle("删除");
                // add to menu
                menu.addMenuItem(deleteItem);
            }
        };
        // set creator
        mListView.setMenuCreator(creator);

        // step 2. listener item click event
        mListView.setOnMenuItemClickListener(new CollectionListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(final int position, SwipeMenu menu, int index) {
                switch (index) {
                    case 0:
                        final DialogHelper dialogHelper = new DialogHelper(MyCollectionActivity.this);
                        dialogHelper.showDialog2(getString(R.string.message_dialog_title),
                            getString(R.string.message_delete_dialog_content),
                            getString(R.string.message_delete_dialog_cancel),
                            getString(R.string.message_delete_dialog_ok), new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    delCollect = position;
                                    showProgressDialog(getString(R.string.message_delete_dialog_deleteing));
                                    mCollectionActionCreator.deleteCollection(userid,
                                        recipeDatas.get(position).getRecipeId());
                                }
                            });
                        break;
                    default:
                        return false;
                }
                return false;
            }
        });

        // set SwipeListener
        mListView.setOnSwipeListener(new CollectionListView.OnSwipeListener() {

            @Override
            public void onSwipeStart(int position) {
                // swipe start
            }

            @Override
            public void onSwipeEnd(int position) {
                // swipe end
            }
        });

        // set MenuStateChangeListener
        mListView.setOnMenuStateChangeListener(new CollectionListView.OnMenuStateChangeListener() {
            @Override
            public void onMenuOpen(int position) {
            }

            @Override
            public void onMenuClose(int position) {
            }
        });
        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                //showToast("" + position);
                return false;
            }
        });

        mListView.setOnRefreshListener(new CollectionListView.OnRefreshListenter() {
            @Override
            public void loadmore() {

                //pages++;
                //mCollectionActionCreator.getUserCollection(userid, pages);
                //mAdapter.notifyDataSetChanged();

            }
        });

    }

    @Override
    public void onRxStoresRegister() {

        //mCollectionStore = new CollectionStore(getApp().getRxFlux().getDispatcher());
        mCollectionStore = CollectionStore.get(this);
        mCollectionStore.register();
    }

    @Override
    public void onRxStoresUnRegister() {
        mCollectionStore.unregister();
    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {

        switch (change.getStoreId()) {

            case CollectionStore.ID:
                switch (change.getRxAction().getType()) {
                    case CollectionActions.ID_USER_COLLECTION:
                        recipeDatas = (List<RecipeData>) change.getRxAction().getData();
                        if (recipeDatas.size() == 0) {
                            stopProgressDialog();
                            nothingToShow.setVisibility(View.VISIBLE);
                            mListView.nothingToshow();
                        } else {
                            stopProgressDialog();
                            nothingToShow.setVisibility(View.INVISIBLE);
                            initData();
                        }

                        break;
                    case CollectionActions.ID_USER_DELETE_COLLECTION:
                        BaseResult baseResult = (BaseResult) change.getRxAction().getData();
                        String ret = baseResult.getRetCode();
                        if ("00000".equals(ret)) {
                            recipeDatas.remove(delCollect);
                            stopProgressDialog();
                            showToast("删除成功");
                            mAdapter.notifyDataSetChanged();
                        }
                        break;
                    default:
                        break;
                }
            default:
                break;
        }

    }

    @Override
    public void onRxError(RxError error) {
        stopProgressDialog();
        showToast(ErrorHandler.handelError(error.getThrowable(), this));
    }

    class AppAdapter extends BaseSwipListAdapter {


        @Override
        public int getCount() {
            return recipeDatas.size();
        }

        @Override
        public Object getItem(int position) {
            return recipeDatas.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = View.inflate(getApplicationContext(), R.layout.layout_delete_collection, null);
                new ViewHolder(convertView);
            }
            ViewHolder holder = (ViewHolder) convertView.getTag();
            //ApplicationInfo item = getItem(position);
            String picurl = recipeDatas.get(position).getPic();
            ImageDownLoader.get(MyCollectionActivity.this).display(picurl, R.drawable.head_default_icon, holder.ivIcon);
            //ImageDownLoader.get(getApplicationContext()).display(picurl, R.drawable.head_default_icon, holder.ivIcon);
            holder.tvName.setText(recipeDatas.get(position).getTitle());
            holder.tvTime.setText(recipeDatas.get(position).getUpdateTime());
            holder.rl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Toast.makeText(MyCollectionActivity.this, "iv_icon_click", Toast.LENGTH_SHORT).show();
                    String webUrl = H5HybirdUrl.getDishDetailH5Url(recipeDatas.get(position).getRecipeId(), userid);
                    Intent intent = new Intent().setClass(MyCollectionActivity.this, WebActivity.class);
                    intent.putExtra(WebActivity.URL, webUrl);
                    intent.putExtra(WebActivity.TITLE, recipeDatas.get(position).getTitle());
                    startActivity(intent);
                }
            });
            holder.tvName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Toast.makeText(MyCollectionActivity.this, "iv_icon_click", Toast.LENGTH_SHORT).show();
                }
            });
            return convertView;
        }

        class ViewHolder {
            RoundedImageView ivIcon;
            TextView tvName;
            TextView tvTime;
            RelativeLayout rl;

            public ViewHolder(View view) {
                ivIcon = (RoundedImageView) view.findViewById(R.id.iv_recipe_icon);
                tvName = (TextView) view.findViewById(R.id.tv_food_name);
                tvTime = (TextView) view.findViewById(R.id.tv_collection_time);
                rl = (RelativeLayout) view.findViewById(R.id.rl_collection);
                view.setTag(this);
            }
        }

        @Override
        public boolean getSwipEnableByPosition(int position) {
            /*if(position % 2 == 0){
                return false;
            }*/
            return true;
        }
    }

    private int dp2px(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }*/

   /* @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_left) {
            mListView.setSwipeDirection(CollectionListView.DIRECTION_LEFT);
            return true;
        }
        if (id == R.id.action_right) {
            mListView.setSwipeDirection(CollectionListView.DIRECTION_RIGHT);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }*/


}
