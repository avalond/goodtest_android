/*
* 文件名：WebActivity
* 版权：〈版权〉
* 描述：〈描述〉
* 修改人： malm@haierubic.com
* 修改时间：2015-09-18 
* 修改单号：〈修改单号〉
* 修改内容：〈修改内容〉
*/


package com.haier.uhome.goodtaste.ui;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.stores.UserStore;
import com.haier.uhome.goodtaste.ui.login.LoginActivity;
import com.haier.uhome.goodtaste.ui.message.MessageActivity;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.widgets.DialogHelper;
import com.haier.uhome.uphybrid.UpHybridActivity;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;

import org.apache.cordova.engine.SystemWebChromeClient;
import org.apache.cordova.engine.SystemWebViewClient;
import org.apache.cordova.engine.SystemWebViewEngine;
import org.json.JSONObject;

public class WebActivity extends UpHybridActivity {
    private static final String TAG = "WebActivity";
    private static final int LOAD_URL_TIMEOUT_VALUE = 60 * 1000;

    //static
    public static final String URL = "url";
    public static final String TITLE = "title";
    public static final String IS_SHOW_SHARE = "is_Show_hare";

    private WebView mWebView;
    private ProgressBar mProgressBar;
    private TextView mErrorView;
    private String mUrl;
    private TextView mClose;
    private String mTitle;
    private TextView mTitleTextView;

    private Runnable mDelayRunnable;
    private Handler mMainHandler;

    private volatile boolean mIsAllowBack = true;
    private volatile boolean mCanGoBack = true;

    private ViewGroup mRootView;
    private String mLastURL = "";//缓存最近一次打开的url

    private ImageButton mRightBtn;
    private int pageLayerNum = 1;//默认H5页面处于第一层
    private boolean isShowShareBtn = false;
    private boolean isShareBtnEnable = true;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mUrl = getIntent().getStringExtra(URL);
        if (!mUrl.startsWith("http://")) {
            mUrl = "http://" + mUrl;
        }
        HaierLoger.d(TAG,"mUrl = "+mUrl);
        mTitle = getIntent().getStringExtra(TITLE);
        isShowShareBtn = getIntent().getBooleanExtra(IS_SHOW_SHARE,false);
        setContentView(R.layout.activity_web_layout, R.id.webView);
        initBarView();
        mMainHandler = new Handler(Looper.getMainLooper());
        initViews();
        mTitleTextView.setText(mTitle);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mWebView.removeAllViews();
        mWebView.destroy();
        mWebView = null;
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        HaierLoger.d(TAG, "onTrimMemory level is " + level);
    }

    private void initViews() {
        mRootView = (ViewGroup) findViewById(R.id.root_view);
        mErrorView = (TextView) findViewById(R.id.tv_error_view);
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        init();
        mWebView = (WebView) appView.getView();
        mWebView.setWebViewClient(new SystemWebViewClient((SystemWebViewEngine) appView.getEngine()) {

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                mErrorView.setVisibility(View.GONE);
                mDelayRunnable = new Runnable() {
                    @Override
                    public void run() {
                        if (mWebView != null) {
                            HaierLoger.d("onPageStarted", "Progress = " + mWebView.getProgress());
                            if (mWebView.getProgress() < 100) {
                                mWebView.stopLoading();
                                showErrorView();
                            }
                        }
                    }
                };
                mMainHandler.postDelayed(mDelayRunnable, LOAD_URL_TIMEOUT_VALUE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                mMainHandler.removeCallbacks(mDelayRunnable);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                super.onReceivedSslError(view, handler, error);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                mLastURL = url;
                return false;
            }

        });
        mWebView.setWebChromeClient(new SystemWebChromeClient((SystemWebViewEngine) appView.getEngine()) {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress == 100) {
                    if (mProgressBar != null) {
                        mProgressBar.setVisibility(View.INVISIBLE);
                        if (mClose != null) {
                            if (view.canGoBack()) {
                                mClose.setVisibility(View.VISIBLE);
                            } else {
                                mClose.setVisibility(View.INVISIBLE);
                            }
                        }
                    }
                } else {
                    if (View.INVISIBLE == mProgressBar.getVisibility()) {
                        mProgressBar.setVisibility(View.VISIBLE);
                    }
                    mProgressBar.setProgress(newProgress);
                }
            }
        });
        mErrorView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(mUrl)) {
                    mWebView.loadUrl(mUrl);
                }
            }
        });

        if (!TextUtils.isEmpty(mUrl)) {
            mWebView.loadUrl(mUrl);
        } else {
            showErrorView();
        }

        mWebView.addJavascriptInterface(new MakeCall(), "MakeCall");
        mWebView.addJavascriptInterface(new SetTitle(), "SetTitle");
        mWebView.addJavascriptInterface(new SetBackStatus(), "SetBackStatus");
        mWebView.addJavascriptInterface(new SetCanWebGoBack(), "SetCanWebGoBack");
        mWebView.addJavascriptInterface(new CloseWebView(), "CloseWebView");
        mWebView.addJavascriptInterface(new LocalWebView(), "LocalWebView");
        mWebView.addJavascriptInterface(new GoLogin(), "GoLogin");
        mWebView.addJavascriptInterface(new SendMessage(), "SendMessage");
        mWebView.addJavascriptInterface(new SetShareStr(), "SetShareStr");
        mWebView.addJavascriptInterface(new SetShareBtn(), "SetShareBtn");
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            handleBackPressed();
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    private void handleBackPressed() {

        if (mWebView.canGoBack()) {
            mWebView.goBack();//返回上一页面
        } else {
            if (pageLayerNum == 1) {
                finish();
            } else {
                mWebView.loadUrl("javascript:goBack()");//返回上一页面
            }
        }
    }

    protected void initBarView() {
        mTitleTextView = (TextView) findViewById(R.id.action_title);

        TextView left = (TextView) findViewById(R.id.left_icon);
        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleBackPressed();
            }
        });

        mClose = (TextView) findViewById(R.id.tv_close);
        mClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.right_icon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mWebView.reload();
            }
        });

        mRightBtn = (ImageButton) findViewById(R.id.right_icon);
        mRightBtn.setVisibility(View.INVISIBLE);
        mRightBtn.setImageResource(R.drawable.share_btn);
        if(isShowShareBtn){
            mRightBtn.setVisibility(View.VISIBLE);
            mRightBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new TimeThread().start();
                    if(isShareBtnEnable) {
                        isShareBtnEnable = false;
                        getShareInfo();
                    }
                }
            });
        }else{
            mRightBtn.setVisibility(View.INVISIBLE);
        }
    }

    /**
     * 计时线程（防止在一定时间段内重复点击按钮）
     */
    private class TimeThread extends Thread {
        public void run() {
            try {
                sleep(1000);
                isShareBtnEnable = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onActivityResult(int request, int response, Intent intent) {
        super.onActivityResult(request, response, intent);
        if(response == RESULT_OK) {
            if (request == LoginActivity.RESULT_CODE) {
                String userId = UserStore.get(WebActivity.this).getUserId();
                String accessToken = UserStore.get(WebActivity.this).getAccessToken();
                retrieveLoginUID(userId,accessToken);
            }
        }
    }

    private void showErrorView() {
        mErrorView.setVisibility(View.VISIBLE);
    }

    class SetBackStatus {
        @JavascriptInterface
        public void set(boolean isAllow) {
            HaierLoger.d(TAG, "set is " + isAllow);
            mIsAllowBack = isAllow;
        }
    }

    class SetCanWebGoBack {
        @JavascriptInterface
        public void set(boolean canGoBack) {
            HaierLoger.d(TAG, "SetCanWebGoBack " + canGoBack);
            mCanGoBack = canGoBack;
        }
    }

    class MakeCall {
        @JavascriptInterface
        public void call(String phone) {
            HaierLoger.d(TAG, "phone is " + phone);
            if (!TextUtils.isEmpty(phone)) {
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phone));
                startActivity(intent);
            }
        }
    }

    class SetTitle {
        @JavascriptInterface
        public void setTitle(String title) {
            HaierLoger.d(TAG, "setTitle title is " + title);
            if (TextUtils.isEmpty(title)) {
                return;
            }
            mTitle = title;
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    mTitleTextView.setText(mTitle);
                }
            });
        }

    }

    class LocalWebView {
        @JavascriptInterface
        public void setPageLayerNum(int pageLayerNumIn) {
            HaierLoger.d(TAG, "LocalWebView.setPageLayerNum");
            pageLayerNum = pageLayerNumIn;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (pageLayerNum == 1) {
                        if (mClose != null) {
                            mClose.setVisibility(View.INVISIBLE);
                        }
                    } else {
                        if (mClose != null) {
                            mClose.setVisibility(View.VISIBLE);
                        }
                    }
                }
            });
        }
    }

    class CloseWebView {
        @JavascriptInterface
        public void close() {
            HaierLoger.d(TAG, "ClosePage.close");
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    WebActivity.this.finish();
                }
            });
        }
    }

    class GoLogin {
        @JavascriptInterface
        public void goLogin() {
            HaierLoger.d(TAG, "GoLogin.goLogin");
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent().setClass(WebActivity.this, LoginActivity.class);
                    startActivityForResult(intent,LoginActivity.RESULT_CODE);
                }
            });
        }
    }

    class SendMessage {
        @JavascriptInterface
        public void sendMessage(final String nickname, final String userId) {
            HaierLoger.d(TAG, "SendMessage.sendMessage");
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent().setClass(WebActivity.this, MessageActivity.class);
                    intent.putExtra("nickname", nickname);
                    intent.putExtra("userid", userId);
                    startActivity(intent);
                }
            });
        }
    }

    private void shareUrl(final String url,final String recipeName) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                DialogHelper dialogHelper = new DialogHelper(WebActivity.this);
                dialogHelper.showDialogShare(recipeName, getString(R.string.share_recipe_content,recipeName), url);
            }
        });
    }

    class SetShareStr {
        @JavascriptInterface
        public void setShareStr(String shareStr,String recipeName) {
            HaierLoger.d("setShareStr");
            if (TextUtils.isEmpty(shareStr)) {
                HaierLoger.d("share url is empty");
                return;
            }
            shareUrl(shareStr,recipeName);
        }
    }

    class SetShareBtn {
        @JavascriptInterface
        public void setShareBtn(boolean isShow) {
            HaierLoger.d("setShareBtn");
            if (isShow) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        mRightBtn.setVisibility(View.VISIBLE);
                    }
                });
            }else{
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        mRightBtn.setVisibility(View.INVISIBLE);
                    }
                });
            }
        }
    }

    public void getShareInfo() {
        HaierLoger.d("javascript:getInfo()");
        String call = "javascript:getInfo()";
        mWebView.loadUrl(call);
    }

    public void retrieveLoginUID(String userId,String accessToken) {
        HaierLoger.d("javascript:retrieveLoginUID "+userId);
        JsonObject object = new JsonObject();
        object.addProperty("usrId",userId);
        object.addProperty("accessToken",accessToken);
        String call = "javascript:retrieveLoginUID("+object.toString()+")";
        mWebView.loadUrl(call);
    }
}
