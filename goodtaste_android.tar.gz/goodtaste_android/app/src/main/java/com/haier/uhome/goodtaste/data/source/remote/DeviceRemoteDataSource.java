package com.haier.uhome.goodtaste.data.source.remote;

import android.support.annotation.NonNull;

import com.haier.uhome.goodtaste.data.source.DeviceDataSource;
import com.haier.uhome.goodtaste.data.source.remote.services.DeviceService;

import okhttp3.OkHttpClient;

/**
 * Created by lijin on 16-5-7.
 */
public class DeviceRemoteDataSource extends AbsRemoteDataSource implements DeviceDataSource {
    private final DeviceService mDeviceService;

    public DeviceRemoteDataSource(@EnvironmentMode int mode, @NonNull OkHttpClient httpClient) {
        super(mode, httpClient);
        switch (mode) {
            case DEBUG:
                mDeviceService = createService(DeviceService.DEBUG_BASE_URL, DeviceService.class);
                break;
            case DEBUG_VERIFY:
                mDeviceService = createService(DeviceService.DEBUG_VERIFY_BASE_URL, DeviceService.class);
                break;
            case PRE_PRODUCT:
                mDeviceService = createService(DeviceService.PRE_PRODUCT_BASE_RUL, DeviceService.class);
                break;
            case PRODUCT:
            default:
                mDeviceService = createService(DeviceService.PRODUCT_BASE_RUL, DeviceService.class);
                break;
        }
    }
}
