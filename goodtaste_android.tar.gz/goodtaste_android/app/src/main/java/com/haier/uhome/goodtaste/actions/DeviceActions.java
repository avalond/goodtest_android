package com.haier.uhome.goodtaste.actions;

/**
 * <p>Created by dallas on 16-4-19.
 */
public interface DeviceActions {
    String ID_CONFIG_DEVICE = "config_device";
    String ID_CONFIG_DEVICE_SMART_LINK = "config_device_smart_link";
    String ID_CONFIG_DEVICE_SOFT_AP = "config_device_soft_ap";
    String ID_GET_DEVICE_LIST = "get_device_list";
    String ID_UNBIND_DEVICE = "unbind_device";
}
