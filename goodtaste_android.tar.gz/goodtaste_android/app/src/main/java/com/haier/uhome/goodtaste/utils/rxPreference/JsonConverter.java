package com.haier.uhome.goodtaste.utils.rxPreference;

import java.lang.reflect.Type;

/**
 * <br>Created by Dallas.
 */
public interface JsonConverter {
    <T> T fromJson(String json, Type typeOfT);

    <T> String toJson(T object, Type typeOfT);
}
