package com.haier.uhome.goodtaste;

import com.umeng.socialize.media.WBShareCallBackActivity;

/**
 * Created by dallas on 16-5-23.
 */
public class WBShareActivity extends WBShareCallBackActivity {}
