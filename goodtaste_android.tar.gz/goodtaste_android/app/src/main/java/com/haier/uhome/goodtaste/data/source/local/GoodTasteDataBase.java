package com.haier.uhome.goodtaste.data.source.local;

import com.raizlabs.android.dbflow.annotation.Database;
import com.raizlabs.android.dbflow.annotation.Migration;
import com.raizlabs.android.dbflow.config.BaseDatabaseDefinition;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.sql.migration.BaseMigration;
import com.raizlabs.android.dbflow.structure.ModelAdapter;
import com.raizlabs.android.dbflow.structure.database.DatabaseWrapper;

import java.util.List;

@Database(name = GoodTasteDataBase.NAME, version = GoodTasteDataBase.VERSION)
public class GoodTasteDataBase {
    public static final String NAME = "good_taste_db";

    public static final int VERSION = 2;

    @Migration(version = GoodTasteDataBase.VERSION, database = GoodTasteDataBase.class)
    public static class UpgradeMigration extends BaseMigration {

        @Override
        public void migrate(DatabaseWrapper database) {
            String dropTable = "DROP TABLE IF EXISTS ";
            BaseDatabaseDefinition databaseDefinition = FlowManager.getDatabase(NAME);
            List<ModelAdapter> modelAdapters = databaseDefinition.getModelAdapters();
            for (ModelAdapter modelAdapter : modelAdapters) {
                String tableName = modelAdapter.getTableName();

                database.execSQL(dropTable + tableName);
                database.execSQL(modelAdapter.getCreationQuery());
            }
        }


    }
}
