package com.haier.uhome.goodtaste.data.source.remote.services;


import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.data.models.GatewayResult;

import retrofit2.http.Body;
import retrofit2.http.POST;
import rx.Observable;

/**
 * pms
 * <br>Created by Dallas.
 */
public interface PmsService {
    String DEBUG_BASE_URL = "http://" + BaseService.DEBUG_HOST + ":40000/pms/";
    String DEBUG_VERIFY_BASE_URL = "http://" + BaseService.DEBUG_VERIFY_HOST + ":40000/pms/";
    String PRE_PRODUCT_BASE_RUL = "http://" + BaseService.PRE_PRODUCT_HOST + ":6080/pms/";
    String PRODUCT_BASE_RUL = "http://" + BaseService.PRODUCT_HOST + ":6080/pms/";

    @POST("userag/assign")
    Observable<GatewayResult> getDeviceGateWay(@Body JsonObject req);
}
