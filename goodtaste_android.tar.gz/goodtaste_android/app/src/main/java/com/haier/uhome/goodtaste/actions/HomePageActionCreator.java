package com.haier.uhome.goodtaste.actions;

import android.content.Context;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.util.SubscriptionManager;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.AppVersionResult;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.ChefInfo;
import com.haier.uhome.goodtaste.data.models.MainRefreshInfo;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;
import com.haier.uhome.goodtaste.data.models.RecomRecipe;
import com.haier.uhome.goodtaste.data.models.TopVideoInfo;
import com.haier.uhome.goodtaste.data.source.ChefDataSource;
import com.haier.uhome.goodtaste.data.source.CommonDataSource;
import com.haier.uhome.goodtaste.data.source.RecipesDataSource;
import com.haier.uhome.goodtaste.data.source.VideoDataSource;
import com.haier.uhome.goodtaste.exception.BaseException;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.utils.NetWorkUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.functions.FuncN;

/**
 * Created by sharp on 16-5-7.
 */
public class HomePageActionCreator extends BaseActionCreator implements HomePageActions {
    public HomePageActionCreator(Context context, DataManager dataManager, Dispatcher dispatcher,
        SubscriptionManager subscriptionManager) {
        super(context, dataManager, dispatcher, subscriptionManager);
    }

    @Override
    public void homeVideoRefresh(String userId, String updateTime) {

        final RxAction action = newRxAction(ID_VIDEO_REFRESH, null);
        if (hasRxAction(action)) {
            return;
        }
        //        if (!NetWorkUtils.isNetworkAvailable(mContext)) {
        //            postError(action, new BaseException(mContext.getString(R.string.net_no)));
        //            return;
        //        }

        VideoDataSource videoRepository = mDataManager.getVideoRepository();
        Observable<List<TopVideoInfo>> tvObservable = videoRepository.getTopVideo(userId, updateTime);
        //拦截轮播图接口请求错误
        //        tvObservable.onErrorReturn(new Func1<Throwable, List<TopVideoInfo>>() {
        //            @Override
        //            public List<TopVideoInfo> call(Throwable throwable) {
        //                HaierLoger.d("HomePageActionCreator", throwable);
        //                return null;
        //            }
        //        });
        Subscription subscription = tvObservable.subscribe(new Subscriber<List<TopVideoInfo>>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                //                postError(action, e);
            }

            @Override
            public void onNext(List<TopVideoInfo> topVideoInfoList) {
                RxAction<List<TopVideoInfo>> resultAction = newRxAction(ID_VIDEO_REFRESH, topVideoInfoList);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    @Override
    public void homeRankRefresh() {
        final RxAction action = newRxAction(ID_RANK_REFRESH, null);
        if (hasRxAction(action)) {
            return;
        }
        //        if (!NetWorkUtils.isNetworkAvailable(mContext)) {
        //            postError(action, new BaseException(mContext.getString(R.string.net_no)));
        //            return;
        //        }

        ChefDataSource repository = mDataManager.getChefRepository();
        Subscription subscription = repository.findChefRank("1").subscribe(new Subscriber<List<ChefInfo>>() {
            @Override
            public void onCompleted() {
                //                    postStopLoading();
            }

            @Override
            public void onError(Throwable e) {
                //                    postError(action, e);
            }

            @Override
            public void onNext(List<ChefInfo> baseResult) {
                RxAction<List<ChefInfo>> resultAction = newRxAction(ID_RANK_REFRESH, baseResult);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    @Override
    public void homeDishRefresh(int recipeType, int pageNum, String updateTime) {
        final RxAction action = newRxAction(ID_DISH_REFRESH, null);
        if (hasRxAction(action)) {
            return;
        }

        RecipesDataSource recipesRepository = mDataManager.getRecipesRepository();

        Observable<List<RecomRecipe>> rpObservable = recipesRepository.getRecommendRecipeInfoList(pageNum, updateTime);
        Subscription subscription = rpObservable.subscribe(new Subscriber<List<RecomRecipe>>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(List<RecomRecipe> recomRecipes) {
                RxAction<List<RecomRecipe>> resultAction = newRxAction(ID_DISH_REFRESH, recomRecipes);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    @Override
    public void homePageRefresh() {
        final RxAction action = newRxAction(ID_PAGE_REFRESH, null);
        if (hasRxAction(action)) {
            return;
        }

        if (!NetWorkUtils.isNetworkAvailable(mContext)) {
            postError(action, new BaseException(mContext.getString(R.string.net_no)));
            return;
        }

        //        VideoDataSource videoRepository = mDataManager.getVideoRepository();
        RecipesDataSource recipesRepository = mDataManager.getRecipesRepository();
        ChefDataSource chefRepository = mDataManager.getChefRepository();

        Observable<List<RecipeWithUser>> rpObservable = recipesRepository.getRecipeInfoList("", 2, 1, 1,
            "2016-05-11 22:12:21");
        Observable<List<ChefInfo>> crObservable = chefRepository.findChefRank("1");

        //拦截接口请求错误
        rpObservable.onErrorReturn(new Func1<Throwable, List<RecipeWithUser>>() {
            @Override
            public List<RecipeWithUser> call(Throwable throwable) {
                return null;
            }
        });
        crObservable.onErrorReturn(new Func1<Throwable, List<ChefInfo>>() {
            @Override
            public List<ChefInfo> call(Throwable throwable) {
                return null;
            }
        });
        List<Observable<?>> templist = new ArrayList<>();
        templist.add(rpObservable);
        templist.add(crObservable);


        Subscriber mSubscriber = new Subscriber<MainRefreshInfo>() {
            @Override
            public void onCompleted() {
                postStopLoading();
            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(MainRefreshInfo baseResult) {
                RxAction<MainRefreshInfo> resultAction = newRxAction(ID_PAGE_REFRESH, baseResult);
                postRxAction(resultAction);
            }
        };

        FuncN<MainRefreshInfo> mfun = new FuncN<MainRefreshInfo>() {
            @Override
            public MainRefreshInfo call(Object... args) {

                List<ChefInfo> temp1 = (List<ChefInfo>) args[0];
                List<RecipeWithUser> temp2 = (List<RecipeWithUser>) args[1];
                return new MainRefreshInfo(temp1, temp2);
            }
        };
        Subscription subscription = Observable.zip(templist, mfun)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(mSubscriber);
        addRxAction(action, subscription);
    }

    @Override
    public void homeMoreDishRefresh(int recipeType, int pageNum, String updateTime) {
        final RxAction action = newRxAction(ID_DISH_MORE_REFRESH, null);
        if (hasRxAction(action)) {
            return;
        }
        //        if (!NetWorkUtils.isNetworkAvailable(mContext)) {
        //            postError(action, new BaseException(mContext.getString(R.string.net_no)));
        //            return;
        //        }

        RecipesDataSource recipesRepository = mDataManager.getRecipesRepository();
        Observable<List<RecipeWithUser>> rpObservable = recipesRepository.getRecipeInfoList("", recipeType, pageNum, 1,
            updateTime).delay((long) 1000, TimeUnit.MILLISECONDS);
        //        rpObservable.onErrorReturn(new Func1<Throwable, List<RecipeWithUser>>() {
        //            @Override
        //            public List<RecipeWithUser> call(Throwable throwable) {
        //                return null;
        //            }
        //        });
        Subscription subscription = rpObservable.subscribe(new Subscriber<List<RecipeWithUser>>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(List<RecipeWithUser> recipeWithUserList) {
                RxAction<List<RecipeWithUser>> resultAction = newRxAction(ID_DISH_MORE_REFRESH, recipeWithUserList);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    /**
     * 视频点赞
     *
     * @param userId
     * @param videoId
     */
    @Override
    public void homeVideoPraise(String userId, String videoId) {
        final RxAction action = newRxAction(ID_VEDIO_PRAISE, null);
        if (hasRxAction(action)) {
            return;
        }
        if (!NetWorkUtils.isNetworkAvailable(mContext)) {
            postError(action, new BaseException(mContext.getString(R.string.net_no)));
            return;
        }

        VideoDataSource videoRepository = mDataManager.getVideoRepository();
        Observable<BaseResult> tvObservable = videoRepository.postLike(userId, videoId);

        Subscription subscription = tvObservable.subscribe(new Subscriber<BaseResult>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onNext(BaseResult baseResult) {
                RxAction<BaseResult> resultAction = newRxAction(ID_VEDIO_PRAISE, baseResult);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    /**
     * 菜谱点赞
     *
     * @param userId
     * @param recipeId
     */
    @Override
    public void homeDishPraise(String userId, String recipeId) {
        final RxAction action = newRxAction(ID_DISH_PRAISE, null);
        if (hasRxAction(action)) {
            return;
        }
        //        if (!NetWorkUtils.isNetworkAvailable(mContext)) {
        //            postError(action, new BaseException(mContext.getString(R.string.net_no)));
        //            return;
        //        }

        ChefDataSource repository = mDataManager.getChefRepository();
        Observable<BaseResult> cfObservable = repository.addPraise(userId, recipeId);
        Subscription subscription = cfObservable.subscribe(new Subscriber<BaseResult>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(BaseResult baseResult) {
                RxAction<BaseResult> resultAction = newRxAction(ID_DISH_PRAISE, baseResult);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    /**
     * 关注某人
     *
     * @param userId         用户ID
     * @param followedUserId 关注用户ID
     * @return
     */
    @Override
    public void homeCookerSubscribe(String userId, String followedUserId) {
        final RxAction action = newRxAction(ID_COOKER_SUBSCRIBE, null);
        if (hasRxAction(action)) {
            return;
        }

        if (!NetWorkUtils.isNetworkAvailable(mContext)) {
            postError(action, new BaseException(mContext.getString(R.string.net_no)));
            return;
        }

        ChefDataSource repository = mDataManager.getChefRepository();
        Observable<BaseResult> cfObservable = repository.subscribe(userId, followedUserId);
        Subscription subscription = cfObservable.subscribe(new Subscriber<BaseResult>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(BaseResult baseResult) {
                RxAction<BaseResult> resultAction = newRxAction(ID_COOKER_SUBSCRIBE, baseResult);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }


    /**
     * 取消关注某人
     *
     * @param userId         用户ID
     * @param followedUserId 关注用户ID
     * @return
     */
    @Override
    public void homeCookerUnSubscribe(String userId, String followedUserId) {
        final RxAction action = newRxAction(ID_COOKER_UNSUBSCRIBE, null);
        if (hasRxAction(action)) {
            return;
        }

        if (!NetWorkUtils.isNetworkAvailable(mContext)) {
            postError(action, new BaseException(mContext.getString(R.string.net_no)));
            return;
        }

        ChefDataSource repository = mDataManager.getChefRepository();
        Observable<BaseResult> cfObservable = repository.unsubscribe(userId, followedUserId);
        Subscription subscription = cfObservable.subscribe(new Subscriber<BaseResult>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(BaseResult baseResult) {
                RxAction<BaseResult> resultAction = newRxAction(ID_COOKER_UNSUBSCRIBE, baseResult);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    @Override
    public void homeIsSubscribe(String userId, String targetUserId) {
        final RxAction action = newRxAction(ID_DEFINE_SUB, null);
        if (hasRxAction(action)) {
            return;
        }

        if (!NetWorkUtils.isNetworkAvailable(mContext)) {
            postError(action, new BaseException(mContext.getString(R.string.net_no)));
            return;
        }

        ChefDataSource repository = mDataManager.getChefRepository();
        Observable<Boolean> cfObservable = repository.isSubscribe(userId, targetUserId);
        Subscription subscription = cfObservable.subscribe(new Subscriber<Boolean>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(Boolean aBoolean) {
                RxAction<Boolean> resultAction = newRxAction(ID_DEFINE_SUB, aBoolean);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    @Override
    public void getAppVersionInfo() {
        final RxAction action = newRxAction(GET_APP_VERSION, null);
        if (hasRxAction(action)) {
            return;
        }

        if (!NetWorkUtils.isNetworkAvailable(mContext)) {
            postError(action, new BaseException(mContext.getString(R.string.net_no)));
            return;
        }

        String appId = ((HaierApplication)(mContext.getApplicationContext())).getAppId();
        CommonDataSource commonRepository = mDataManager.getCommonRepository();
        Observable<AppVersionResult> observable = commonRepository.getAppVersionInfo(appId);
        Subscription subscription = observable.subscribe(new Subscriber<AppVersionResult>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onNext(AppVersionResult appVersionResult) {
                RxAction<AppVersionResult> resultAction = newRxAction(GET_APP_VERSION, appVersionResult);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }
}
