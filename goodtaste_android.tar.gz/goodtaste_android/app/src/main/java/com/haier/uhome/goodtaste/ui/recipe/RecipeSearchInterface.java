package com.haier.uhome.goodtaste.ui.recipe;

/**
 * 首页推荐菜谱部分点击事件的回调
 * Created by sharp on 16-5-6.
 */
public interface RecipeSearchInterface {

    //菜谱的厨咖主页
    void onSearchHotkey(String key);
}
