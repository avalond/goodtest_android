package com.haier.uhome.goodtaste.data.source.remote.services;

/**
 * <br>Created by Dallas.
 */
interface BaseService {
    /**
     * 联调环境（开发过程中使用该环境，服务器环境部署在虚拟机上）
     */
    String DEBUG_HOST = "103.8.220.166";
    /**
     * 验证环境（同联调环境，只是服务器环境部署在真实设备上）
     */
    String DEBUG_VERIFY_HOST = "203.130.41.37";
    /**
     * 验收环境（质量部验收时使用该环境，一般程序内不需要设置该环境。通过使用生产环境域名并设置路由器DNS来接入该环境）
     */
    String PRE_PRODUCT_HOST = "210.51.17.150";
    /**
     * 生产环境
     */
    String PRODUCT_HOST = "uhome.haier.net";
}
