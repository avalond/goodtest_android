package com.haier.uhome.goodtaste.data.models.req;

import java.io.Serializable;
import java.util.List;

/**
 * 菜谱添加步骤请求参数
 * <br>Created by dallas on 16-5-7.
 */
public class CreateRecipeStepReq implements Serializable {
    private static final long serialVersionUID = -8916384649134567267L;
    private String recipeId;
    private int state;
    private List<RecipeStepReq> steps;

    public String getRecipeId() {
        return recipeId;
    }

    public void setRecipeId(String recipeId) {
        this.recipeId = recipeId;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public List<RecipeStepReq> getSteps() {
        return steps;
    }

    public void setSteps(List<RecipeStepReq> steps) {
        this.steps = steps;
    }
}
