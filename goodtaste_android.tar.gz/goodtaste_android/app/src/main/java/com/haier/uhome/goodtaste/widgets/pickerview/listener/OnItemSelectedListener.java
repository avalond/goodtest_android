package com.haier.uhome.goodtaste.widgets.pickerview.listener;


public interface OnItemSelectedListener {
    void onItemSelected(int index);
}
