package com.haier.uhome.goodtaste.utils;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class NetWorkUtils {
    @IntDef({TYPE_NONE, TYPE_WIFI, TYPE_MOBILE})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Type {}

    public static final int TYPE_NONE = -1;
    public static final int TYPE_WIFI = 0;
    public static final int TYPE_MOBILE = 1;

    /**
     * 查看网络链接状态
     *
     * @param context Context
     * @return {@link #TYPE_NONE}, {@link #TYPE_WIFI},{@link #TYPE_MOBILE}
     */
    @Type
    public static int getConnectType(Context context) {
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        @Type int type = TYPE_NONE;
        if (manager == null) {
            return type;
        }
        NetworkInfo mobile = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        NetworkInfo wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (mobile != null && mobile.isConnectedOrConnecting()) {
            type = TYPE_MOBILE;
        }
        if (wifi != null && wifi.isConnectedOrConnecting()) {
            type = TYPE_WIFI;
        }
        return type;
    }

    /**
     * 检测当的网络是否可用
     *
     * @param context Context
     * @return true 表示网络可用
     */
    public static boolean isNetworkAvailable(Context context) {
        return getConnectType(context) != TYPE_NONE;
    }

}