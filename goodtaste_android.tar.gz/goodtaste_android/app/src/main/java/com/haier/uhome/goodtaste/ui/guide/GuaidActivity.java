package com.haier.uhome.goodtaste.ui.guide;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.HaierPreference;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.ui.guide.adapter.GuaidAdapter;
import com.haier.uhome.goodtaste.ui.main.HomeActivity;
import com.haier.uhome.goodtaste.ui.main.HomeMainActivity;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;

import java.util.ArrayList;

import butterknife.Bind;

/**
 * Created by Administrator on 2016/4/26.
 */
public class GuaidActivity extends BaseActivity implements ViewPager.OnPageChangeListener, View.OnClickListener {

    private ViewPager mViewPaper;
    private int[] images={R.drawable.guaid_one,R.drawable.guaid_two,R.drawable.guaid_three};
    private static RxPreference preferences ;
    private ArrayList<View> views;
    private LinearLayout ll;
    int num=0;
    @Bind(R.id.guaid_iumpbtn)
    Button jumpBtn;
    @Bind(R.id.guaid_feelbtn)
    Button feelBtn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);
        hideToolbar();
        preferences = DataManager.instance().getPreference();
        jumpBtn.setOnClickListener(this);
        feelBtn.setOnClickListener(this);
        if(preferences.getBoolean(HaierPreference.IS_FIRST_OPEN,true)) {
            mViewPaper = (ViewPager) findViewById(R.id.guide_vp);
            ll = (LinearLayout) findViewById(R.id.guide_ll);
            views = new ArrayList<>();
            for (int i = 0; i < images.length; i++) {
                ImageView iv = new ImageView(this);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                iv.setLayoutParams(layoutParams);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setImageResource(images[i]);
                views.add(iv);
            }
            GuaidAdapter adapter = new GuaidAdapter(views);
            mViewPaper.setAdapter(adapter);
            mViewPaper.addOnPageChangeListener(this);
            ((ImageView)ll.getChildAt(num)).setBackgroundResource(R.drawable.guaid_show);
        }else {

            Intent i = new Intent(GuaidActivity.this, HomeActivity.class);
            startActivity(i);
            finish();
        }
    }

    @Override
    public void onRxStoresRegister() {

    }

    @Override
    public void onRxStoresUnRegister() {

    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {

    }

    @Override
    public void onRxError(RxError error) {

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        ((ImageView)ll.getChildAt(position)).setBackgroundResource(R.drawable.guaid_show);
        ((ImageView)ll.getChildAt(num)).setBackgroundResource(R.drawable.guaid_noshow);
        num=position;
        if(mViewPaper.getCurrentItem()==images.length-1) {
            jumpBtn.setVisibility(View.GONE);
            feelBtn.setVisibility(View.VISIBLE);
        }else{
            jumpBtn.setVisibility(View.VISIBLE);
            feelBtn.setVisibility(View.GONE);
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    @Override
    public void onClick(View v) {
        preferences.put(HaierPreference.IS_FIRST_OPEN, false);
        Intent i = new Intent(GuaidActivity.this, HomeActivity.class);
        startActivity(i);
        finish();
    }
}
