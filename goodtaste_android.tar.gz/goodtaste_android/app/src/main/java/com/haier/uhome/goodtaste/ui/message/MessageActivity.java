package com.haier.uhome.goodtaste.ui.message;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.actions.MessageActionCreator;
import com.haier.uhome.goodtaste.actions.MessageActions;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.stores.MessageStore;
import com.haier.uhome.goodtaste.stores.UserStore;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.utils.ErrorHandler;
import com.haier.uhome.goodtaste.utils.ImageDownLoader;
import com.haier.uhome.goodtaste.widgets.MessageListView;
import com.haier.uhome.goodtaste.widgets.roundedimageview.RoundedImageView;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by Administrator on 2016/5/5.
 */
public class MessageActivity extends BaseActivity {

    @Bind(R.id.et_message)
    EditText etMessage;
    @Bind(R.id.lv_message)
    MessageListView lvMessage;
    @Bind(R.id.ll_message)
    LinearLayout llMessage;
    private List<MessageInfo> list = new ArrayList<>();
    private MyAdapter adapter;
    private MessageActionCreator mMessageActionCreator;
    private MessageStore mMessageStore;
    private MessageInfo messageInfo;
    private String messageId;
    private String msgid;
    private String nickname;
    private String edit;
    //每次查询的消息个数
    private int maxIndex = 10;
    private String userid;
    private UserStore mUserStore;
    private String avter;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_message);
        nickname = getIntent().getStringExtra(getString(R.string.friend));
        userid = getIntent().getStringExtra(getString(R.string.userid));
        //userid = "123365233";
        msgid = getIntent().getStringExtra(getString(R.string.msgid));
        showToolbar();
        setToolbarTitle(nickname);
        mMessageActionCreator = new MessageActionCreator(this , getApp().getDataManager() ,
                getApp().getRxFlux().getDispatcher(),getApp().getRxFlux().getSubscriptionManager());
        //directMessageDbUtil = new DirectMessageDbUtil(this);
        //list = directMessageDbUtil.queryMessagers(msgid, index, maxIndex);
        //list = mMessageActionCreator.getMaxList(index, msgid, maxIndex);
        mUserStore = UserStore.get(this);
        mMessageActionCreator.getUnReadMsgContent( mUserStore.getUserId(), userid , maxIndex);
        avter = mUserStore.getUserInfo().getAvater();
        //mMessageActionCreator.sort(list);
        //initData();
    }

    @Override
    protected View createToolbarView(LayoutInflater inflater, ViewGroup container) {
        View v = super.createToolbarView(inflater, container);
        TextView mRightBtn = (TextView) v.findViewById(R.id.toolbar_right_btn);
        mRightBtn.setVisibility(View.INVISIBLE);
        return v;
    }
    //暂时写在onResume
    @Override
    protected void onResume() {
        super.onResume();


    }

    private void initData() {

        if (list != null) {
            if (adapter == null) {
                adapter = new MyAdapter(this);
                lvMessage.setAdapter(adapter);
                if (list.size() > 0) {
                    lvMessage.setSelection(list.size() - 1);
                }
            } else {
                adapter.notifyDataSetChanged();
                //lvMessage.setSelection(list.size() - 1);
            }

        }
        etMessage.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    openInputMethod(etMessage);
                } else {
                    closeInputMethod();
                }
            }
        });

        lvMessage.setOnRefreshListener(new MessageListView.OnRefreshListenter() {
            @Override
            public void refresh() {
                //要从本地数据库一次取十条数据
                maxIndex += maxIndex;
                //maxIndex = mMessageActionCreator.getMaxIndex(maxIndex , msgid);
                handler.sendEmptyMessageDelayed(0, 1000);
                //lvMessage.finish();
                //mMessageActionCreator.sort(list);


            }
        });

    }

    private Handler handler = new Handler(){
        public void handleMessage(android.os.Message msg) {
            //结束刷新
            lvMessage.finish();
            mMessageActionCreator.getUnReadMsgContent( userid , mUserStore.getUserId(), maxIndex );
        }
    };

    private class MyAdapter extends BaseAdapter {

        final int typtMessageMe = 0;
        final int typeMessageYou = 1;
        Context mContext;
        LayoutInflater inflater;

        public MyAdapter(Context context) {

            mContext = context;
            inflater = LayoutInflater.from(mContext);
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public int getViewTypeCount() {
            return 2;
        }

        @Override
        public int getItemViewType(int position) {
            //我给你发和你给我发的fromuserid 是不一样的
            if (userid.equals(list.get(position).getTargetUid())) {
                return typtMessageMe;
            } else {
                return typeMessageYou;
            }

        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder1 holder1 = null;

            int type = getItemViewType(position);

            if (convertView == null) {

                if (type == typtMessageMe) {
                    convertView = inflater.inflate(R.layout.item_message_my_list, parent, false);
                    holder1 = new ViewHolder1();
                    holder1.imageView = (RoundedImageView) convertView.findViewById(R.id.iv_item_my);
                    holder1.textView = (TextView) convertView.findViewById(R.id.tv_item_my);
                    holder1.tvTime = (TextView) convertView.findViewById(R.id.tv_message_my_time);
                    convertView.setTag(holder1);
                } else if (type == typeMessageYou) {
                    convertView = inflater.inflate(R.layout.item_message_other_list, parent, false);
                    holder1 = new ViewHolder1();
                    holder1.imageView = (RoundedImageView) convertView.findViewById(R.id.iv_item_other);
                    holder1.textView = (TextView) convertView.findViewById(R.id.tv_item_other);
                    holder1.tvTime = (TextView) convertView.findViewById(R.id.tv_message_you_time);
                    convertView.setTag(holder1);
                }

            } else {

                holder1 = (ViewHolder1) convertView.getTag();

            }


            holder1.textView.setText(list.get(position).getMsg());
            holder1.tvTime.setText(list.get(position).getTime());
            //holder1.imageView.setImageResource(R.drawable.usercenter_default_img);
            ImageDownLoader.get(MessageActivity.this)
                .display(list.get(position).getAvater(), R.drawable.head_default_icon, holder1.imageView);
            return convertView;
        }
    }


    static class ViewHolder1 {
        private RoundedImageView imageView;
        private TextView textView;
        private TextView tvTime;
    }

    @OnClick(R.id.btn_message_send)
    protected void toSend() {

        closeInputMethod();
        edit = etMessage.getText().toString();

        if (!TextUtils.isEmpty(edit)) {
            mMessageActionCreator.send(mUserStore.getUserId() ,userid, edit ,nickname ,avter);
            showProgressDialog(getString(R.string.sending_message));

        }


    }

    /**
     * 显示系统键盘
     *
     * @param editText
     */
    public void openInputMethod(final EditText editText) {
        /*Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            public void run() {
                InputMethodManager inputManager = (InputMethodManager) editText
                        .getContext().getSystemService(
                                Context.INPUT_METHOD_SERVICE);
                inputManager.showSoftInput(editText, 8);
            }
        }, 200);*/
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (!inputMethodManager.isActive()) {
            // 接受软键盘输入的编辑文本或其它视图
            inputMethodManager.showSoftInput(editText, InputMethodManager.SHOW_FORCED);
        }
    }

    //隐藏系统键盘
    public void closeInputMethod() {
        try {
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                            InputMethodManager.HIDE_NOT_ALWAYS);
        } catch (Exception e) {
        }
    }


    @Override
    public void onRxStoresRegister() {

        //mMessageStore = new MessageStore(getApp().getRxFlux().getDispatcher());
        mMessageStore = MessageStore.get(this);
        mMessageStore.register();

    }

    @Override
    public void onRxStoresUnRegister() {
        mMessageStore.unregister();
    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {

        switch (change.getStoreId()) {
            case MessageStore.ID:
                switch (change.getRxAction().getType()) {
                    case MessageActions.SEND_MESSAGE:
                        messageInfo = (MessageInfo) change.getRxAction().getData();
                        messageId = messageInfo.getId();
                        stopProgressDialog();
                        if (TextUtils.isEmpty(messageId)) {
                            showToast(getString(R.string.send_message_erro));
                        }else{
                            showToast(getString(R.string.send_message_success));
                            list.add(messageInfo);
                            etMessage.setText("");
                        }
                        /*directMessageDbUtil.addDirectMessage("20032", msgid, edit,
                                DateUtil.getFormatCurrentTime(), "乐哥", "13526230630.2336");
                        MessageInfo info = new MessageInfo("20032", msgid, edit,
                                DateUtil.getFormatCurrentTime(), "乐哥", "13526230630.2336");*/
                        //list = mMessageActionCreator.getMaxList(index, msgid, maxIndex);

                        adapter.notifyDataSetChanged();
                        if (list.size() > 0) {
                            lvMessage.setSelection(list.size() - 1);
                        }
                        break;
                    case MessageActions.GET_UNREAD_MESSAGE_CURRENT:
                        list = (List<MessageInfo>) change.getRxAction().getData();
                        initData();
                        break;
                    default:
                        return;
                }
                break;
            default:
                return;
        }

    }

    @Override
    public void onRxError(RxError error) {
        stopProgressDialog();
        //showToast(getString(R.string.send_message_erro));
        showToast(ErrorHandler.handelError(error.getThrowable(), this));
    }
}
