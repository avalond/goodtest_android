package com.haier.uhome.goodtaste.exception;

import com.haier.uhome.usdk.api.uSDKErrorConst;

/**
 * <br>Created by dallas on 16-4-25.
 */
public class SdkException extends BaseException {
    private final transient uSDKErrorConst mSDKError;

    public SdkException(uSDKErrorConst errorConst) {
        super(errorConst.toString());
        mSDKError = errorConst;
    }

    public uSDKErrorConst getSDKError() {
        return mSDKError;
    }
}
