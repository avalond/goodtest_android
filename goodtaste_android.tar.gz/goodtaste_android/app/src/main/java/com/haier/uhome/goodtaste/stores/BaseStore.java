package com.haier.uhome.goodtaste.stores;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStore;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.actions.LoadingIndicatorActions;

/**
 * <br>Created by dallas on 16-4-18.
 */
public abstract class BaseStore extends RxStore {
    public static final String ID_SHOW_LOADING = "base_store_show_loading";
    public static final String ID_STOP_LOADING = "base_store_stop_loading";

    protected BaseStore(Dispatcher dispatcher) {
        super(dispatcher);
    }

    @Override
    public void onRxAction(RxAction action) {
        if (!postLoadingStoreChange(action)) {
            onAction(action);
        }
    }

    protected boolean postLoadingStoreChange(RxAction action) {
        if (LoadingIndicatorActions.ID_SHOW_LOADING.equals(action.getType())) {
            postStoreChange(new RxStoreChange(ID_SHOW_LOADING, action));
            return true;
        } else if (LoadingIndicatorActions.ID_STOP_LOADING.equals(action.getType())) {
            postStoreChange(new RxStoreChange(ID_STOP_LOADING, action));
            return true;
        }
        return false;
    }

    protected abstract void onAction(RxAction action);
}
