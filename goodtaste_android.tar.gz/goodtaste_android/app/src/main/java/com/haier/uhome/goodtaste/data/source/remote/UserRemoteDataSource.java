package com.haier.uhome.goodtaste.data.source.remote;

import android.support.annotation.NonNull;
import android.util.Log;

import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.data.models.AccType;
import com.haier.uhome.goodtaste.data.models.BaseEntity;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.LoginInfo;
import com.haier.uhome.goodtaste.data.models.LoginType;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.data.models.RewardInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.UserProfileType;
import com.haier.uhome.goodtaste.data.models.UserScore;
import com.haier.uhome.goodtaste.data.source.UserDataSource;
import com.haier.uhome.goodtaste.data.source.remote.services.LoginService;
import com.haier.uhome.goodtaste.data.source.remote.services.UserService;
import com.haier.uhome.goodtaste.utils.AccountUtil;

import java.util.List;

import okhttp3.OkHttpClient;
import rx.Observable;

import static com.haier.uhome.goodtaste.utils.Preconditions.checkNotNull;

/**
 * <p>Created by dallas on 16-4-18.
 */
public class UserRemoteDataSource extends AbsRemoteDataSource implements UserDataSource {
    private final UserService mUserService;
    private final LoginService mLoginService;

    public UserRemoteDataSource(@EnvironmentMode int mode, @NonNull OkHttpClient httpClient) {
        super(mode, httpClient);

        switch (mode) {
            case DEBUG:
                mUserService = createService(UserService.DEBUG_BASE_URL, UserService.class);
                mLoginService = createService(LoginService.DEBUG_BASE_URL, LoginService.class);
                break;
            case DEBUG_VERIFY:
                mUserService = createService(UserService.DEBUG_VERIFY_BASE_URL, UserService.class);
                mLoginService = createService(LoginService.DEBUG_VERIFY_BASE_URL, LoginService.class);
                break;
            case PRE_PRODUCT:
                mUserService = createService(UserService.PRE_PRODUCT_BASE_RUL, UserService.class);
                mLoginService = createService(LoginService.DEBUG_VERIFY_BASE_URL, LoginService.class);
                break;
            case PRODUCT:
            default:
                mUserService = createService(UserService.PRODUCT_BASE_RUL, UserService.class);
                mLoginService = createService(LoginService.DEBUG_VERIFY_BASE_URL, LoginService.class);
                break;
        }
    }


    @Override
    public Observable<BaseResult> register(String mobile, String password, String uvc, String inviteCode) {

        JsonObject req = new JsonObject();
        req.addProperty("tenantId", "100"); // 租户（好空气为13）
        req.addProperty("mobile", mobile);
        req.addProperty("accType", AccType.HAIER + "");
        req.addProperty("msgCode", uvc);
        req.addProperty("password", password);
        req.addProperty("inviteCode", inviteCode);

        return mUserService.register(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<BaseResult> applyRegMsgCode(String mobile) {

        JsonObject req = new JsonObject();
        req.addProperty("tenantId", "100"); // 租户（好空气为13）
        req.addProperty("mobile", mobile);
        req.addProperty("accType", AccType.HAIER + "");
        Log.i("6666", "666660");
        return mUserService.postUvcForRegister(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<LoginInfo> login(String loginId, String password, @AccType.Type int accType,
        @LoginType.Type int loginType, String thirdPartyAppId, String thirdPartyAccessToken) {
        checkNotNull(loginId);
        checkNotNull(password);

        JsonObject req = new JsonObject();
        req.addProperty("loginId", loginId);
        req.addProperty("password", password);
        req.addProperty("accType", accType);
        req.addProperty("loginType", loginType);
        req.addProperty("sequenceId", getSequenceId());
        if ((thirdPartyAppId != null && thirdPartyAppId.length() != 0) &&
            (thirdPartyAccessToken != null && thirdPartyAccessToken.length() != 0)) {
            req.addProperty("thirdpartyAccessToken", thirdPartyAccessToken);
            req.addProperty("thirdpartyAppId", thirdPartyAppId);
        }

        return mLoginService.login(req).compose(this.<BaseEntity<LoginInfo>, LoginInfo>getTransformer2());
    }

    @Override
    public Observable<LoginInfo> login(String loginId, @AccType.Type int accType, String thirdPartyAppId,
        String thirdPartyAccessToken) {
        return login(loginId, "password", accType, LoginType.USER_NAME, thirdPartyAppId, thirdPartyAccessToken);
    }

    @Override
    public Observable<LoginInfo> login(String loginId, String password) {
        int loginType = AccountUtil.getLoginType(loginId);
        return login(loginId, password, AccType.HAIER, loginType, null, null);
    }

    @Override
    public Observable<UserInfo> findUserInfoById(String userId) {
        checkNotNull(userId);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        return mUserService.findUserInfoById(req).compose(this.<BaseEntity<UserInfo>, UserInfo>getTransformer2());
    }

    @Override
    public Observable<BaseResult> updateUserInfoById(String userId, @UserProfileType.Type int type, String content) {
        checkNotNull(userId);
        checkNotNull(type);
        checkNotNull(content);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("type", type + "");

        req.addProperty("nickName", "");
        req.addProperty("avater", "");
        req.addProperty("gender", "1");
        req.addProperty("address", "");
        req.addProperty("introduction", "");
        req.addProperty("email", "");
        req.addProperty("phone", "");
        req.addProperty("birthday", "");
        switch (type) {
            case UserProfileType.NIKE_NAME:
                req.addProperty("nickName", content);
                break;
            case UserProfileType.SEX:
                req.addProperty("gender", content);
                break;
            case UserProfileType.CITY:
                req.addProperty("address", content);
                break;
            case UserProfileType.ABOUT:
                req.addProperty("introduction", content);
                break;
            case UserProfileType.EMAIL:
                req.addProperty("email", content);
                break;
            case UserProfileType.PHONE:
                req.addProperty("phone", content);
                break;
            case UserProfileType.BIRTHDAY:
                req.addProperty("birthday", content);
                break;
            case UserProfileType.AVATAR:
                req.addProperty("avater", content);
                break;
            default:
                break;
        }
        return mUserService.updateUserInfoById(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<MessageInfo> sendMsgToUser(String fromUserId, String toUserId,
                                                 String msg, String nickname,String avter) {
        checkNotNull(fromUserId);
        checkNotNull(toUserId);
        checkNotNull(msg);

        JsonObject req = new JsonObject();
        req.addProperty("fromUserId", fromUserId);
        req.addProperty("toUserId", toUserId);
        req.addProperty("msg", msg);
        return mUserService.sendMsgToUser(req).compose(this.<BaseEntity<MessageInfo>, MessageInfo>getTransformer2());
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadPersonMsg(String userId) {
        checkNotNull(userId);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        return mUserService.getUnReadPersonMsg(req)
            .compose(this.<BaseEntity<List<MessageInfo>>, List<MessageInfo>>getTransformer2());
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadMsgState(String userId) {
        return getUnReadPersonMsg(userId);
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadMsgList(String userId) {
        return getUnReadPersonMsg(userId);
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadMsgListLocal(String userId) {
        return null;
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadMsgContent(String userId, String targetUid, int maxIndex) {

        return null;
    }

    @Override
    public Observable<BaseResult> updateMsgStatus(String userId, String time) {
        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("time", time);
        return mUserService.updateMsgStatus(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<UserScore> findUserPoint(String userId) {
        checkNotNull(userId);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);

        return mUserService.findUserPoint(req).compose(this.<BaseEntity<UserScore>, UserScore>getTransformer2());
    }

    @Override
    public Observable<RewardInfo> rewardUser(String userId, String rewardUserId, String rewardScore) {
        checkNotNull(userId);

        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("rewardUserId", rewardUserId);
        req.addProperty("rewardScore", rewardScore);
        return mUserService.rewardUser(req).compose(this.<BaseEntity<RewardInfo>, RewardInfo>getTransformer2());
    }

    @Override
    public void saveAccessToken(String token) {
    }

    @Override
    public void saveUserId(String userId) {

    }

    @Override
    public Observable<UserInfo> saveUserInfo(UserInfo userInfo) {
        return Observable.empty();
    }

    @Override
    public Observable<List<MessageInfo>> saveMessageInfo(List<MessageInfo> messageInfoList) {
        return null;
    }
}
