package com.haier.uhome.goodtaste.data.models;

import java.io.Serializable;

/**
 * Created by lijin on 16-5-7.
 */
public class UserScore implements Serializable{
    private static final long serialVersionUID = -1163683312366440715L;

    private String point;

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }

    @Override
    public String toString() {
        return "UserScore{" +
            "point='" + point + '\'' +
            '}';
    }
}
