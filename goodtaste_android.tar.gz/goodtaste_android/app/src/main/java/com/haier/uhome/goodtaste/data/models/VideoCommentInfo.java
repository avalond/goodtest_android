package com.haier.uhome.goodtaste.data.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by dallas on 16-5-10.
 */
public class VideoCommentInfo implements Serializable {
    private static final long serialVersionUID = 1426662970144537885L;
    private UserInfo createrUserInfo;
    @SerializedName("videoCommInfo")
    private Data data;

    public UserInfo getCreaterUserInfo() {
        return createrUserInfo;
    }

    public void setCreaterUserInfo(UserInfo createrUserInfo) {
        this.createrUserInfo = createrUserInfo;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public static class Data implements Serializable {

        private static final long serialVersionUID = -8479238034540982528L;


        /**
         * id : 10
         * videoId : 4
         * content : 888888888888888888888888888
         * resourceId :
         * resourceUrl : resourceUrl1,resourceUrl2
         * status : 0
         * statusDes : 正常
         * createTime : 1462784145000
         * fromUser : 100013957366161861
         * toUser : 100013957366161885
         * appid : aaa
         * version : ccc
         * versionname :
         * systemId : WEIZHIDAO
         * createTimeStr : 20分钟前
         * delete : false
         */

        private String id;
        private String videoId;
        private String content;
        private String resourceId;
        private String resourceUrl;
        private int status;
        private String statusDes;
        private long createTime;
        private String fromUser;
        private String toUser;
        @SerializedName("appid")
        private String appId;
        private String version;
        @SerializedName("versionname")
        private String versionName;
        private String systemId;
        private String createTimeStr;
        private boolean delete;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getVideoId() {
            return videoId;
        }

        public void setVideoId(String videoId) {
            this.videoId = videoId;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getResourceId() {
            return resourceId;
        }

        public void setResourceId(String resourceId) {
            this.resourceId = resourceId;
        }

        public String getResourceUrl() {
            return resourceUrl;
        }

        public void setResourceUrl(String resourceUrl) {
            this.resourceUrl = resourceUrl;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getStatusDes() {
            return statusDes;
        }

        public void setStatusDes(String statusDes) {
            this.statusDes = statusDes;
        }

        public long getCreateTime() {
            return createTime;
        }

        public void setCreateTime(long createTime) {
            this.createTime = createTime;
        }

        public String getFromUser() {
            return fromUser;
        }

        public void setFromUser(String fromUser) {
            this.fromUser = fromUser;
        }

        public String getToUser() {
            return toUser;
        }

        public void setToUser(String toUser) {
            this.toUser = toUser;
        }


        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getSystemId() {
            return systemId;
        }

        public void setSystemId(String systemId) {
            this.systemId = systemId;
        }

        public String getCreateTimeStr() {
            return createTimeStr;
        }

        public void setCreateTimeStr(String createTimeStr) {
            this.createTimeStr = createTimeStr;
        }

        public boolean isDelete() {
            return delete;
        }

        public void setDelete(boolean delete) {
            this.delete = delete;
        }

        public String getAppId() {
            return appId;
        }

        public void setAppId(String appId) {
            this.appId = appId;
        }

        public String getVersionName() {
            return versionName;
        }

        public void setVersionName(String versionName) {
            this.versionName = versionName;
        }
    }
}
