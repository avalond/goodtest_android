package com.haier.uhome.goodtaste.data.models.req;

import java.io.Serializable;

/**
 * Created by dallas on 16-5-7.
 */
public class ResourceInfoReq implements Serializable {
    private static final long serialVersionUID = -2410244022936937328L;
    private String resourceUrl;

    public ResourceInfoReq() {
    }

    public ResourceInfoReq(String resourceUrl) {
        this.resourceUrl = resourceUrl;
    }

    public String getResourceUrl() {
        return resourceUrl;
    }

    public void setResourceUrl(String resourceUrl) {
        this.resourceUrl = resourceUrl;
    }
}
