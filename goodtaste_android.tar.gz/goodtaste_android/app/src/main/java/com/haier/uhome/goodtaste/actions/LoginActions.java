package com.haier.uhome.goodtaste.actions;

import com.haier.uhome.goodtaste.data.models.AccType;

/**
 * Created by Administrator on 2016/5/13.
 */
public interface LoginActions {
    String ID_LOGIN = "user_login";
    String ID_3RD_PARTY_LOGIN = "user_3rd_party_login";
    String ID_LOGOUT = "user_logout";
    String ID_SAVE_PASSWORD = "save_password";

    /**
     * 默认是海尔官网用户登录
     *
     * @param loginId  登录用户名
     * @param password 密码
     */
    void login(String loginId, String password);

    /**
     * 第三方登录
     *
     * @param loginId               登录用户名, 由第三方平台返回
     * @param accType               用户类型 {@link AccType}
     * @param thirdPartyAppId       第三方平台应用ID，根据第三方平台验证需要，输入具体值
     * @param thirdPartyAccessToken 第三方平台安全令牌
     */
    void login(String loginId, @AccType.Type int accType, String thirdPartyAppId, String thirdPartyAccessToken);

    /**
     * 退出登录
     */
    void logout();

    /**
     * 保存密码
     */
    void savePassword(Boolean savestatus,String pwd);
}
