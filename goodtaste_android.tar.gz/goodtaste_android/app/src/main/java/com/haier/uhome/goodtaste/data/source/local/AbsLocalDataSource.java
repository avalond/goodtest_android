package com.haier.uhome.goodtaste.data.source.local;

import android.content.Context;

import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;

/**
 * Created by dallas on 16-4-18.
 */
public abstract class AbsLocalDataSource {
    protected RxPreference mPreference;
    protected Context mContext;

    public AbsLocalDataSource(RxPreference preference, Context context) {
        mPreference = preference;
        mContext = context;
    }
}
