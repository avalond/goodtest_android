package com.haier.uhome.goodtaste.ui.guide;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.HaierPreference;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.ui.main.HomeActivity;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;

public class WelcomeActivity extends BaseActivity {

    private static final String TAG = "WelcomeActivity";
    private Handler mHandler;
    private RxPreference preferences;
    private static final int DEFAULT_TIME_OUT = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_layout);
        init();
        goNextActivity(DEFAULT_TIME_OUT);
    }

    private void init(){
        hideToolbar();
        mHandler = new Handler(getMainLooper());
        preferences = DataManager.instance().getPreference();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    private void goNextActivity(int delay) {
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(preferences.getBoolean(HaierPreference.IS_FIRST_OPEN,true)){
                    Intent i = new Intent(WelcomeActivity.this, GuaidActivity.class);
                    startActivity(i);
                }else {
                    Intent i = new Intent(WelcomeActivity.this, HomeActivity.class);
                    startActivity(i);
                }
                finish();
            }
        }, delay);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onRxStoresRegister() {

    }

    @Override
    public void onRxStoresUnRegister() {

    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {

    }

    @Override
    public void onRxError(RxError error) {

    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }
}
