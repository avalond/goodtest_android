package com.haier.uhome.goodtaste.data.source.remote;

import android.support.annotation.NonNull;

import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.data.models.BaseEntity;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.TopVideoInfo;
import com.haier.uhome.goodtaste.data.models.VideoCommentInfo;
import com.haier.uhome.goodtaste.data.models.VideoInfo;
import com.haier.uhome.goodtaste.data.models.req.ResourceInfoReq;
import com.haier.uhome.goodtaste.data.models.req.VideoCommentReq;
import com.haier.uhome.goodtaste.data.source.VideoDataSource;
import com.haier.uhome.goodtaste.data.source.remote.services.VideoService;

import java.util.List;

import okhttp3.OkHttpClient;
import rx.Observable;

public class VideoRemoteDataSource extends AbsRemoteDataSource implements VideoDataSource {
    private final VideoService mVideoService;

    public VideoRemoteDataSource(@EnvironmentMode int mode, @NonNull OkHttpClient httpClient) {
        super(mode, httpClient);
        switch (mode) {
            case DEBUG:
                mVideoService = createService(VideoService.DEBUG_BASE_URL, VideoService.class);
                break;
            case DEBUG_VERIFY:
                mVideoService = createService(VideoService.DEBUG_VERIFY_BASE_URL, VideoService.class);
                break;
            case PRE_PRODUCT:
                mVideoService = createService(VideoService.PRE_PRODUCT_BASE_RUL, VideoService.class);
                break;
            case PRODUCT:
            default:
                mVideoService = createService(VideoService.PRODUCT_BASE_RUL, VideoService.class);
                break;
        }
    }

    @Override
    public Observable<List<TopVideoInfo>> getTopVideo(String userId, String updateTime) {
        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("time", updateTime);

        return mVideoService.getTopVideo(req)
            .compose(this.<BaseEntity<List<TopVideoInfo>>, List<TopVideoInfo>>getTransformer2());
    }

    @Override
    public Observable<BaseResult> postLike(String userId, String videoId) {
        JsonObject req = new JsonObject();
        req.addProperty("userId", userId);
        req.addProperty("videoId", videoId);

        return mVideoService.postLike(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<BaseResult> commentVideo(VideoCommentReq comment) {
        StringBuilder resUrl = new StringBuilder();
        if (comment.getResourceInfo() != null && comment.getResourceInfo().size() > 0) {
            for (ResourceInfoReq res : comment.getResourceInfo()) {
                resUrl.append(res.getResourceUrl());
                resUrl.append(",");
            }
            resUrl.deleteCharAt(resUrl.length() - 1);
        }
        JsonObject req = new JsonObject();
        req.addProperty("fromUser", comment.getFromUser());
        req.addProperty("toUser", comment.getToUser());
        req.addProperty("videoId", comment.getVideoId());
        req.addProperty("content", comment.getContent());
        req.addProperty("resourceUrls", resUrl.toString());


        return mVideoService.commentVideo(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<List<VideoInfo>> getVideoList(String albumId, int pageNum) {
        JsonObject req = new JsonObject();
        req.addProperty("albumId", albumId);
        req.addProperty("pageNum", pageNum + "");

        return mVideoService.getVideoList(req)
            .compose(this.<BaseEntity<List<VideoInfo>>, List<VideoInfo>>getTransformer2());
    }

    @Override
    public Observable<List<VideoInfo>> getVideoListByAlbumId(String albumId) {
        JsonObject req = new JsonObject();
        req.addProperty("albumId", albumId);
        req.addProperty("pageNum", 1);

        return mVideoService.getVideoListByAlbumId(req)
            .compose(this.<BaseEntity<List<VideoInfo>>, List<VideoInfo>>getTransformer2());
    }

    @Override
    public Observable<List<VideoCommentInfo>> getVideoComment(String videoId, String userId, String size) {
        JsonObject req = new JsonObject();
        req.addProperty("videoId", videoId);
        req.addProperty("loginUserId", userId);
        req.addProperty("selectSize", size);

        return mVideoService.getVideoComment(req)
            .compose(this.<BaseEntity<List<VideoCommentInfo>>, List<VideoCommentInfo>>getTransformer2());
    }

    @Override
    public Observable<List<VideoCommentInfo>> getMoreVideoComment(String videoId, String userId, int pageNum) {
        JsonObject req = new JsonObject();
        req.addProperty("videoId", videoId);
        req.addProperty("loginUserId", userId);
        req.addProperty("pageNum", pageNum + "");

        return mVideoService.getMoreVideoComment(req)
            .compose(this.<BaseEntity<List<VideoCommentInfo>>, List<VideoCommentInfo>>getTransformer2());
    }

    @Override
    public Observable<BaseResult> deleteVideoComment(String commentId, String videoId, String userId) {
        JsonObject req = new JsonObject();
        req.addProperty("commId", commentId);
        req.addProperty("videoId", videoId);
        req.addProperty("userId", userId);

        return mVideoService.deleteVideoComment(req).compose(this.<BaseResult>getTransformer());
    }

    @Override
    public Observable<VideoInfo> getVideoInfo(String videoId) {
        JsonObject req = new JsonObject();
        req.addProperty("videoId", videoId);

        return mVideoService.getVideoInfo(req).compose(this.<BaseEntity<VideoInfo>, VideoInfo>getTransformer2());
    }

    @Override
    public Observable<List<TopVideoInfo>> saveTopVideoInfo(List<TopVideoInfo> videoInfoList) {
        return null;
    }
}
