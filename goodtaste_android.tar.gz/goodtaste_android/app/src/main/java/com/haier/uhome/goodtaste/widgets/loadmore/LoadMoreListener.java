package com.haier.uhome.goodtaste.widgets.loadmore;

/**
 * Created by sharp on 16-5-7.
 */
public interface LoadMoreListener {

    /**
     * loading more
     */
    void onLoadMore();

}
