package com.haier.uhome.goodtaste.ui.login;

import com.tencent.tauth.IUiListener;
import com.tencent.tauth.UiError;

/**
 * Created by centling on 2016/3/25.
 */
public class BaseUiListener implements IUiListener {
    @Override
    public void onComplete(Object o) {

    }

    @Override
    public void onError(UiError uiError) {

    }

    @Override
    public void onCancel() {

    }
}
