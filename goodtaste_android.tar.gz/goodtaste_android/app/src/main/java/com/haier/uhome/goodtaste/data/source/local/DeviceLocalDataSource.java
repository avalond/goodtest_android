package com.haier.uhome.goodtaste.data.source.local;

import android.content.Context;

import com.haier.uhome.goodtaste.data.source.DeviceDataSource;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;

/**
 * Created by lijin on 16-5-6.
 */
public class DeviceLocalDataSource extends AbsLocalDataSource implements DeviceDataSource {
    public DeviceLocalDataSource(RxPreference preference, Context context) {
        super(preference, context);
    }

    
}
