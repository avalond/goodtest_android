package com.haier.uhome.goodtaste.ui.main.fragment;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.gmail.adffice.rxflux.util.SubscriptionManager;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.actions.HomePageActionCreator;
import com.haier.uhome.goodtaste.actions.HomePageActions;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.ChefInfo;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;
import com.haier.uhome.goodtaste.data.models.TopVideoInfo;
import com.haier.uhome.goodtaste.data.models.VideoData;
import com.haier.uhome.goodtaste.data.source.remote.services.H5HybirdUrl;
import com.haier.uhome.goodtaste.stores.BaseStore;
import com.haier.uhome.goodtaste.stores.ChefStore;
import com.haier.uhome.goodtaste.stores.RecipeStore;
import com.haier.uhome.goodtaste.stores.UserStore;
import com.haier.uhome.goodtaste.stores.VideoStore;
import com.haier.uhome.goodtaste.ui.BaseFragment;
import com.haier.uhome.goodtaste.ui.WebActivity;
import com.haier.uhome.goodtaste.ui.login.LoginActivity;
import com.haier.uhome.goodtaste.ui.main.HandleHomeDishInterface;
import com.haier.uhome.goodtaste.ui.main.HandleHomeHeaderInterface;
import com.haier.uhome.goodtaste.ui.main.HandleHomeRankInterface;
import com.haier.uhome.goodtaste.ui.main.HomeActivity;
import com.haier.uhome.goodtaste.ui.main.adapter.DishListAdapter;
import com.haier.uhome.goodtaste.ui.recipe.RecipeListActivity;
import com.haier.uhome.goodtaste.ui.videocomment.VideoCommentActivity;
import com.haier.uhome.goodtaste.utils.ErrorHandler;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.utils.NetWorkUtils;
import com.haier.uhome.goodtaste.widgets.CustomProgressDialog;
import com.haier.uhome.goodtaste.widgets.HomePtrClassicFrameLayout;
import com.haier.uhome.goodtaste.widgets.loadmore.HaoRecyclerView;
import com.haier.uhome.goodtaste.widgets.loadmore.LoadMoreListener;
import com.haier.uhome.goodtaste.widgets.ptr.PtrDefaultHandler;
import com.haier.uhome.goodtaste.widgets.ptr.PtrFrameLayout;
import com.haier.uhome.goodtaste.widgets.ptr.PtrHandler;


import java.util.ArrayList;
import java.util.List;

/**
 * Created by sharp on 16-5-3.
 */
public class FirstMainFragment extends BaseFragment {

    private static final String TAG = "FirstMainFragment";

    private LayoutInflater mLayoutInflater;
    private View mRootView;
    private HomePtrClassicFrameLayout mPtrFrame;//下拉刷新层
    private HaoRecyclerView hRecycleview;//推荐菜谱列表

    private UserStore mUserStore;
    private ChefStore mChefStore; //厨咖业务相关的store
    private VideoStore mVideoStore;//视频业务相关的store
    private RecipeStore mRecipeStore;//菜谱业务相关的store

    private List<TopVideoInfo> mTopVideoInfoList = new ArrayList<TopVideoInfo>();
    private List<ChefInfo> chefInfoList = new ArrayList<ChefInfo>();
    private List<RecipeWithUser> recipeWithUserList = new ArrayList<RecipeWithUser>();

    private DishListAdapter mDishListAdapter;

    private boolean isGetChefListFinished = true;
    private boolean isGetVideoListFinished = true;
    private boolean isGetRecipeListFinished = true;

    private HomePageActionCreator mHomePageActionCreator;

    private View mDishHeaderView;

    private int currentPage = 2;//上滑动加载更多，这个行为是从2开始计算的。
    private boolean canGetMoreRecipe = true;//是否正在刷新界面，true，允许加载更多
    private boolean loadMoreFail = false;//加载更多是否失败
    public final static String SER_KEY = "video.info";

    private CustomProgressDialog progressDialog;// 倒计时旋转进度

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mHomePageActionCreator = new HomePageActionCreator(getActivity(), getDataManager(), getDispatcher(),
            getSubscriptionManager());
        mLayoutInflater = LayoutInflater.from(getActivity());
        mRootView = initViews(mLayoutInflater);
        //        progressDialog = new CustomProgressDialog(getActivity(), 0);
        updateData();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return mRootView;
    }


    private View initViews(LayoutInflater inflater) {

        View contentView = inflater.inflate(R.layout.fragment_first_main, null);
        mPtrFrame = (HomePtrClassicFrameLayout) contentView.findViewById(R.id.menu_ptr_frame);
        mPtrFrame.setLastUpdateTimeRelateObject(this);
        mPtrFrame.setPtrHandler(mPtrHandler);

        // the following are default settings
        mPtrFrame.setResistance(1.7f);
        mPtrFrame.setRatioOfHeaderHeightToRefresh(1.2f);
        mPtrFrame.setDurationToClose(200);
        mPtrFrame.setDurationToCloseHeader(1000);
        mPtrFrame.setPullToRefresh(false);
        mPtrFrame.setKeepHeaderWhenRefresh(true);
        mPtrFrame.disableWhenHorizontalMove(true);

        mDishHeaderView = contentView.findViewById(R.id.header_dishlist);
        mDishHeaderView.setOnClickListener(null);
        TextView mAllDishBtn = (TextView) mDishHeaderView.findViewById(R.id.tv_all_dish);
        mAllDishBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(getActivity(), RecipeListActivity.class);
                startActivity(intent);
            }
        });

        mDishListAdapter = new DishListAdapter(getActivity(), recipeWithUserList, mHandleHomeHeaderInterface,
            mHandleHomeRankInterface, handleHomeDishInterface);

        int orientation = getLayoutManagerOrientation(getResources().getConfiguration().orientation);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), orientation, false);


        hRecycleview = (HaoRecyclerView) contentView.findViewById(R.id.menu_recyclerview);
        hRecycleview.setLayoutManager(layoutManager);

        hRecycleview.setLoadMoreListener(new LoadMoreListener() {
            @Override
            public void onLoadMore() {
                //当页面正在刷新，推荐菜谱列表为空的时候，不允许上滑动加载更多
                if (!canGetMoreRecipe || mDishListAdapter == null ||
                    mDishListAdapter.getmRecipeWithUserList().size() < 1) {
                    hRecycleview.setCanloadMore(false);
                    hRecycleview.loadMoreComplete();
                    return;
                }
                hRecycleview.setCanloadMore(true);
                mHomePageActionCreator.homeMoreDishRefresh(2, currentPage + 1, "");
            }
        });

        hRecycleview.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition();
                if (firstVisibleItemPosition >= 2) {
                    mDishHeaderView.setVisibility(View.VISIBLE);
                } else {
                    mDishHeaderView.setVisibility(View.GONE);
                }
            }
        });

        hRecycleview.setAdapter(mDishListAdapter);

        //此监听必须在setAdapter之后
        hRecycleview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //                Toast.makeText(getActivity(), "click-----position" + i, Toast.LENGTH_SHORT).show();
                //                 if (loadMoreFail && NetWorkUtils.isNetworkAvailable(getActivity())) {
                if (loadMoreFail) {
                    loadMoreFail = false;
                    hRecycleview.setloadFail();
                    hRecycleview.setCanloadMore(true);
                    mHomePageActionCreator.homeMoreDishRefresh(2, currentPage + 1, "");
                }
            }
        });

        return contentView;
    }


    private int getLayoutManagerOrientation(int activityOrientation) {
        if (activityOrientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
            return LinearLayoutManager.VERTICAL;
        } else {
            return LinearLayoutManager.HORIZONTAL;
        }
    }

    private PtrHandler mPtrHandler = new PtrHandler() {
        @Override
        public void onRefreshBegin(PtrFrameLayout frame) {
            //            if (NetWorkUtils.isNetworkAvailable(getActivity())) {
            updateData();
            //            } else {
            //                ((HomeActivity) getActivity()).showToast(getString(R.string.net_no));
            //                mPtrFrame.refreshComplete();
            //            }
        }

        @Override
        public boolean checkCanDoRefresh(PtrFrameLayout frame, View content, View header) {
            return PtrDefaultHandler.checkContentCanBePulledDown(frame, content, header);
        }
    };


    private void updateData() {
        canGetMoreRecipe = false;//刷新整个页面的时候，禁用上滑动加载更多
        isGetChefListFinished = false;
        isGetVideoListFinished = false;
        isGetRecipeListFinished = false;
        currentPage = 1;
        String userId = UserStore.get(getContext()).getUserId();
        mHomePageActionCreator.homeVideoRefresh(userId, "");
        //                mHomePageActionCreator.homePageRefresh();
        mHomePageActionCreator.homeRankRefresh();
        mHomePageActionCreator.homeDishRefresh(2, 1, "");
    }


    @Override
    public void onRxStoresRegister() {
        mChefStore = ChefStore.get(getActivity());
        mChefStore.register();
        mVideoStore = VideoStore.get(getActivity());
        mVideoStore.register();
        mRecipeStore = RecipeStore.get(getActivity());
        mRecipeStore.register();
        mUserStore = UserStore.get(getActivity());
        mUserStore.register();
    }

    @Override
    public void onRxStoresUnRegister() {
        mChefStore.unregister();
        mVideoStore.unregister();
        mRecipeStore.unregister();
        mUserStore.unregister();
    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {

        switch (change.getStoreId()) {
            case BaseStore.ID_SHOW_LOADING:
                //                showProgressDialog();
                break;
            case BaseStore.ID_STOP_LOADING:
                //                stopProgressDialog();
                break;
            case ChefStore.ID:
                switch (change.getRxAction().getType()) {
                    case HomePageActions.ID_RANK_REFRESH:
                        isGetChefListFinished = true;
                        if (mChefStore.getmChefInfoList() != null) {
                            chefInfoList.clear();
                            chefInfoList.addAll(mChefStore.getmChefInfoList());
                            //更新厨咖排行相关view
                            refreshChefView(chefInfoList);
                        }
                        break;
                    case HomePageActions.ID_PAGE_REFRESH:
                        isGetChefListFinished = true;
                        chefInfoList.clear();
                        chefInfoList.addAll(mChefStore.getmChefInfoList());
                        //更新厨咖排行相关view
                        refreshChefView(chefInfoList);
                        break;
                    case HomePageActions.ID_DEFINE_SUB:
                        HaierLoger.d(TAG, "得到了厨咖和当前用户的关注关系，需要刷新界面");
                        break;
                    case HomePageActions.ID_COOKER_SUBSCRIBE:
                        // progressDialog.setmProgressBarState(CustomProgressDialog.SUCCESS);
                        dismissDialog();
                        progressDialog = CustomProgressDialog.show(getActivity(), true, false, null,
                            CustomProgressDialog.SUCCESS);
                        refreshSubscribeView(true);
                        break;
                    case HomePageActions.ID_COOKER_UNSUBSCRIBE:
//                        progressDialog.setmProgressBarState(CustomProgressDialog.FAIL);
                        dismissDialog();
                        progressDialog = CustomProgressDialog.show(getActivity(), true, false, null,
                            CustomProgressDialog.FAIL);
                        refreshSubscribeView(false);
                        break;
                    default:
                        break;
                }
                break;
            case VideoStore.ID:
                switch (change.getRxAction().getType()) {
                    case HomePageActions.ID_VIDEO_REFRESH:
                        isGetVideoListFinished = true;
                        mTopVideoInfoList.clear();
                        mTopVideoInfoList.addAll(mVideoStore.getmTopVideoInfoList());
                        refreshVideoView(mTopVideoInfoList);
                        break;
                    default:
                        break;
                }
                break;
            case RecipeStore.ID:
                switch (change.getRxAction().getType()) {
                    case HomePageActions.ID_PAGE_REFRESH:
                        isGetRecipeListFinished = true;
                        recipeWithUserList = mRecipeStore.getRecipeWithUserList();
                        // 更新推荐菜谱相关
                        refreshRecipeView(recipeWithUserList);
                        break;
                    case HomePageActions.ID_DISH_REFRESH:
                        isGetRecipeListFinished = true;
                        recipeWithUserList = mRecipeStore.getRecipeWithUserList();
                        // 更新推荐菜谱相关
                        refreshRecipeView(recipeWithUserList);
                        break;
                    case HomePageActions.ID_DISH_MORE_REFRESH:
                        recipeWithUserList = mRecipeStore.getRecipeWithUserList();
                        if (recipeWithUserList == null || recipeWithUserList.size() < 1) {
                            hRecycleview.loadMoreEnd();
                        } else if (recipeWithUserList.size() > 1 && recipeWithUserList.size() < 10) {
                            hRecycleview.loadMoreEnd();
                            currentPage = currentPage + 1;//当前页码加1
                            addMoreRecipeView(recipeWithUserList);
                        } else {
                            currentPage = currentPage + 1;//当前页码加1
                            addMoreRecipeView(recipeWithUserList);
                        }
                        // 更新推荐菜谱相关
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }

    }


    @Override
    public void onRxError(RxError error) {

        ((HomeActivity) getActivity()).showToast(ErrorHandler.handelError(error.getThrowable(), getActivity()));
        switch (error.getAction().getType()) {
            case HomePageActions.ID_VIDEO_REFRESH:
                mPtrFrame.refreshComplete();
                break;
            case HomePageActions.ID_RANK_REFRESH:
                mPtrFrame.refreshComplete();
                break;
            case HomePageActions.ID_DISH_REFRESH:
                mPtrFrame.refreshComplete();
                break;
            case HomePageActions.ID_PAGE_REFRESH:
                mPtrFrame.refreshComplete();
                break;
            case HomePageActions.ID_DISH_MORE_REFRESH:
                //                hRecycleview.loadMoreComplete();
                loadMoreFail = true;
                hRecycleview.loadFail();
                break;
            default:
                break;

        }

    }

    /**
     * 改变关注状态
     *
     * @param state
     */
    private void refreshSubscribeView(boolean state) {
        if (mDishListAdapter != null) {
            mDishListAdapter.setUserSubscribeStatus(state);
        }
    }


    private void refreshChefView(List<ChefInfo> chefInfoList) {
        if (mDishListAdapter != null && chefInfoList != null && chefInfoList.size() > 0) {
            mDishListAdapter.setChefInfoList(chefInfoList);
        }
        finishTopRefreshComplete();
    }


    private void refreshVideoView(List<TopVideoInfo> topVideoInfoList) {
        if (mDishListAdapter != null && topVideoInfoList != null && topVideoInfoList.size() > 0) {
            mDishListAdapter.setTopVideoInfoList(topVideoInfoList);
        }
        finishTopRefreshComplete();
    }

    private void refreshRecipeView(List<RecipeWithUser> recipeWithUserList) {
        if (mDishListAdapter != null && recipeWithUserList != null && recipeWithUserList.size() > 0) {
            mDishListAdapter.setRecipeWithUserList(recipeWithUserList);
        }
        hRecycleview.loadMoreComplete();
        finishTopRefreshComplete();
    }

    private void addMoreRecipeView(List<RecipeWithUser> recipeWithUserList) {
        if (mDishListAdapter != null && recipeWithUserList != null && recipeWithUserList.size() > 0) {
            mDishListAdapter.addRecipeWithUserList(recipeWithUserList);
        }
        hRecycleview.loadMoreComplete();
    }

    private void finishTopRefreshComplete() {
        //        isGetChefListFinished && isGetVideoListFinished && isGetRecipeListFinished
        //        if (isGetRecipeListFinished) {
        if (isGetChefListFinished || isGetVideoListFinished || isGetRecipeListFinished) {
            mPtrFrame.refreshComplete();
        }

        //只有在菜谱刷新完成之后才能尝试让推荐菜谱加载更多（还要取决与当前推荐菜谱列表是否为空）
        if (isGetRecipeListFinished) {
            canGetMoreRecipe = true;
        }
    }


    /**
     * 首页header部分，今日厨咖部分点击时间的回调
     */
    private HandleHomeHeaderInterface mHandleHomeHeaderInterface = new HandleHomeHeaderInterface() {

        @Override
        public void onSubscribeUser(String followedUserId, String state) {

            //先判断是否登陆
            if (TextUtils.isEmpty(mUserStore.getAccessToken())) {
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivity(intent);
            } else {
                String userId = UserStore.get(getActivity()).getUserId();
                if ("0".equals(state)) {
//                    progressDialog.setmProgressBarState(CustomProgressDialog.LOADING_SUB);
//                    progressDialog.show();
                    progressDialog = CustomProgressDialog.show(getActivity(), false, false, null,
                        CustomProgressDialog.LOADING_SUB);
                    mHomePageActionCreator.homeCookerSubscribe(userId, followedUserId);
                } else if ("1".equals(state)) {
//                    progressDialog.setmProgressBarState(CustomProgressDialog.LOADING_UN);
//                    progressDialog.show();
                    progressDialog = CustomProgressDialog.show(getActivity(), false, false, null,
                        CustomProgressDialog.LOADING_UN);
                    mHomePageActionCreator.homeCookerUnSubscribe(userId, followedUserId);
                }
            }
        }

        @Override
        public void onCookerMainPage(String cookerUserId) {
            String userId = UserStore.get(getActivity()).getUserId();
            String url = H5HybirdUrl.instance().getCookerPersonalH5Url(cookerUserId, userId);
            String title = getActivity().getString(R.string.chef_page_title);
            startWebView(url, title, false);
        }

        @Override
        public void onVideoMainPage(VideoData videoData) {
            //Toast.makeText(getActivity(),
            // " 视频播放地址" + videoData.getVideoNetUrl(), Toast.LENGTH_LONG).show();
            Intent mIntent = new Intent(getActivity(), VideoCommentActivity.class);
            Bundle mBundle = new Bundle();
            mBundle.putSerializable(SER_KEY, videoData);
            mIntent.putExtras(mBundle);
            startActivity(mIntent);
        }

        @Override
        public void onVideoPraise(String videoId) {
            String userId = UserStore.get(getContext()).getUserId();
            mHomePageActionCreator.homeVideoPraise(userId, videoId);
        }
    };

    /**
     * 首页厨咖排名部分点击事件的回调
     */
    private HandleHomeRankInterface mHandleHomeRankInterface = new HandleHomeRankInterface() {
        @Override
        public void onCookerMainPage(String userId, String cookerUserId) {
            String url = H5HybirdUrl.instance().getCookerPersonalH5Url(cookerUserId, userId);
            startWebView(url, getString(R.string.chef_page_title), false);

        }

        @Override
        public void onCookerRankListPage() {
            String userId = UserStore.get(getContext()).getUserId();
            String url = H5HybirdUrl.instance().getCookersH5Url(userId);
            startWebView(url, getString(R.string.chef_more_title), false);
        }
    };

    /**
     * 首页推荐菜谱部分点击事件的回调
     */
    private HandleHomeDishInterface handleHomeDishInterface = new HandleHomeDishInterface() {
        @Override
        public void onDishCookerPage(String cookerUserId) {
            String userId = UserStore.get(getActivity()).getUserId();
            String url = H5HybirdUrl.instance().getCookerPersonalH5Url(cookerUserId, userId);
            String title = getActivity().getString(R.string.chef_page_title);
            startWebView(url, title, false);
        }

        @Override
        public void onDishMainPage(String recipeId, String title) {
            String userId = UserStore.get(getActivity()).getUserId();
            String url = H5HybirdUrl.instance().getDishDetailH5Url(recipeId, userId);
            startWebView(url, title, true);
        }

        @Override
        public void onDishPraise(String recipeId) {
            String userId = UserStore.get(getContext()).getUserId();
            mHomePageActionCreator.homeDishPraise(userId, recipeId);
        }
    };

    private void startWebView(String url, String title, boolean isShowShare) {
        HaierLoger.d(TAG, "url=" + url);
        HaierLoger.d(TAG, "title=" + title);
        Intent intent = new Intent().setClass(getActivity(), WebActivity.class);
        intent.putExtra(WebActivity.URL, url);
        intent.putExtra(WebActivity.TITLE, title);
        intent.putExtra(WebActivity.IS_SHOW_SHARE, isShowShare);
        startActivity(intent);
    }

    private DataManager getDataManager() {
        return ((HaierApplication) getActivity().getApplicationContext()).getDataManager();
    }

    private Dispatcher getDispatcher() {
        return ((HaierApplication) getActivity().getApplicationContext()).getRxFlux().getDispatcher();
    }

    private SubscriptionManager getSubscriptionManager() {
        return ((HaierApplication) getActivity().getApplicationContext()).getRxFlux().getSubscriptionManager();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == LoginActivity.RESULT_CODE) {
            String userId = UserStore.get(getActivity()).getUserId();
            //需要查询用户关注当前厨咖的状态
            // mHomePageActionCreator.homeIsSubscribe(userId,mTopVideoInfoList.get(0)
            // .getUserInfo().getUserId());
            mHomePageActionCreator.homeVideoRefresh(userId, "");
        }
    }

    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }
}
