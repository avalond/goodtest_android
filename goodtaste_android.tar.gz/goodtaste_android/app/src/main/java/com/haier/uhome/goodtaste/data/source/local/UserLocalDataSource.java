package com.haier.uhome.goodtaste.data.source.local;

import android.content.Context;
import android.text.TextUtils;

import com.haier.uhome.goodtaste.data.HaierPreference;
import com.haier.uhome.goodtaste.data.models.AccType;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.LoginInfo;
import com.haier.uhome.goodtaste.data.models.LoginType;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.data.models.MessageInfo_Table;
import com.haier.uhome.goodtaste.data.models.RewardInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo_Table;
import com.haier.uhome.goodtaste.data.models.UserProfileType;
import com.haier.uhome.goodtaste.data.models.UserScore;
import com.haier.uhome.goodtaste.data.source.UserDataSource;
import com.haier.uhome.goodtaste.utils.DateUtil;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;
import com.raizlabs.android.dbflow.runtime.transaction.process.ProcessModelInfo;
import com.raizlabs.android.dbflow.runtime.transaction.process.SaveModelTransaction;
import com.raizlabs.android.dbflow.sql.language.Method;
import com.raizlabs.android.dbflow.sql.language.SQLite;
import com.raizlabs.android.dbflow.sql.language.property.IProperty;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class UserLocalDataSource extends AbsLocalDataSource implements UserDataSource {
    public UserLocalDataSource(RxPreference preference, Context context) {
        super(preference, context);
    }

    @Override
    public Observable<BaseResult> register(String mobile, String password, String uvc, String inviteCode) {
        return null;
    }

    @Override
    public Observable<BaseResult> applyRegMsgCode(String mobile) {
        return null;
    }

    @Override
    public Observable<LoginInfo> login(String loginId, String password, @AccType.Type int accType,
        @LoginType.Type int loginType, String thirdPartyAppId, String thirdPartyAccessToken) {
        return null;
    }

    @Override
    public Observable<LoginInfo> login(String loginId, @AccType.Type int accType, String thirdPartyAppId,
        String thirdPartyAccessToken) {
        return null;
    }

    @Override
    public Observable<LoginInfo> login(String loginId, String password) {
        return null;
    }

    @Override
    public Observable<UserInfo> findUserInfoById(final String userId) {
        return Observable.create(new Observable.OnSubscribe<UserInfo>() {
            @Override
            public void call(Subscriber<? super UserInfo> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                UserInfo userInfo = SQLite.select()
                    .from(UserInfo.class)
                    .where(UserInfo_Table.userId.eq(userId))
                    .querySingle();

                if (userInfo != null && TextUtils.isEmpty(userInfo.getUserId())) {
                    userInfo = null;
                }

                subscriber.onNext(userInfo);
                subscriber.onCompleted();
            }
        }).observeOn(Schedulers.io());
    }

    @Override
    public Observable<BaseResult> updateUserInfoById(String userId, @UserProfileType.Type int type, String content) {
        return null;
    }

    @Override
    public Observable<MessageInfo> sendMsgToUser(String fromUserId, String toUserId,
                                                 String msg , String nickname,String avter) {
        return null;
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadPersonMsg(String userId) {
        return null;
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadMsgState(String userId) {
        return null;
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadMsgList(String userId) {
        return Observable.create(new Observable.OnSubscribe<List<MessageInfo>>() {
            @Override
            public void call(Subscriber<? super List<MessageInfo>> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }

                List<IProperty> properties = new ArrayList<>();
                Collections.addAll(properties, MessageInfo_Table.getAllColumnProperties());
                properties.add(Method.max(MessageInfo_Table.time));
                IProperty[] newProperties = new IProperty[properties.size()];
                properties.toArray(newProperties);

                // SELECT 'id', 'targetUid', 'msg', 'nickName', 'userBpic', 'avater', 'time', 'fromUid', MAX('time')
                // FROM MessageInfo GROUP BY targetUid
                List<MessageInfo> result = SQLite.select(newProperties)
                    .from(MessageInfo.class)
                    .groupBy(MessageInfo_Table.targetUid)
                    .queryList();

                subscriber.onNext(result);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadMsgListLocal(String userId) {
        return getUnReadMsgList(userId).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Observable<List<MessageInfo>> getUnReadMsgContent(final String userId,
                                                             final String targetUid  , final int maxIndex) {
        return Observable.create(new Observable.OnSubscribe<List<MessageInfo>>() {
            @Override
            public void call(Subscriber<? super List<MessageInfo>> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                List<MessageInfo> result = SQLite.select()
                    .from(MessageInfo.class)
                    .where(MessageInfo_Table.targetUid.eq(targetUid))
                    .limit(maxIndex).orderBy(MessageInfo_Table.time, false)
                    .queryList();
                //对请求到的数据再次进行排序
                Collections.sort(result, new Comparator<MessageInfo>() {
                    @Override
                    public int compare(MessageInfo lhs, MessageInfo rhs) {
                        if (DateUtil.getDateFromString(lhs.getTime(), "yyyy-MM-dd HH:mm:ss").getTime() >
                                DateUtil.getDateFromString(rhs.getTime(), "yyyy-MM-dd HH:mm:ss").getTime()) {
                            return 0;
                        }
                        if (DateUtil.getDateFromString(lhs.getTime(), "yyyy-MM-dd HH:mm:ss").getTime() >
                                DateUtil.getDateFromString(rhs.getTime(), "yyyy-MM-dd HH:mm:ss").getTime()) {
                            return 1;
                        }
                        return -1;
                    }
                });
                subscriber.onNext(result);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());
    }

    @Override
    public Observable<BaseResult> updateMsgStatus(String userId, String time) {
        return null;
    }

    @Override
    public Observable<UserScore> findUserPoint(String userId) {
        return null;
    }

    @Override
    public Observable<RewardInfo> rewardUser(String userId, String rewardUserId, String rewardScore) {
        return null;
    }

    @Override
    public void saveAccessToken(String token) {
        mPreference.put(HaierPreference.KEY_TOKEN, token);
    }

    @Override
    public void saveUserId(String userId) {
        mPreference.put(HaierPreference.KEY_USERID, userId);
    }

    @Override
    public Observable<UserInfo> saveUserInfo(final UserInfo userInfo) {
        return Observable.create(new Observable.OnSubscribe<UserInfo>() {
            @Override
            public void call(Subscriber<? super UserInfo> subscriber) {
                if (userInfo != null) {
                    userInfo.save();
                }

                subscriber.onNext(userInfo);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());

    }

    @Override
    public Observable<List<MessageInfo>> saveMessageInfo(final List<MessageInfo> messageInfoList) {
        return Observable.create(new Observable.OnSubscribe<List<MessageInfo>>() {
            @Override
            public void call(Subscriber<? super List<MessageInfo>> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }

                new SaveModelTransaction<>(ProcessModelInfo.withModels(messageInfoList)).onExecute();

                subscriber.onNext(messageInfoList);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());
    }
}
