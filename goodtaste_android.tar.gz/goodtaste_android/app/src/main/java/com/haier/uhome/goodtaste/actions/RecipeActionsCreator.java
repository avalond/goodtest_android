package com.haier.uhome.goodtaste.actions;

import android.content.Context;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.util.SubscriptionManager;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.HotKey;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;
import com.haier.uhome.goodtaste.data.models.RecomRecipe;
import com.haier.uhome.goodtaste.data.source.ChefDataSource;
import com.haier.uhome.goodtaste.data.source.RecipesDataSource;

import java.util.List;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;

/**
 * Created by sharp on 16-5-20.
 */
public class RecipeActionsCreator extends BaseActionCreator implements RecipeActions {


    private RecipesDataSource recipesRepository;

    public RecipeActionsCreator(Context context, DataManager dataManager, Dispatcher dispatcher,
        SubscriptionManager subscriptionManager) {
        super(context, dataManager, dispatcher, subscriptionManager);
        recipesRepository = mDataManager.getRecipesRepository();
    }

    @Override
    public void getGoodRecipe(int pageNum, String updateTime) {
        final RxAction action = newRxAction(ID_GOOD_RECIPE, null);
        if (hasRxAction(action)) {
            return;
        }

        Observable<List<RecomRecipe>> rpObservable = recipesRepository.getRecommendRecipeInfoList(pageNum, updateTime);
        Subscription subscription = rpObservable.subscribe(new Subscriber<List<RecomRecipe>>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(List<RecomRecipe> recomRecipes) {
                RxAction<List<RecomRecipe>> resultAction = newRxAction(ID_GOOD_RECIPE, recomRecipes);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }


    //得到全部菜谱
    @Override
    public void getAllRecipe(int pageNum) {
        final RxAction action = newRxAction(ID_ALL_RECIPE, null);
        if (hasRxAction(action)) {
            return;
        }
        Observable<List<RecipeWithUser>> rpObservable = recipesRepository.getRecipeInfoList(pageNum, "");
        Subscription subscription = rpObservable.subscribe(new Subscriber<List<RecipeWithUser>>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(List<RecipeWithUser> recipeWithUserList) {
                RxAction<List<RecipeWithUser>> resultAction = newRxAction(ID_ALL_RECIPE, recipeWithUserList);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    //得到关键词菜谱
    @Override
    public void getKeyRecipe(String recipeKey, int pageNum) {
        final RxAction action = newRxAction(ID_KEY_RECIPE, null);
        if (hasRxAction(action)) {
            return;
        }
        Observable<List<RecipeWithUser>> rpObservable = recipesRepository.queryRecipe(recipeKey, pageNum);
        Subscription subscription = rpObservable.subscribe(new Subscriber<List<RecipeWithUser>>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onNext(List<RecipeWithUser> recipeWithUserList) {
                RxAction<List<RecipeWithUser>> resultAction = newRxAction(ID_KEY_RECIPE, recipeWithUserList);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }


    //获得热搜词汇
    @Override
    public void getHotKey() {
        final RxAction action = newRxAction(ID_HOT_KEY, null);
        if (hasRxAction(action)) {
            return;
        }
        Observable<List<HotKey>> rpObservable = recipesRepository.getRecipeHotKey();

        Subscription subscription = rpObservable.subscribe(new Subscriber<List<HotKey>>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onNext(List<HotKey> hotKeys) {
                RxAction<List<HotKey>> resultAction = newRxAction(ID_HOT_KEY, hotKeys);
                postRxAction(resultAction);
            }
        });

        addRxAction(action, subscription);
    }

    /**
     * 菜谱点赞
     *
     * @param userId
     * @param recipeId
     */
    @Override
    public void recipePraise(String userId, String recipeId) {
        final RxAction action = newRxAction(ID_RECIPE_PRAISE, null);
        if (hasRxAction(action)) {
            return;
        }
        //        if (!NetWorkUtils.isNetworkAvailable(mContext)) {
        //            postError(action, new BaseException(mContext.getString(R.string.net_no)));
        //            return;
        //        }

        ChefDataSource repository = mDataManager.getChefRepository();
        Observable<BaseResult> cfObservable = repository.addPraise(userId, recipeId);
        Subscription subscription = cfObservable.subscribe(new Subscriber<BaseResult>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(BaseResult baseResult) {
                RxAction<BaseResult> resultAction = newRxAction(ID_RECIPE_PRAISE, baseResult);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }
}
