package com.haier.uhome.goodtaste.stores;

import android.content.Context;
import android.util.Log;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.actions.UserActions;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.BaseResult;

/**
 * Created by Administrator on 2016/5/8.
 */
public class UserRegisStore extends BaseStore {

    public static final String ID = "UserRegisStore";
    private BaseResult mRegisInfo;
    private BaseResult mVerifyInfo;
    private static UserRegisStore instance;


    public synchronized static UserRegisStore get(Context context) {
        if (instance == null) {
            HaierApplication app = (HaierApplication) context.getApplicationContext();
            instance = new UserRegisStore(app.getRxFlux().getDispatcher());
        }
        return instance;
    }
    protected UserRegisStore(Dispatcher dispatcher) {
        super(dispatcher);
    }
    @Override
    protected void onAction(RxAction action) {

        switch (action.getType()){
            case UserActions.ID_POST_UVC_MOBILE:
                mRegisInfo = (BaseResult) action.getData();
                break;
            case  UserActions.ID_REGISTER:
                mVerifyInfo = (BaseResult) action.getData();
                break;
            default:
                return;
        }
        postStoreChange(new RxStoreChange(ID, action));
    }
    public Boolean postSucceed(){
        return   mRegisInfo.getRetCode().equals(BaseResult.RET_OK);
    }
    public Boolean isVerifySucceed(){
        return mVerifyInfo!=null;
//      return  true;
    }

}
