package com.haier.uhome.goodtaste.ui.recipe.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.data.models.ChefInfo;
import com.haier.uhome.goodtaste.data.models.HotKey;
import com.haier.uhome.goodtaste.ui.main.HandleHomeRankInterface;
import com.haier.uhome.goodtaste.ui.recipe.RecipeSearchInterface;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.utils.ImageDownLoader;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sharp on 16-5-7.
 */
public class HotKeyAdapter extends BaseAdapter {
    private static final String TAG = "HotKeyAdapter";
    private Activity mActivity;
    private LayoutInflater mInflater = null;
    private List<HotKey> mData;
    private RecipeSearchInterface mRecipeSearchInterface;

    public HotKeyAdapter(Activity context, List<HotKey> pData,RecipeSearchInterface recipeSearchInterface) {
        mActivity = context;
        mInflater = LayoutInflater.from(mActivity);
        if (pData == null) {
            mData = new ArrayList<>();
        } else {
            mData = pData;
        }
        mRecipeSearchInterface = recipeSearchInterface;
    }

    @Override
    public int getCount() {
        // 在此适配器中所代表的数据集中的条目数
        return mData.size();
    }

    @Override
    public Object getItem(int position) {

        // 获取数据集中与指定索引对应的数据项
        return position;
    }

    @Override
    public long getItemId(int position) {

        // 获取在列表中与指定索引对应的行id
        return position;
    }

    // 获取一个在数据集中指定索引的视图来显示数据
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        // 如果缓存convertView为空，则需要创建View
        if (convertView == null) {
            holder = new ViewHolder();
            // 根据自定义的Item布局加载布局
            convertView = mInflater.inflate(R.layout.item_search_hotkey, null);
            holder.tvHotKeyItem = (TextView) convertView.findViewById(R.id.item_rank_cooker_name);
            // 将设置好的布局保存到缓存中，并将其设置在Tag里，以便后面方便取出Tag
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.tvHotKeyItem.setText(mData.get(position).getName());
        holder.tvHotKeyItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mRecipeSearchInterface.onSearchHotkey(mData.get(position).getName());
            }
        });
        return convertView;
    }

    // ViewHolder静态类
    static class ViewHolder {
        public TextView tvHotKeyItem;
    }

    public void updateHotKeyList(List<HotKey> list) {
        mData = list;
        HaierLoger.d(TAG, "list.size()" + list.size());
        notifyDataSetChanged();
    }
}
