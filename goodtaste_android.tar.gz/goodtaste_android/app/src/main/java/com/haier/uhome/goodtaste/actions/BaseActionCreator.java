package com.haier.uhome.goodtaste.actions;

import android.content.Context;
import android.support.annotation.NonNull;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.action.RxActionCreator;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.util.SubscriptionManager;
import com.haier.uhome.goodtaste.data.DataManager;

/**
 * <br>Created by dallas on 16-4-18.
 */
public abstract class BaseActionCreator extends RxActionCreator {
    protected Context mContext;
    protected DataManager mDataManager;

    public BaseActionCreator(Context context, DataManager dataManager, Dispatcher dispatcher,
        SubscriptionManager subscriptionManager) {
        super(dispatcher, subscriptionManager);
        mContext = context.getApplicationContext();
        mDataManager = dataManager;
    }

    /**
     * 发送显示加载对话框事件。
     *
     * @param msg 提示信息
     */
    protected void postShowLoading(String msg) {
        postRxAction(newRxAction(LoadingIndicatorActions.ID_SHOW_LOADING, msg));
    }

    /**
     * 发送取消加载对话框事件。
     */
    protected void postStopLoading() {
        postRxAction(newRxAction(LoadingIndicatorActions.ID_STOP_LOADING, null));
    }

    @Override
    protected void postError(@NonNull RxAction action, Throwable throwable) {
        postStopLoading();
        super.postError(action, throwable);
    }
}
