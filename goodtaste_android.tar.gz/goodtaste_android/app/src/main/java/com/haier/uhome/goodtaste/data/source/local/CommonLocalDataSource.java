package com.haier.uhome.goodtaste.data.source.local;

import android.content.Context;
import android.text.TextUtils;

import com.haier.uhome.goodtaste.data.HaierPreference;
import com.haier.uhome.goodtaste.data.models.AccType;
import com.haier.uhome.goodtaste.data.models.AppVersionResult;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.GatewayResult;
import com.haier.uhome.goodtaste.data.models.ResourceResult;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo_Table;
import com.haier.uhome.goodtaste.data.models.UvcResult;
import com.haier.uhome.goodtaste.data.models.Validate;
import com.haier.uhome.goodtaste.data.source.CommonDataSource;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;
import com.raizlabs.android.dbflow.sql.language.SQLite;

import java.io.File;

import rx.Observable;
import rx.Subscriber;
import rx.schedulers.Schedulers;

/**
 * <br>Created by dallas on 16-4-18.
 */
public class CommonLocalDataSource extends AbsLocalDataSource implements CommonDataSource {

    public CommonLocalDataSource(RxPreference preference, Context context) {
        super(preference, context);
    }

    @Override
    public Observable<BaseResult> logout() {
        return Observable.create(new Observable.OnSubscribe<BaseResult>() {
            @Override
            public void call(Subscriber<? super BaseResult> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                String uid = mPreference.getString(HaierPreference.KEY_USERID, "");
                // 清除token
                mPreference.remove(HaierPreference.KEY_TOKEN);
                // 清除userId
                mPreference.remove(HaierPreference.KEY_USERID);
                // 清除userId对应的用户信息
                if (!TextUtils.isEmpty(uid)) {
                    SQLite.delete().from(UserInfo.class).where(UserInfo_Table.userId.eq(uid));
                }

                BaseResult result = new BaseResult(BaseResult.RET_OK, "success");
                subscriber.onNext(result);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());
    }

    @Override
    public Observable<GatewayResult> getDeviceGateWay(String userId, String sdkVer, String platform, String model) {
        return null;
    }

    @Override
    public Observable<AppVersionResult> getAppVersionInfo(String appId) {
        return null;
    }

    @Override
    public Observable<UvcResult> postUserVerificationCode(String account, @Validate.Type int type,
        @Validate.Scene int scene, String sendTo, @AccType.Type int accType) {
        return null;
    }

    @Override
    public Observable<UvcResult> postUvcMobile(String account, String mobile, @Validate.Scene int scene) {
        return null;
    }

    @Override
    public Observable<UvcResult> postUvcEmail(String account, String email, @Validate.Scene int scene) {
        return null;
    }

    @Override
    public Observable<BaseResult> verifyUserVerificationCode(String uvc, String account, @Validate.Type int type,
        @Validate.Scene int scene, String transactionId, @AccType.Type int accType) {
        return null;
    }

    @Override
    public Observable<BaseResult> verifyUvcMobile(String uvc, String account, String transactionId,
        @Validate.Scene int scene) {
        return null;
    }

    @Override
    public Observable<BaseResult> verifyUvcEmail(String uvc, String account, String transactionId,
        @Validate.Scene int scene) {
        return null;
    }

    @Override
    public Observable<ResourceResult> assignResource(String useType, String id, String type, String ext, String name,
        String description) {
        return null;
    }

    @Override
    public Observable<String> uploadAvatar(String userId, File file) {
        return null;
    }

}
