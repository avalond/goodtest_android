package com.haier.uhome.goodtaste.actions;

import android.content.Context;
import android.text.TextUtils;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.util.SubscriptionManager;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.data.source.UserDataSource;

import java.util.List;

import rx.Subscriber;
import rx.Subscription;

/**
 * Created by Administrator on 2016/5/6.
 */
public class MessageActionCreator extends BaseActionCreator implements MessageActions {
    public MessageActionCreator(Context context, DataManager dataManager,
                                Dispatcher dispatcher, SubscriptionManager subscriptionManager) {
        super(context, dataManager, dispatcher, subscriptionManager);
    }

    public void send(String fromUserId, String toUserId, String msg , String nickname ,String avter) {

        final RxAction action = newRxAction(SEND_MESSAGE, null);
        if (hasRxAction(action)) {
            return;
        }
        if (TextUtils.isEmpty(msg)) {
            return;
        }

        UserDataSource repository = mDataManager.getUserRepository();
        Subscription subscription =
                repository.sendMsgToUser(fromUserId, toUserId, msg ,nickname ,avter).subscribe(
                        new Subscriber<MessageInfo>() {
                            @Override
                            public void onCompleted() {
                            }

                            @Override
                            public void onError(Throwable e) {
                                postError(action, e);
                            }

                            @Override
                            public void onNext(MessageInfo messageInfo) {

                                RxAction<MessageInfo> resultAction = newRxAction(SEND_MESSAGE, messageInfo);
                                postRxAction(resultAction);
                            }
                        });
        addRxAction(action, subscription);

    }

    public void getUnReadMsgContent(String fromUserId, String toUserId ,int maxIndex){

        final RxAction action = newRxAction(GET_UNREAD_MESSAGE_CURRENT, null);
        if (hasRxAction(action)) {
            return;
        }


        UserDataSource repository = mDataManager.getUserRepository();
        Subscription subscription =
                repository.getUnReadMsgContent(fromUserId, toUserId , maxIndex).subscribe(
                        new Subscriber<List<MessageInfo>>() {
                            @Override
                            public void onCompleted() {
                                postStopLoading();
                            }

                            @Override
                            public void onError(Throwable e) {
                                postError(action, e);
                            }

                            @Override
                            public void onNext(List<MessageInfo> messageInfo) {

                                RxAction<List<MessageInfo>> resultAction = newRxAction(GET_UNREAD_MESSAGE_CURRENT,
                                        messageInfo);
                                postRxAction(resultAction);
                            }
                        });
        addRxAction(action, subscription);
    }

    @Override
    public String receive() {
        return null;
    }

    @Override
    public void sendSuccess() {

    }

    @Override
    public void sendErro() {

    }

    //对集合进行排序
   /* public void sort(List queryList) {
        Collections.sort(queryList, new Comparator<MessageInfo>() {
            @Override
            public int compare(MessageInfo lhs, MessageInfo rhs) {
                if (DateUtil.getDateFromString(lhs.getTime(), "yyyy-MM-dd HH:mm:ss").getTime() >
                        DateUtil.getDateFromString(rhs.getTime(), "yyyy-MM-dd HH:mm:ss").getTime()) {
                    return 0;
                }
                if (DateUtil.getDateFromString(lhs.getTime(), "yyyy-MM-dd HH:mm:ss").getTime() >
                        DateUtil.getDateFromString(rhs.getTime(), "yyyy-MM-dd HH:mm:ss").getTime()) {
                    return 1;
                }
                return -1;
            }
        });
    }

    //获取数据集合的最大值
    public List<MessageInfo> getMaxList(int index, String msgid, int maxIndex) {
        int size = new Select().from(MessageInfo.class).where(MessageInfo_Table.id.eq(msgid)).queryList().size();
        if (size < maxIndex) {
            maxIndex = size;
        }
        List<MessageInfo> list = new Select().from(MessageInfo.class).where(MessageInfo_Table.id.eq(msgid))
                .queryList().subList(index, maxIndex);
        return list;
    }*/

}
