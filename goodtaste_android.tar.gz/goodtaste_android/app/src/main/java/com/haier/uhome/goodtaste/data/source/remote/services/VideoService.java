package com.haier.uhome.goodtaste.data.source.remote.services;

import com.google.gson.JsonObject;
import com.haier.uhome.goodtaste.data.models.BaseEntity;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.TopVideoInfo;
import com.haier.uhome.goodtaste.data.models.VideoCommentInfo;
import com.haier.uhome.goodtaste.data.models.VideoInfo;

import java.util.List;

import retrofit2.http.Body;
import retrofit2.http.POST;
import rx.Observable;

/**
 * 视频
 */
public interface VideoService {
    String DEBUG_BASE_URL = "http://" + BaseService.DEBUG_HOST + ":7480/";
    String DEBUG_VERIFY_BASE_URL = "http://" + BaseService.DEBUG_VERIFY_HOST + ":7480/";
    String PRE_PRODUCT_BASE_RUL = "http://" + BaseService.PRE_PRODUCT_HOST + ":7260/";
    String PRODUCT_BASE_RUL = "http://" + BaseService.PRODUCT_HOST + ":7260/";

    @POST("foodStreetData/recipe/market/getTopVideo")
    Observable<BaseEntity<List<TopVideoInfo>>> getTopVideo(@Body JsonObject req);

    @POST("foodStreetData/recipe/market/getVideoList")
    Observable<BaseEntity<List<VideoInfo>>> getVideoList(@Body JsonObject req);

    @POST("foodStreetData/recipe/market/getVideoListByType")
    Observable<BaseEntity<List<VideoInfo>>> getVideoListByAlbumId(@Body JsonObject req);

    @POST("foodStreetData/recipe/market/addVideoPraise")
    Observable<BaseResult> postLike(@Body JsonObject req);

    @POST("foodStreetData/recipe/market/commentVideo")
    Observable<BaseResult> commentVideo(@Body JsonObject req);

    @POST("foodStreetData/recipe/market/findCommVideoById")
    Observable<BaseEntity<List<VideoCommentInfo>>> getVideoComment(@Body JsonObject req);

    @POST("foodStreetData/recipe/market/findCommVideoByIdMore")
    Observable<BaseEntity<List<VideoCommentInfo>>> getMoreVideoComment(@Body JsonObject req);

    @POST("foodStreetData/recipe/market/delCommentVideo")
    Observable<BaseResult> deleteVideoComment(@Body JsonObject req);

    @POST("foodStreetData/recipe/market/findInfoVideoById")
    Observable<BaseEntity<VideoInfo>> getVideoInfo(@Body JsonObject req);
}
