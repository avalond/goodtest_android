package com.haier.uhome.goodtaste.stores;

import android.content.Context;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.actions.HomePageActions;
import com.haier.uhome.goodtaste.data.models.ChefInfo;
import com.haier.uhome.goodtaste.data.models.MainRefreshInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sharp on 16-5-8.
 */
public class ChefStore extends BaseStore {

    private static ChefStore instance;

    public synchronized static ChefStore get(Context context) {
        if (instance == null) {
            HaierApplication app = (HaierApplication) context.getApplicationContext();
            instance = new ChefStore(app.getRxFlux().getDispatcher());
        }
        return instance;
    }


    protected ChefStore(Dispatcher dispatcher) {
        super(dispatcher);
    }


    private List<ChefInfo> mChefInfoList = new ArrayList<>();

    private boolean isSubscribe = false;
    public static final String ID = "ChefStore";

    @Override
    protected void onAction(RxAction action) {
        switch (action.getType()) {
            case HomePageActions.ID_VIDEO_REFRESH:
                //                mChefInfoList = (List<ChefInfo>) action.getData();
                break;
            case HomePageActions.ID_PAGE_REFRESH:
                mChefInfoList = ((MainRefreshInfo) action.getData()).getChefInfoList();
                //需要在此将成功返回的(非空)数据写入数据库缓存起来
            case HomePageActions.ID_RANK_REFRESH:
                List<ChefInfo> temp = new ArrayList<>();
                if (mChefInfoList == null || mChefInfoList.size() == 0) {
                    mChefInfoList = new ArrayList<>();
                } else {
                    mChefInfoList.clear();
                }
                temp = (List<ChefInfo>) action.getData();
                if (temp.size() >= 5) {
                    for (int i = 0; i < 5; i++) {
                        mChefInfoList.add(temp.get(i));
                    }
                } else if (temp.size() > 0 && temp.size() < 5) {
                    for (int i = 0; i < temp.size(); i++) {
                        mChefInfoList.add(temp.get(i));
                    }
                }

                break;
            case HomePageActions.ID_DEFINE_SUB:
                isSubscribe = (boolean) action.getData();
                break;
            case HomePageActions.ID_COOKER_SUBSCRIBE:
                break;
            case HomePageActions.ID_COOKER_UNSUBSCRIBE:
                break;
            default: // 重要！！！重要！！！重要！！！ 如果不需要处理那么就要忽略该事件
                return;
        }
        postStoreChange(new RxStoreChange(ID, action));
    }


    public List<ChefInfo> getmChefInfoList() {
        return mChefInfoList;
    }

    public boolean getIsSubscribe() {
        return isSubscribe;
    }
}
