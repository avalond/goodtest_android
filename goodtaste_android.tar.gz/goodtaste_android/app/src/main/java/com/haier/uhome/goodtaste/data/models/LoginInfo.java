package com.haier.uhome.goodtaste.data.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by dallas on 16-5-6.
 */
public class LoginInfo implements Serializable {
    private static final long serialVersionUID = -5210845907798540682L;

    private String userId;
    private String accessToken;
    @SerializedName("actived")
    private boolean activated;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public boolean isActivated() {
        return activated;
    }

    public void setActivated(boolean activated) {
        this.activated = activated;
    }
}
