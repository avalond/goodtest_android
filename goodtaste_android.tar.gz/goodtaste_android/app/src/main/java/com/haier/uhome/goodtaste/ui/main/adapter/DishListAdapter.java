package com.haier.uhome.goodtaste.ui.main.adapter;


import android.app.Activity;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.data.models.ChefInfo;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;
import com.haier.uhome.goodtaste.data.models.TopVideoInfo;
import com.haier.uhome.goodtaste.data.models.UserScore;
import com.haier.uhome.goodtaste.data.source.remote.services.H5HybirdUrl;
import com.haier.uhome.goodtaste.stores.UserStore;
import com.haier.uhome.goodtaste.ui.WebActivity;
import com.haier.uhome.goodtaste.ui.main.HandleHomeDishInterface;
import com.haier.uhome.goodtaste.ui.main.HandleHomeHeaderInterface;
import com.haier.uhome.goodtaste.ui.main.HandleHomeRankInterface;
import com.haier.uhome.goodtaste.ui.recipe.RecipeListActivity;
import com.haier.uhome.goodtaste.utils.DimensionPixelUtil;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.utils.ImageDownLoader;

import java.util.List;


/**
 * Created by sharp on 16-5-5.
 */
public class DishListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final String TAG = "HomeDeviceListAdapter";
    private Activity mActivity;
    private LayoutInflater mLayoutInflater;
    private static final int HEAD_ITEM = 0;
    private static final int RANK_ITEM = HEAD_ITEM + 1;
    private static final int DISH_ITEM = HEAD_ITEM + 2;
    private HeadCookerHolder mHeadCookerHolder;
    private RankHolder mRankHolder;
    private List<TopVideoInfo> mTopVideoInfoList;
    private List<ChefInfo> mChefInfoList;
    private List<RecipeWithUser> mRecipeWithUserList;


    private HandleHomeHeaderInterface mHandleHomeHeaderInterface;
    private HandleHomeRankInterface mHandleHomeRankInterface;
    private HandleHomeDishInterface mHandleHomeDishInterface;

    public DishListAdapter(Activity context, List<RecipeWithUser> recipeWithUserList,
        HandleHomeHeaderInterface mHeaderInterface, HandleHomeRankInterface mRankInterface,
        HandleHomeDishInterface mDishInterface) {
        mActivity = context;
        //        mDishItemList = dishItemList;
        mRecipeWithUserList = recipeWithUserList;
        mHandleHomeHeaderInterface = mHeaderInterface;
        mHandleHomeRankInterface = mRankInterface;
        mHandleHomeDishInterface = mDishInterface;
        mLayoutInflater = LayoutInflater.from(mActivity);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        View view = null;
        switch (viewType) {
            case HEAD_ITEM:
                view = mLayoutInflater.inflate(R.layout.layout_header_fragment_first_main, parent, false);
                mHeadCookerHolder = new HeadCookerHolder(view, mActivity);
                viewHolder = mHeadCookerHolder;
                break;
            case RANK_ITEM:
                view = mLayoutInflater.inflate(R.layout.layout_rank_fragment_first_main, parent, false);
                mRankHolder = new RankHolder(view, mActivity);
                viewHolder = mRankHolder;
                break;
            case DISH_ITEM:
                view = mLayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_fragment_first_main_dish_layout, parent, false);
                viewHolder = new DishListHolder(view, mActivity);
                break;
            default:
                // view = mLayoutInflater.from(parent.getContext()).inflate(R.layout.view_item, parent, false);
                //viewHolder = new DishListHolder(view, mActivity);
                break;
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {

        switch (getItemViewType(position)) {
            case HEAD_ITEM:
                break;
            case RANK_ITEM:
                if (holder instanceof RankHolder) {
                    RankHolder rankHolder = (RankHolder) holder;
                    rankHolder.moreRank.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mHandleHomeRankInterface.onCookerRankListPage();
                        }
                    });
                    rankHolder.rankGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            String userId = UserStore.get(mActivity).getUserId();
                            ChefInfo chefInfo = mChefInfoList.get(position);
                            String cookerId = "";
                            if (chefInfo != null) {
                                cookerId = chefInfo.getUserId();
                            }
                            mHandleHomeRankInterface.onCookerMainPage(userId, cookerId);
                        }
                    });
                }
                break;
            case DISH_ITEM:
                if (holder instanceof DishListHolder) {
                    DishListHolder dishListHolder = (DishListHolder) holder;

                    if (position == 2) {
                        dishListHolder.headerView.setVisibility(View.VISIBLE);
                        dishListHolder.headerView.setOnClickListener(null);
                        dishListHolder.mAllDishBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent();
                                intent.setClass(mActivity, RecipeListActivity.class);
                                mActivity.startActivity(intent);
                            }
                        });
                    } else {
                        dishListHolder.headerView.setVisibility(View.GONE);
                    }

                    if (position - 2 >= 0) {
                        refreshDishItemView(position - 2, dishListHolder);
                    }
                }
                break;
            default:

                break;
        }

    }

    @Override
    public int getItemCount() {
        return mRecipeWithUserList.size() + 2;

    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0) {
            return HEAD_ITEM;
        }
        if (position == 1) {
            return RANK_ITEM;
        }
        RecipeWithUser item = getRecipeItemFromList(position - 2);
        if (item != null) {
            return getType(item);
        }
        return super.getItemViewType(position);
    }

    @Nullable
    private RecipeWithUser getRecipeItemFromList(int pos) {
        if (mRecipeWithUserList != null && pos > -2 && pos < mRecipeWithUserList.size()) {
            return mRecipeWithUserList.get(pos);
        }
        return null;
    }

    private int getType(RecipeWithUser item) {
        if (item == null) {
            HaierLoger.e(TAG, "getType info = null");
            return -1;
        }
        return DISH_ITEM;
    }


    @Nullable
    private TopVideoInfo getTopVideoInfo(int index) {
        if (mTopVideoInfoList != null && mTopVideoInfoList.size() > 0) {
            if (mTopVideoInfoList.get(index) != null) {
                return mTopVideoInfoList.get(index);
            }
        }
        return null;
    }

    /**
     * 顶部今日厨咖部分的ViewHolder
     */
    class HeadCookerHolder extends RecyclerView.ViewHolder {

        Activity mActivity;
        ImageView cookerPic;
        TextView cookerName;
        ImageView videoPraise;
        ImageView cookerSubscribe;

        ImageView mBGImageView;
        ViewPager mViewPager;
        LinearLayout mIndicatorLayout;
        int mActivePosition = -1;

        CookerPagerAdapter mCookerPagerAdapter;
        int mPosition = 0;//当前处于前台显示的pager页下标

        private ViewPager.OnPageChangeListener mOnPageChangeListener = new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                mPosition = position;
                updateIndicator(position);
                //                refreshTopBarView(position);//按照需求，此处不需要跟随pager切换而刷新，故注释掉
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        };

        public HeadCookerHolder(View itemView, final Activity activity) {
            super(itemView);
            mActivity = activity;
            cookerPic = (ImageView) itemView.findViewById(R.id.iv_today_cooker_pic);
            cookerName = (TextView) itemView.findViewById(R.id.tv_today_cooker_name);

            videoPraise = (ImageView) itemView.findViewById(R.id.iv_praise);
            cookerSubscribe = (ImageView) itemView.findViewById(R.id.iv_subscribe);

            mViewPager = (ViewPager) itemView.findViewById(R.id.vp_today_cooker_flash);
            mIndicatorLayout = (LinearLayout) itemView.findViewById(R.id.ll_dot_indicator);

            mViewPager.addOnPageChangeListener(mOnPageChangeListener);
            mViewPager.setOffscreenPageLimit(1);
            mCookerPagerAdapter = new CookerPagerAdapter(mActivity, mTopVideoInfoList, mHandleHomeHeaderInterface);
            mViewPager.setAdapter(mCookerPagerAdapter);
            mCookerPagerAdapter.notifyDataSetChanged();
        }

        public void refreshTopBarView(int index) {
            if (getTopVideoInfo(index) != null) {
                final TopVideoInfo videoInfo = getTopVideoInfo(index);
                String cookerId = "";
                String cookerPicUrl = "";
                String videoId = "";
                if (videoInfo.getUserInfo() != null) {

                    cookerId = videoInfo.getUserInfo().getUserId();
                    cookerPicUrl = videoInfo.getUserInfo().getAvater();
                    videoId = videoInfo.getData().getAlbumId();

                    ImageDownLoader.get(mActivity).display(cookerPicUrl, R.drawable.test_pic_user, cookerPic);
                    cookerName.setText(videoInfo.getUserInfo().getNickName());

                    //cooker头像--跳转厨咖主页
                    final String finalCookerId = cookerId;
                    cookerPic.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mHandleHomeHeaderInterface.onCookerMainPage(finalCookerId);
                        }
                    });
                    //点赞--视频点赞
                    final String finalVideoId = videoId;
                    videoPraise.setImageResource(R.drawable.btn_to_like);
                    videoPraise.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (!videoInfo.getData().getIsPraise() && !TextUtils.isEmpty(finalVideoId)) {
                                videoInfo.getData().setIsPraise(true);
                                videoPraise.setImageResource(R.drawable.btn_liked);
                                mHandleHomeHeaderInterface.onVideoPraise(finalVideoId);
                            }
                            // else {
                            //  Toast.makeText(mActivity, "菜谱", Toast.LENGTH_SHORT).show();
                            //}
                        }
                    });
                    //关注--根据取到的关注状态选择加载图
                    final String state = videoInfo.getSubscribeStatus();
                    if ("0".equals(state)) {
                        cookerSubscribe.setImageResource(R.drawable.btn_follow);
                    } else if ("1".equals(state)) {
                        cookerSubscribe.setImageResource(R.drawable.btn_followed);
                    }
                    //点击关注用户
                    cookerSubscribe.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mHandleHomeHeaderInterface.onSubscribeUser(finalCookerId, state);
                        }
                    });
                }
            }
        }

        public void addIndicator(int count) {
            removeIndicator();
            mActivePosition = -1;
            if (count <= 0) {
                return;
            }
            for (int i = 0; i < count; i++) {
                ImageView img = new ImageView(mActivity);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
                params.leftMargin = (int) DimensionPixelUtil.dip2px(mActivity, 3f);
                params.rightMargin = (int) DimensionPixelUtil.dip2px(mActivity, 3f);
                img.setImageResource(R.drawable.dot_light);
                mIndicatorLayout.addView(img, params);
            }
            if (count == 1) {
                updateIndicator(0);
            } else {
                updateIndicator(mViewPager.getCurrentItem());
            }
        }

        private void removeIndicator() {
            mIndicatorLayout.removeAllViews();
        }

        private void updateIndicator(int position) {
            if (mActivePosition != position) {
                if (mCookerPagerAdapter != null) {
                    String url = mCookerPagerAdapter.getCurrentCityBGURL(position);
                    //                    updateTopVideoBG(url);
                }
                if (mActivePosition == -1) {
                    ImageView imageView = ((ImageView) mIndicatorLayout.getChildAt(position));
                    if (imageView != null) {
                        imageView.setImageResource(R.drawable.dot_white);
                    }
                    mActivePosition = position;
                    return;
                }
                ImageView imageView = ((ImageView) mIndicatorLayout.getChildAt(mActivePosition));
                if (imageView != null) {
                    imageView.setImageResource(R.drawable.dot_light);
                }
                ImageView imgView = ((ImageView) mIndicatorLayout.getChildAt(position));
                if (imgView != null) {
                    imgView.setImageResource(R.drawable.dot_white);
                }
                mActivePosition = position;
            }

        }

        public void updateTopVideoBG(String picURL) {
            ImageDownLoader.get(mActivity)
                .display(picURL, R.drawable.test_pic_dish, R.drawable.test_pic_dish, mBGImageView);
        }
    }

    class HeaderHolder extends RecyclerView.ViewHolder {

        Activity mActivity;
        TextView moreDish;

        public HeaderHolder(View itemView, final Activity activity) {
            super(itemView);
            mActivity = activity;
            moreDish = (TextView) itemView.findViewById(R.id.tv_all_dish);
        }
    }

    /**
     * 推荐菜谱列表的ViewHolder
     */
    class DishListHolder extends RecyclerView.ViewHolder {

        Activity mActivity;
        //菜谱名，口味，时间，难易，点赞数，厨咖昵称
        TextView dishName;
        TextView cuisineName;
        TextView levelName;
        TextView duringName;
        TextView praiseNumName;
        TextView cookerName;

        //菜谱图，点赞图标，用户头像
        ImageView goodDishImage;
        ImageView dishPraiseImage;
        ImageView dishCookerImage;
        View headerView;
        TextView mAllDishBtn;

        public DishListHolder(View itemView, final Activity activity) {
            super(itemView);
            mActivity = activity;
            dishName = (TextView) itemView.findViewById(R.id.tv_item_dish_name);
            cuisineName = (TextView) itemView.findViewById(R.id.tv_dish_tip_cuisine);
            levelName = (TextView) itemView.findViewById(R.id.tv_dish_tip_level);
            duringName = (TextView) itemView.findViewById(R.id.tv_dish_tip_during);
            praiseNumName = (TextView) itemView.findViewById(R.id.tv_dish_praise_num);
            cookerName = (TextView) itemView.findViewById(R.id.tv_dish_cooker_name);

            goodDishImage = (ImageView) itemView.findViewById(R.id.iv_good_dish_pic);
            dishPraiseImage = (ImageView) itemView.findViewById(R.id.iv_dish_praise_pic);
            dishCookerImage = (ImageView) itemView.findViewById(R.id.iv_dish_cooker_pic);
            headerView = (View) itemView.findViewById(R.id.header_dishlist);
            mAllDishBtn = (TextView) itemView.findViewById(R.id.tv_all_dish);
        }
    }

    /**
     * 刷新推荐菜谱的相关view
     *
     * @param pos
     */
    public void refreshDishItemView(final int pos, final DishListHolder dishListHolder) {
        if (mRecipeWithUserList == null || mRecipeWithUserList.size() < 1) {
            return;
        }
        final RecipeWithUser mRecipeWithUser = mRecipeWithUserList.get(pos);
        if (mRecipeWithUser == null) {
            return;
        }

        //菜谱相关
        String dishNameStr = "";
        String cuisineNameStr = "";
        String levelNameStr = "";
        String duringNameStr = "";
        int praiseNumNameStr = 0;
        String goodDishImageUrl = "";
        String recipeId = "";

        if (mRecipeWithUser.getRecipeInfo() != null) {
            dishNameStr = mRecipeWithUser.getRecipeInfo().getTitle();
            cuisineNameStr = mRecipeWithUser.getRecipeInfo().getCuisine();
            levelNameStr = mRecipeWithUser.getRecipeInfo().getLevel();
            duringNameStr = mRecipeWithUser.getRecipeInfo().getDuring();
            if (mRecipeWithUser.getRecipeInfo().getFavoriteNumber() != null) {
                praiseNumNameStr = Integer.parseInt(mRecipeWithUser.getRecipeInfo().getFavoriteNumber());
            } else {
                praiseNumNameStr = 0;
            }
            goodDishImageUrl = mRecipeWithUser.getRecipeInfo().getPic();
            recipeId = mRecipeWithUser.getRecipeInfo().getRecipeId();
        }

        dishListHolder.dishName.setText(dishNameStr);
        dishListHolder.cuisineName.setText(cuisineNameStr);
        dishListHolder.levelName.setText(levelNameStr);
        dishListHolder.duringName.setText(duringNameStr);
        dishListHolder.praiseNumName.setText(praiseNumNameStr + "");

        ImageDownLoader.get(mActivity)
            .display(goodDishImageUrl, R.drawable.bg_defalt_recepe, dishListHolder.goodDishImage);

        //跳转到菜谱主页
        //        HaierLoger.d("DishListAdapter", dishListHolder.goodDishImage.hashCode());
        if (!TextUtils.isEmpty(recipeId)) {
            final String finalRecipeId = recipeId;
            dishListHolder.goodDishImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Toast.makeText(mActivity, pos + "菜谱pic id"
                    // + finalRecipeId, Toast.LENGTH_SHORT).show();
                    //需要回调接口 调取打开菜谱详情页
                    mHandleHomeDishInterface.onDishMainPage(mRecipeWithUser.getRecipeInfo().getRecipeId(),
                        mRecipeWithUser.getRecipeInfo().getTitle());
                }
            });
        }

        //用户相关
        String cookerNameStr = "";
        String dishCookerImageUrl = "";
        String cookerUserId = "";

        if (mRecipeWithUser.getUserInfo() != null) {
            cookerNameStr = mRecipeWithUser.getUserInfo().getNickName();
            dishCookerImageUrl = mRecipeWithUser.getUserInfo().getAvater();
            cookerUserId = mRecipeWithUser.getUserInfo().getUserId();
        }

        dishListHolder.cookerName.setText(cookerNameStr);
        ImageDownLoader.get(mActivity)
            .display(dishCookerImageUrl, R.drawable.test_pic_user, dishListHolder.dishCookerImage);


        //菜谱点赞--需要改变点赞数和点赞图
        dishListHolder.dishPraiseImage.setImageResource(R.drawable.btn_to_like);
        final String finalCookerUserId = cookerUserId;
        final int praise = praiseNumNameStr;
        final boolean isPraise = mRecipeWithUser.getRecipeInfo().getIsPraise();
        dishListHolder.dishPraiseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isPraise && !TextUtils.isEmpty(finalCookerUserId)) {
                    mRecipeWithUser.getRecipeInfo().setIsPraise(true);
                    // Toast.makeText(mActivity, pos + "点赞user id" + finalCookerUserId, Toast.LENGTH_SHORT).show();
                    dishListHolder.dishPraiseImage.setImageResource(R.drawable.btn_liked);
                    dishListHolder.praiseNumName.setText((praise + 1) + "");
                    //需要回调接口 调取点赞接口
                    mHandleHomeDishInterface.onDishPraise(finalCookerUserId);
                }
            }
        });
        //厨咖主页
        dishListHolder.dishCookerImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mActivity, pos + "头像user id" + finalCookerUserId, Toast.LENGTH_SHORT).show();
                //需要回调接口 调取点赞接口
                mHandleHomeDishInterface.onDishCookerPage(finalCookerUserId);
            }
        });
    }

    /**
     * 厨咖排名的ViewHolder
     */
    class RankHolder extends RecyclerView.ViewHolder {

        Activity mActivity;
        GridView rankGrid;
        TextView moreRank;
        RankAdapter mRankAdapter;

        public RankHolder(View itemView, final Activity activity) {
            super(itemView);
            mActivity = activity;
            rankGrid = (GridView) itemView.findViewById(R.id.gv_rank);
            moreRank = (TextView) itemView.findViewById(R.id.tv_more_dish);
            mRankAdapter = new RankAdapter(mActivity, mChefInfoList, mHandleHomeRankInterface);
            rankGrid.setAdapter(mRankAdapter);
            mRankAdapter.notifyDataSetChanged();
        }
    }


    /**
     * 更新轮播图数据
     *
     * @param topVideoInfoList
     */
    public void setTopVideoInfoList(List<TopVideoInfo> topVideoInfoList) {
        if (mHeadCookerHolder != null && topVideoInfoList != null && topVideoInfoList.size() > 0) {
            this.mTopVideoInfoList = topVideoInfoList;
            mHeadCookerHolder.mCookerPagerAdapter.updateViewList(topVideoInfoList);
            mHeadCookerHolder.addIndicator(topVideoInfoList.size());

            //以下按照需求，此处不需要跟随pager切换而刷新，故注释掉
            //            //判断刷新之前的所处pager下标是否大于刷新后的pager页数，如果大于就跳转到第0个pager
            //            if (mHeadCookerHolder.mPosition <= topVideoInfoList.size() - 1) {
            //                mHeadCookerHolder.refreshTopBarView(mHeadCookerHolder.mPosition);
            //            } else {
            //                mHeadCookerHolder.refreshTopBarView(0);
            //            }
            mHeadCookerHolder.refreshTopBarView(0);
        }
        notifyDataSetChanged();
    }

    /**
     * 刷新厨咖排行数据
     *
     * @param chefInfoList
     */
    public void setChefInfoList(List<ChefInfo> chefInfoList) {
        if (mRankHolder != null && chefInfoList != null && chefInfoList.size() > 0) {
            this.mChefInfoList = chefInfoList;
            mRankHolder.mRankAdapter.updateViewList(mChefInfoList);
        }
        notifyDataSetChanged();
    }

    public void setUserSubscribeStatus(boolean state){
        if(mHeadCookerHolder != null){
            if(state){
//                mHeadCookerHolder.cookerSubscribe.setImageResource(R.drawable.btn_followed);
                mTopVideoInfoList.get(0).setSubscribeStatus("1");
            }else{
//                mHeadCookerHolder.cookerSubscribe.setImageResource(R.drawable.btn_follow);
                mTopVideoInfoList.get(0).setSubscribeStatus("0");
            }
//            notifyDataSetChanged();
            mHeadCookerHolder.refreshTopBarView(0);
        }
    }

    /**
     * 刷新推荐菜谱信息
     *
     * @param recipeWithUserList
     */
    public void setRecipeWithUserList(List<RecipeWithUser> recipeWithUserList) {
        this.mRecipeWithUserList = recipeWithUserList;
        notifyDataSetChanged();
    }

    /**
     * 等到当前adapter中菜谱列表的数量
     *
     * @return
     */
    public List<RecipeWithUser> getmRecipeWithUserList() {
        return mRecipeWithUserList;
    }

    /**
     * 追加推荐菜谱信息
     *
     * @param recipeWithUserList
     */
    public void addRecipeWithUserList(List<RecipeWithUser> recipeWithUserList) {
        this.mRecipeWithUserList.addAll(recipeWithUserList);
        notifyDataSetChanged();
    }


    private void setOnDishClickListener(ImageView room, final int position) {
        room.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mActivity, position + "", Toast.LENGTH_LONG);
            }
        });
    }

    public static interface OnRecyclerViewItemClickListener {
        void onItemClick(View view, String data);
    }
}
