package com.haier.uhome.goodtaste.widgets;

import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.StyleRes;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.haier.uhome.goodtaste.R;

import java.util.Timer;
import java.util.TimerTask;


public class CustomProgressDialog extends Dialog {

    private static ProgressBar mProgressBar;
    private static ImageView mIvSuccess;
    private static ImageView mIvFail;
    private static TextView mText;
    private static CustomProgressDialog dialog;
    public static final int LOADING_SUB = 1;
    public static final int LOADING_UN = 2;
    public static final int SUCCESS = 3;
    public static final int FAIL = 4;

    public CustomProgressDialog(@NonNull Context context) {
        this(context, 0);
    }

    public CustomProgressDialog(@NonNull Context context, @StyleRes int theme) {
        super(context, theme);
    }

    public static CustomProgressDialog show(Context context, boolean conttime,
        boolean cancelable, OnCancelListener cancelListener,int state) {
        if (dialog != null) {
            if (dialog.isShowing()) {
                dialog.dismiss();
            }
        }
        dialog = new CustomProgressDialog(context, R.style.ProgressHUD);

        dialog.setContentView(R.layout.layout_custom_progressdialog);
        mProgressBar = (ProgressBar) dialog.findViewById(R.id.progress_icon_loading);
        mIvSuccess = (ImageView) dialog.findViewById(R.id.progress_icon_success);
        mIvFail = (ImageView) dialog.findViewById(R.id.progress_icon_fail);
        mText = (TextView) dialog.findViewById(R.id.progress_loadingmsg);

        setmProgressBarState(context,state);

        dialog.setCancelable(cancelable);
        dialog.setOnCancelListener(cancelListener);
        dialog.getWindow().getAttributes().gravity = Gravity.CENTER;

        WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();
        lp.dimAmount = 0.0f;
        dialog.getWindow().setAttributes(lp);
        dialog.show();

        if(conttime){
            cont = 3;
            // init timer
            mTimer = new Timer();
            // start timer task
            setTimerTask();
        }
        return dialog;
    }

    public static void setmProgressBarState(Context context,int state) {
        switch (state) {
            case LOADING_SUB:
                mProgressBar.setVisibility(View.VISIBLE);
                mIvSuccess.setVisibility(View.GONE);
                mIvFail.setVisibility(View.GONE);
                mText.setText(context.getString(R.string.progress_loading_text1));
                break;
            case LOADING_UN:
                mProgressBar.setVisibility(View.VISIBLE);
                mIvSuccess.setVisibility(View.GONE);
                mIvFail.setVisibility(View.GONE);
                mText.setText(context.getString(R.string.progress_loading_text2));
                break;
            case SUCCESS:
                mProgressBar.setVisibility(View.GONE);
                mIvSuccess.setVisibility(View.VISIBLE);
                mIvFail.setVisibility(View.GONE);
                mText.setText(context.getString(R.string.progress_success_text));
                break;
            case FAIL:
                mProgressBar.setVisibility(View.GONE);
                mIvSuccess.setVisibility(View.GONE);
                mIvFail.setVisibility(View.VISIBLE);
                mText.setText(context.getString(R.string.progress_fail_text));
                break;
            default:

                break;
        }
    }

    private static Timer mTimer;
    private static int cont = 3;

    private static void setTimerTask() {
        mTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                Message message = new Message();
                if (cont > 1) {
                    message.what = 1;
                } else {
                    message.what = 2;
                }

                doActionHandler.sendMessage(message);
            }
        }, 1000, 1000/* 表示1000毫秒之后，每隔1000毫秒执行一次 */);
    }

    /**
     * do some action
     */
    private static Handler doActionHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            int msgId = msg.what;
            switch (msgId) {
                case 1:
                    cont = cont - 1;
                    break;
                case 2:
                    dialog.dismiss();
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    public void dismiss() {
        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
        super.dismiss();
    }
}
