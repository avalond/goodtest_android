package com.haier.uhome.goodtaste.actions;

/**
 * Created by Administrator on 2016/5/21.
 */
public interface GiveRewardActions {
    String ID_FIND_POINT = "findUserPoint";//查询用户积分的ID
    String ID_RAWARD_USER = "rewardUser";//登录用户给某个用户打赏
    /**
     * 查询用户积分
     * @param userId 用户ID
     */
    void findUserPoint(String userId);

    /**
     * 当前登录用户给某个用户打赏
     *
     * @param userId       用户ID
     * @param rewardUserId 打赏userId"
     * @param rewardScore  打赏积分
     */
    void rewardUser(String userId, String rewardUserId, String rewardScore);
}
