package com.haier.uhome.goodtaste.data.models;

import com.haier.uhome.goodtaste.data.source.local.GoodTasteDataBase;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.io.Serializable;

@Table(database = GoodTasteDataBase.class, allFields = true)
public class UserProfile extends BaseModel implements Serializable {
    private static final long serialVersionUID = 4468166348993035750L;
    @PrimaryKey(autoincrement = true)
    private long id;
    private String nickName;
    private String userBpic;
    private String sex;
    private String city;
    private String about;
    private String email;
    private String phone;
    private String birthday;

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getUserBpic() {
        return userBpic;
    }

    public void setUserBpic(String userBpic) {
        this.userBpic = userBpic;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "UserProfile{" +
            "id=" + id +
            ", nickName='" + nickName + '\'' +
            ", userBpic='" + userBpic + '\'' +
            ", sex='" + sex + '\'' +
            ", city='" + city + '\'' +
            ", about='" + about + '\'' +
            ", email='" + email + '\'' +
            ", phone='" + phone + '\'' +
            ", birthday='" + birthday + '\'' +
            '}';
    }
}
