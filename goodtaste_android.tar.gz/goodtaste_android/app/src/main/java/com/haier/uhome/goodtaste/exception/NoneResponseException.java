package com.haier.uhome.goodtaste.exception;

/**
 * Created by Dallas on 2016/3/15.
 */
public class NoneResponseException extends RuntimeException {
    public static final String NONE_RESPONSE_BODY_ERROR = "90000";
    private static final long serialVersionUID = -8267272049494282223L;

    public NoneResponseException() {
        super("response body is null[" + NONE_RESPONSE_BODY_ERROR + "]");
    }
}
