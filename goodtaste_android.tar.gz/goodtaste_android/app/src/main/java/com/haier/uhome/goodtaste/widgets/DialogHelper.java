package com.haier.uhome.goodtaste.widgets;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.support.v7.app.AlertDialog;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.widgets.ptr.PtrFrameLayout;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;

/**
 * Created by lijin on 2016/5/21
 */
public class DialogHelper {
    private Activity mContext;

    public DialogHelper(Activity context) {
        mContext = context;
    }

    /**
     * 竖屏分享dialog
     *
     * @param title     分享标题
     * @param text      分享文字内容
     * @param targetUrl 分享h5 url
     */
    public void showDialogShare(String title, final String text, final String targetUrl) {
        final Dialog sharedialog = new Dialog(mContext, R.style.dialog_video);
        View view = View.inflate(mContext, R.layout.layout_share_dialog, null);
        sharedialog.setContentView(view); //设置dialog的布局
        Window dialogWindow = sharedialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        dialogWindow.setGravity(Gravity.BOTTOM);

        WindowManager m = (mContext).getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = dialogWindow.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 0.38); // 高度设置为屏幕的0.6
        p.width = (int) (d.getWidth() * 1.0); // 宽度设置为屏幕的0.65
        dialogWindow.setAttributes(p);
        dialogWindow.setAttributes(lp);
        sharedialog.setCanceledOnTouchOutside(true);

        Button btnCancel = (Button) view.findViewById(R.id.btn_cancel);
        TextView tcTitle = (TextView) view.findViewById(R.id.tv_text);
        TextView tvShareCircle = (TextView) view.findViewById(R.id.tv_share_wache_circle);
        TextView tvShareSine = (TextView) view.findViewById(R.id.tv_share_sine);
        TextView tvShareFriend = (TextView) view.findViewById(R.id.tv_share_friend);
        tcTitle.setText(mContext.getString(R.string.share_title, title));
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharedialog.dismiss();
            }
        });
        tvShareFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new ShareAction(mContext).setPlatform(SHARE_MEDIA.WEIXIN)
                    .setCallback(umShareListener)
                    .withText(text)
                    .withTargetUrl(targetUrl)
                    .withMedia(new UMImage(mContext,
                        BitmapFactory.decodeResource(mContext.getResources(), R.drawable.share_img)))
                    .share();
            }
        });
        tvShareSine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new ShareAction(mContext).setPlatform(SHARE_MEDIA.SINA)
                    .setCallback(umShareListener)
                    .withText(text)
                    .withTargetUrl(targetUrl)
                    .withMedia(new UMImage(mContext,
                        BitmapFactory.decodeResource(mContext.getResources(), R.drawable.share_img)))
                    .share();
            }
        });
        tvShareCircle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new ShareAction(mContext).setPlatform(SHARE_MEDIA.WEIXIN_CIRCLE)
                    .setCallback(umShareListener)
                    .withText(text)
                    .withTitle(text)
                    .withTargetUrl(targetUrl)
                    .withMedia(new UMImage(mContext,
                        BitmapFactory.decodeResource(mContext.getResources(), R.drawable.share_img)))
                    .share();
            }
        });
        sharedialog.show();
    }

    /**
     * 横屏分享dialog
     *
     * @param title     分享标题
     * @param text      分享文字内容
     * @param targetUrl 分享视频h5 url
     */
    public void showDialogShareVideoHorizontal(String title, final String text, final String targetUrl) {
        final Dialog sharedialog = new Dialog(mContext, R.style.dialog_video);
        View view = View.inflate(mContext, R.layout.layout_share_video, null);
        sharedialog.setContentView(view); //设置dialog的布局
        Window dialogWindow = sharedialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        dialogWindow.setGravity(Gravity.CENTER);

        WindowManager m = (mContext).getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = dialogWindow.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1.0); // 高度设置为屏幕的0.6
        p.width = (int) (d.getWidth() * 1.0); // 宽度设置为屏幕的0.65
        dialogWindow.setAttributes(p);
        dialogWindow.setAttributes(lp);
        sharedialog.setCanceledOnTouchOutside(true);

        Button btnCancel = (Button) view.findViewById(R.id.btn_cancel);
        TextView tcTitle = (TextView) view.findViewById(R.id.title);
        TextView tvShareCircle = (TextView) view.findViewById(R.id.tv_share_wache_circle);
        TextView tvShareSine = (TextView) view.findViewById(R.id.tv_share_sine);
        TextView tvShareFriend = (TextView) view.findViewById(R.id.tv_share_friend);
        tcTitle.setText(mContext.getString(R.string.share_title, title));
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharedialog.dismiss();
            }
        });
        tvShareFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new ShareAction(mContext).setPlatform(SHARE_MEDIA.WEIXIN)
                    .setCallback(umShareListener)
                    .withText(text)
                    .withTargetUrl(targetUrl)
                    .withMedia(new UMImage(mContext,
                        BitmapFactory.decodeResource(mContext.getResources(), R.drawable.share_img)))
                    .share();
            }
        });
        tvShareSine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new ShareAction(mContext).setPlatform(SHARE_MEDIA.SINA)
                    .setCallback(umShareListener)
                    .withText(text)
                    .withTargetUrl(targetUrl)
                    .withMedia(new UMImage(mContext,
                        BitmapFactory.decodeResource(mContext.getResources(), R.drawable.share_img)))
                    .share();
            }
        });
        tvShareCircle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new ShareAction(mContext).setPlatform(SHARE_MEDIA.WEIXIN_CIRCLE)
                    .setCallback(umShareListener)
                    .withText(text)
                    .withTitle(text)
                    .withTargetUrl(targetUrl)
                    .withMedia(new UMImage(mContext,
                        BitmapFactory.decodeResource(mContext.getResources(), R.drawable.share_img)))
                    .share();
            }
        });
        sharedialog.show();
    }


    UMShareListener umShareListener = new UMShareListener() {
        @Override
        public void onResult(SHARE_MEDIA shareMedia) {
            Toast.makeText(mContext, mContext.getString(R.string.share_success), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onError(SHARE_MEDIA shareMedia, Throwable throwable) {
            Toast.makeText(mContext, mContext.getString(R.string.share_failure), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onCancel(SHARE_MEDIA shareMedia) {
            Toast.makeText(mContext, mContext.getString(R.string.share_cancel), Toast.LENGTH_SHORT).show();
        }
    };


    /**
     * 邀请好友dialog
     *
     * @param inviteCode 邀请码
     * @param targetUrl 邀请h5 url
     */
    public void showInviteFriendShare(final String inviteCode, final String targetUrl) {
        final Dialog sharedialog = new Dialog(mContext, R.style.dialog_video);
        View view = View.inflate(mContext, R.layout.layout_invite_friend_dialog, null);
        sharedialog.setContentView(view); //设置dialog的布局
        Window dialogWindow = sharedialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        dialogWindow.setGravity(Gravity.BOTTOM);

        WindowManager m = (mContext).getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = dialogWindow.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 0.38); // 高度设置为屏幕的0.6
        p.width = (int) (d.getWidth() * 1.0); // 宽度设置为屏幕的0.65
        dialogWindow.setAttributes(p);
        dialogWindow.setAttributes(lp);
        sharedialog.setCanceledOnTouchOutside(true);

        Button btnCancel = (Button) view.findViewById(R.id.btn_cancel);
        TextView tvShareWache = (TextView) view.findViewById(R.id.tv_share_wache);
        TextView tvShareFriend = (TextView) view.findViewById(R.id.tv_share_friend);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharedialog.dismiss();
            }
        });
        tvShareFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new ShareAction(mContext).setPlatform(SHARE_MEDIA.WEIXIN)
                    .setCallback(umInviteListener)
                    .withText(mContext.getString(R.string.invite_content,inviteCode))
                    .withTargetUrl(targetUrl)
                    .withMedia(new UMImage(mContext,
                        BitmapFactory.decodeResource(mContext.getResources(), R.drawable.share_img)))
                    .share();
            }
        });
        tvShareWache.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new ShareAction(mContext).setPlatform(SHARE_MEDIA.WEIXIN_CIRCLE)
                    .setCallback(umInviteListener)
                    .withText(mContext.getString(R.string.invite_content_wx_circle,inviteCode))
                    .withTitle(mContext.getString(R.string.invite_content_wx_circle,inviteCode))
                    .withTargetUrl(targetUrl)
                    .withMedia(new UMImage(mContext,
                        BitmapFactory.decodeResource(mContext.getResources(), R.drawable.share_img)))
                    .share();
            }
        });
        sharedialog.show();
    }

    UMShareListener umInviteListener = new UMShareListener() {
        @Override
        public void onResult(SHARE_MEDIA shareMedia) {
            Toast.makeText(mContext, mContext.getString(R.string.invite_success), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onError(SHARE_MEDIA shareMedia, Throwable throwable) {
            Toast.makeText(mContext, mContext.getString(R.string.invite_failure), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onCancel(SHARE_MEDIA shareMedia) {
            Toast.makeText(mContext, mContext.getString(R.string.invite_cancel), Toast.LENGTH_SHORT).show();
        }
    };


    /**
     * 两个按钮弹出对话框
     *
     * @param title            标题
     * @param content          内容
     * @param cancelBtnStr     取消按钮文字
     * @param okBtnStr         确认按钮文字
     * @param okClickListener  确认按钮回调
     */
    public void showDialog2(String title, String content, String cancelBtnStr, String okBtnStr,
        final View.OnClickListener okClickListener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        View view = View.inflate(mContext, R.layout.activity_collection_dialog, null);
        TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
        TextView tvMessage = (TextView) view.findViewById(R.id.tv_message);
        TextView btnOk = (TextView) view.findViewById(R.id.btn_ok);
        TextView btnCancel = (TextView) view.findViewById(R.id.btn_cancel);
        tvTitle.setText(title);
        tvMessage.setText(content);
        btnOk.setText(okBtnStr);
        btnCancel.setText(cancelBtnStr);
        builder.setView(view);
        final AlertDialog dialog = builder.create();
        Window dialogWindow = dialog.getWindow();
        dialogWindow.setGravity(Gravity.CENTER);
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.alpha = 1.0f;
        dialogWindow.setAttributes(lp);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                okClickListener.onClick(v);
            }
        });
        dialog.show();
    }
}
