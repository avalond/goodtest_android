package com.haier.uhome.goodtaste.stores;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.actions.HomePageActions;
import com.haier.uhome.goodtaste.actions.LoginActions;
import com.haier.uhome.goodtaste.actions.UserActions;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.HaierPreference;
import com.haier.uhome.goodtaste.data.models.AppVersionResult;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.LoginInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo_Table;
import com.haier.uhome.goodtaste.data.models.UserProfileType;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;
import com.raizlabs.android.dbflow.sql.language.SQLite;

/**
 * <br>
 * Created by dallas on 16-4-19.
 */
public class UserStore extends BaseStore {
    private static UserStore instance;

    public synchronized static UserStore get(Context context) {
        if (instance == null) {
            HaierApplication app = (HaierApplication) context.getApplicationContext();
            instance = new UserStore(app.getRxFlux().getDispatcher());
        }
        return instance;
    }

    public static final String ID = "UserStore";
    private UserInfo mUserInfo;
    private String mUserId;
    private LoginInfo mLoginInfo;
    private String mAccessToken;
    private AppVersionResult mAppVersionResult;
    private boolean isLogoutSuccess;

    protected UserStore(Dispatcher dispatcher) {
        super(dispatcher);
        RxPreference preference = DataManager.instance().getPreference();
        mAccessToken = preference.getString(HaierPreference.KEY_TOKEN, "");
        mUserId = preference.getString(HaierPreference.KEY_USERID, "");

        if (!TextUtils.isEmpty(mUserId)) {
            mUserInfo = SQLite.select().from(UserInfo.class).where(UserInfo_Table.userId.eq(mUserId)).querySingle();
        }
    }

    @Override
    public void unregister() {
        // UserStore为单例，所以不需要取消注册。最终在App所有页面完全退出后自动取消注册。
        // super.unregister();
    }

    @Override
    protected void onAction(RxAction action) {
        switch (action.getType()) {
            case LoginActions.ID_LOGIN:
                Bundle data = (Bundle) action.getData();
                mLoginInfo = (LoginInfo) data.get("resultAction");
                mAccessToken = mLoginInfo.getAccessToken();
                mUserId = mLoginInfo.getUserId();
                isLogoutSuccess = false;
                break;
            case UserActions.ID_GET_USER_INFO:
                mUserInfo = (UserInfo) action.getData();
                break;
            case LoginActions.ID_3RD_PARTY_LOGIN:
                mLoginInfo = (LoginInfo) action.getData();
                mAccessToken = mLoginInfo.getAccessToken();
                mUserId = mLoginInfo.getUserId();
                isLogoutSuccess = false;
                break;
            case LoginActions.ID_LOGOUT:
                BaseResult result = (BaseResult) action.getData();
                isLogoutSuccess = true;
                mLoginInfo = null;
                mUserInfo = null;
                mAccessToken = "";
                mUserId = "";
                break;
            case UserActions.ID_UPDATE_USER_PROFILE:
                updateUserInfo((Bundle) action.getData());
                break;
            case UserActions.ID_UPLOAD_AVATAR:
                mUserInfo.setAvater((String) action.getData());
                break;
            case HomePageActions.GET_APP_VERSION:
                mAppVersionResult = ((AppVersionResult) action.getData());
                break;

            default: // 重要！！！重要！！！重要！！！ 如果不需要处理那么就要忽略该事件
                return;
        }
        postStoreChange(new RxStoreChange(ID, action));
    }

    @Nullable
    public String getUserId() {
        return mUserId;
    }

    public UserInfo getUserInfo() {
        return mUserInfo;
    }

    public AppVersionResult getAppVersion() {
        return mAppVersionResult;
    }

    public boolean isLoginSuccess() {
        return !TextUtils.isEmpty(mAccessToken);
    }

    public boolean isLogoutSuccess() {
        return isLogoutSuccess;
    }

    public String getAccessToken() {
        return mAccessToken;
    }

    public boolean isActivated() {
        HaierLoger.a("isActivated", mLoginInfo != null);
        HaierLoger.a("isActivated", mLoginInfo.isActivated());
        return mLoginInfo != null && mLoginInfo.isActivated();
    }

    private void updateUserInfo(Bundle data) {
        int type = data.getInt("type");
        String content = data.getString("content");
        switch (type) {
            case UserProfileType.NIKE_NAME:
                mUserInfo.setNickName(content);
                break;
            case UserProfileType.SEX:
                mUserInfo.setGender(content);
                break;
            case UserProfileType.CITY:
                mUserInfo.setAddress(content);
                break;
            case UserProfileType.ABOUT:
                mUserInfo.setIntroduction(content);
                break;
            case UserProfileType.EMAIL:
                mUserInfo.setEmail(content);
                break;
            case UserProfileType.PHONE:
                mUserInfo.setPhone(content);
                break;
            case UserProfileType.BIRTHDAY:
                mUserInfo.setBirthday(content);
                break;
            default:
                break;
        }
    }
}
