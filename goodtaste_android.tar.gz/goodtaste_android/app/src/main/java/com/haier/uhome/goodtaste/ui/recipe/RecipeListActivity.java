package com.haier.uhome.goodtaste.ui.recipe;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.gmail.adffice.rxflux.util.SubscriptionManager;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.actions.RecipeActionsCreator;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.HotKey;
import com.haier.uhome.goodtaste.data.models.RecipeData;
import com.haier.uhome.goodtaste.data.models.RecipeWithUser;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.source.remote.services.H5HybirdUrl;
import com.haier.uhome.goodtaste.stores.ChefStore;
import com.haier.uhome.goodtaste.stores.RecipeStore;
import com.haier.uhome.goodtaste.stores.UserStore;
import com.haier.uhome.goodtaste.stores.VideoStore;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.ui.WebActivity;
import com.haier.uhome.goodtaste.ui.main.HandleHomeDishInterface;
import com.haier.uhome.goodtaste.ui.recipe.adapter.HotKeyAdapter;
import com.haier.uhome.goodtaste.ui.recipe.adapter.RecipeListAdapter;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.widgets.UnScrollGridView;
import com.haier.uhome.goodtaste.widgets.loadmore.HaoRecyclerView;
import com.haier.uhome.goodtaste.widgets.loadmore.LoadMoreListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sharp on 16-5-14.
 */
public class RecipeListActivity extends BaseActivity {

    public static final String TAG = RecipeListActivity.class.getSimpleName();
    LinearLayoutManager layoutManager;
    private RecipeActionsCreator mRecipeActionsCreator;

    private UserStore mUserStore;
    private RecipeStore mRecipeStore;//菜谱业务相关的store

    private FrameLayout searchFrame;

    private boolean isGetRecipeListFinished = true;
    private HaoRecyclerView mRecipeRecylerView;//菜谱列表
    private RecipeListAdapter mRecipeListAdapter;
    private List<RecipeWithUser> recipeWithUserList = new ArrayList<RecipeWithUser>();
    private List<RecipeWithUser> tempRecipeWithUserList = new ArrayList<RecipeWithUser>();

    private HotKeyAdapter mHotKeyAdapter;
    private List<HotKey> tempHotKey;//hotkey
    private UnScrollGridView mHotKeyGrid;

    private TextView mLeftBack;//ActionBar左侧按钮
    private TextView mRightBtn;//ActionBar左侧按钮
    private EditText mKeyEditText;

    private String keyWord = "";//用以缓存回调接口得到的key
    private int currentPage = 1;//上滑动加载更多，这个行为是从2开始计算的。
    private static final int LIMIT = 10;//每页最多条数
    private boolean canGetMoreRecipe = true;//是否正在刷新界面.true，允许加载更多
    private boolean loadMoreFail = false;//加载更多是否失败

    private int getMoreType = GET_MORE_ALL;
    private static final int GET_MORE_ALL = 0;
    private static final int GET_MORE_SEARCH = 1;

    public RecipeListActivity() {}

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_list);
        mRecipeActionsCreator = new RecipeActionsCreator(this, getDataManager(), getDispatcher(),
            getSubscriptionManager());
        initView();
        initData();
    }

    private void initView() {

        mRecipeRecylerView = (HaoRecyclerView) findViewById(R.id.rv_recipe_list);
        searchFrame = (FrameLayout) findViewById(R.id.rl_search_frame);
        searchFrame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        mHotKeyGrid = (UnScrollGridView) findViewById(R.id.gv_hot_key);

        int orientation = getLayoutManagerOrientation(getResources().getConfiguration().orientation);
        layoutManager = new LinearLayoutManager(this, orientation, false);

        mRecipeRecylerView.setLayoutManager(layoutManager);
        mRecipeRecylerView.setLoadMoreListener(new LoadMoreListener() {
            @Override
            public void onLoadMore() {
                //当页面正在刷新，推荐菜谱列表为空的时候，不允许上滑动加载更多
                if (!canGetMoreRecipe || recipeWithUserList == null || recipeWithUserList.size() < 1) {
                    mRecipeRecylerView.setCanloadMore(false);
                    mRecipeRecylerView.loadMoreComplete();
                    //                    mRecipeRecylerView.loadMoreEnd();
                    return;
                }

                mRecipeRecylerView.setCanloadMore(true);
                canGetMoreRecipe = false;
                if (getMoreType == GET_MORE_SEARCH) {
                    mRecipeActionsCreator.getKeyRecipe(keyWord, currentPage);
                } else if (getMoreType == GET_MORE_ALL) {
                    mRecipeActionsCreator.getAllRecipe(currentPage);//真实的接口
                }
            }
        });
    }

    private void initData() {

        mRecipeActionsCreator.getHotKey();
        mRecipeActionsCreator.getAllRecipe(1);
        isGetRecipeListFinished = false;
        getMoreType = GET_MORE_ALL;//真实的
        //        mRecipeActionsCreator.getKeyRecipe("西", 1);//测试
        //        getMoreType = GET_MORE_SEARCH;//测试
        canGetMoreRecipe = false;//刷新整个页面的时候，禁用上滑动加载更多
        ///////////////////此处应该改为本地缓存
        String[] temp = getDummyDataSet();
        tempHotKey = new ArrayList<>();
        for (int i = 0; i < temp.length; i++) {
            HotKey itemkey = new HotKey();
            itemkey.setName(temp[i]);
            tempHotKey.add(itemkey);
        }
        ///////////////////

        //热搜词汇
        mHotKeyAdapter = new HotKeyAdapter(this, tempHotKey, mRecipeSearchInterface);
        mHotKeyGrid.setAdapter(mHotKeyAdapter);

        //菜谱
        recipeWithUserList = new ArrayList<>();
        mRecipeListAdapter = new RecipeListAdapter(this, recipeWithUserList, handleHomeDishInterface);
        mRecipeRecylerView.setAdapter(mRecipeListAdapter);

        mRecipeRecylerView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // Toast.makeText(getActivity(), "click-----position" + i, Toast.LENGTH_SHORT).show();
                // if (loadMoreFail && NetWorkUtils.isNetworkAvailable(getActivity())) {
                if (loadMoreFail) {
                    loadMoreFail = false;
                    mRecipeRecylerView.setloadFail();
                    mRecipeRecylerView.setCanloadMore(true);
                    if (getMoreType == GET_MORE_SEARCH) {
                        mRecipeActionsCreator.getKeyRecipe(keyWord, currentPage);
                    } else if (getMoreType == GET_MORE_ALL) {
                        mRecipeActionsCreator.getAllRecipe(currentPage);//真实的接口
                    }
                    //                    mRecipeActionsCreator.homeMoreDishRefresh(2, currentPage, "");
                }
            }
        });
    }

    private String[] getDummyDataSet() {
        return getResources().getStringArray(R.array.hotkey);
    }

    @Override
    protected View createToolbarView(LayoutInflater inflater, ViewGroup container) {

        View view = inflater.inflate(R.layout.layout_toolbar_recipe, container);

        mLeftBack = (TextView) view.findViewById(R.id.toolbar_left_btn);
        mRightBtn = (TextView) view.findViewById(R.id.toolbar_right_btn);
        mKeyEditText = (EditText) view.findViewById(R.id.etv_search_recipe_key);
        mKeyEditText.addTextChangedListener(mTextWatcher);

        mKeyEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                //判断是否是“Search”键
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    //隐藏软键盘
                    closeKeyBoard();
                    //重置search的搜索各个状态量
                    setSearchState();
                    //                    //标记这是搜索而不是全部
                    //                    getMoreType = GET_MORE_SEARCH;
                    //                    currentPage = 1;//每次重新搜索页码都重置为1
                    //                    mRecipeActionsCreator.getKeyRecipe(mKeyEditText.getText().toString(), 1);
                    //                    searchFrame.setVisibility(View.GONE);
                    //                    mKeyEditText.clearFocus();
                    return true;
                }
                return false;
            }
        });

        mLeftBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onToolbarLeftButtonClicked(v);
            }
        });

        mRightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onToolbarRightButtonClicked(v);
            }
        });

        mKeyEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (searchFrame.getVisibility() != View.VISIBLE) {
                        searchFrame.setVisibility(View.VISIBLE);
                        refreshHotKey(tempHotKey);
                        openKeyBoard();
                    }
                }
            }
        });
        return view;
    }

    @Override
    public void onRxStoresRegister() {
        mRecipeStore = RecipeStore.get(this);
        mRecipeStore.register();
        mUserStore = UserStore.get(this);
        mUserStore.register();
    }

    @Override
    public void onRxStoresUnRegister() {
        mRecipeStore.unregister();
        mUserStore.unregister();
    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {
        switch (change.getStoreId()) {
            case RecipeStore.ID:
                switch (change.getRxAction().getType()) {
                    case RecipeActionsCreator.ID_ALL_RECIPE://全部菜谱
                        isGetRecipeListFinished = true;
                        recipeWithUserList = mRecipeStore.getRecipeWithUserList();
                        if (currentPage == 1) {
                            tempRecipeWithUserList = new ArrayList<>();
                            tempRecipeWithUserList.addAll(mRecipeStore.getRecipeWithUserList());
                            if (recipeWithUserList == null || recipeWithUserList.size() < 1) {
                                //设置一个失败的图
                                HaierLoger.d(TAG, "recipeWithUserList == null");
                            } else if (recipeWithUserList.size() > 0 && recipeWithUserList.size() < LIMIT) {
                                mRecipeRecylerView.loadMoreEnd();
                                currentPage = currentPage + 1;
                                refreshRecipeView(recipeWithUserList);
                            } else {
                                currentPage = currentPage + 1;
                                refreshRecipeView(recipeWithUserList);
                            }
                        } else if (currentPage > 1) {
//                            tempRecipeWithUserList.addAll(mRecipeStore.getRecipeWithUserList());
                            if (recipeWithUserList == null || recipeWithUserList.size() < 1) {
                                mRecipeRecylerView.loadMoreEnd();
                            } else if (recipeWithUserList.size() > 0 && recipeWithUserList.size() < LIMIT) {
                                mRecipeRecylerView.loadMoreEnd();
                                currentPage = currentPage + 1;
                                addMoreRecipeView(recipeWithUserList);
                            } else {
                                currentPage = currentPage + 1;
                                addMoreRecipeView(recipeWithUserList);
                            }
                        }
                        break;
                    case RecipeActionsCreator.ID_HOT_KEY://更新热搜hotkey
                        tempHotKey = mRecipeStore.getHotKeyList();
                        break;
                    case RecipeActionsCreator.ID_KEY_RECIPE://hotkey搜索
                        isGetRecipeListFinished = true;
                        //                        mKeyEditText.setText(keyWord);

                        recipeWithUserList = mRecipeStore.getRecipeWithUserList();
                        if (currentPage == 1) {
                            if (recipeWithUserList == null || recipeWithUserList.size() < 1) {
                                //设置一个失败的图
                                HaierLoger.d(TAG, "recipeWithUserList == null");
                            } else if (recipeWithUserList.size() > 0 && recipeWithUserList.size() < LIMIT) {
                                mRecipeRecylerView.loadMoreEnd();
                                currentPage = currentPage + 1;
                                refreshRecipeView(recipeWithUserList);
                            } else {
                                currentPage = currentPage + 1;
                                refreshRecipeView(recipeWithUserList);
                            }
                        } else if (currentPage > 1) {
                            if (recipeWithUserList == null || recipeWithUserList.size() < 1) {
                                mRecipeRecylerView.loadMoreEnd();
                            } else if (recipeWithUserList.size() > 0 && recipeWithUserList.size() < LIMIT) {
                                mRecipeRecylerView.loadMoreEnd();
                                currentPage = currentPage + 1;
                                addMoreRecipeView(recipeWithUserList);
                            } else {
                                currentPage = currentPage + 1;
                                addMoreRecipeView(recipeWithUserList);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onRxError(RxError error) {

    }

    private void refreshRecipeView(List<RecipeWithUser> recipeWithUserList) {

        if (searchFrame.getVisibility() == View.VISIBLE) {
            searchFrame.setVisibility(View.GONE);
            mKeyEditText.clearFocus();
        }
        layoutManager.scrollToPosition(0);
        if (mRecipeListAdapter != null && recipeWithUserList != null && recipeWithUserList.size() > 0) {
            mRecipeListAdapter.setmRecipeDataList(recipeWithUserList);
        }
        mRecipeRecylerView.loadMoreComplete();
        finishTopRefreshComplete();
    }

    private void addMoreRecipeView(List<RecipeWithUser> recipeWithUserList) {
        if (searchFrame.getVisibility() == View.VISIBLE) {
            searchFrame.setVisibility(View.GONE);
            mKeyEditText.clearFocus();
        }
        if (mRecipeListAdapter != null && recipeWithUserList != null && recipeWithUserList.size() > 0) {
            mRecipeListAdapter.addmRecipeDataList(recipeWithUserList);
        }
        mRecipeRecylerView.loadMoreComplete();
        finishTopRefreshComplete();
    }

    private void refreshHotKey(List<HotKey> list) {
        mHotKeyAdapter.updateHotKeyList(tempHotKey);
    }

    private void finishTopRefreshComplete() {
        //只有在菜谱刷新完成之后才能尝试让推荐菜谱加载更多（还要取决与当前推荐菜谱列表是否为空）
        if (isGetRecipeListFinished) {
            canGetMoreRecipe = true;
        }
    }


    private int getLayoutManagerOrientation(int activityOrientation) {
        if (activityOrientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
            return LinearLayoutManager.VERTICAL;
        } else {
            return LinearLayoutManager.HORIZONTAL;
        }
    }

    private DataManager getDataManager() {
        return ((HaierApplication) this.getApplicationContext()).getDataManager();
    }

    private Dispatcher getDispatcher() {
        return ((HaierApplication) this.getApplicationContext()).getRxFlux().getDispatcher();
    }

    private SubscriptionManager getSubscriptionManager() {
        return ((HaierApplication) this.getApplicationContext()).getRxFlux().getSubscriptionManager();
    }

    @Override
    protected void onToolbarLeftButtonClicked(View v) {
        if (searchFrame.getVisibility() == View.VISIBLE) {
            closeKeyBoard();
            searchFrame.setVisibility(View.GONE);
            mKeyEditText.clearFocus();
        } else {
            finish();
        }
    }

    @Override
    protected void onToolbarRightButtonClicked(View v) {
        //隐藏软键盘
        closeKeyBoard();
        //重置search的搜索各个状态量
        setSearchState();
    }

    @Override
    public void onBackPressed() {
        if (searchFrame.getVisibility() == View.VISIBLE) {
            searchFrame.setVisibility(View.GONE);
            mKeyEditText.clearFocus();
        } else {
            finish();
        }
    }


    /**
     * 首页推荐菜谱部分点击事件的回调
     */
    private HandleHomeDishInterface handleHomeDishInterface = new HandleHomeDishInterface() {
        @Override
        public void onDishCookerPage(String cookerUserId) {
            String userId = UserStore.get(getBaseContext()).getUserId();
            String url = H5HybirdUrl.instance().getCookerPersonalH5Url(cookerUserId,userId);
            startWebView(url,getString(R.string.chef_page_title));
        }

        @Override
        public void onDishMainPage(String recipeId,String title) {
            String userId = UserStore.get(getBaseContext()).getUserId();
            String url = H5HybirdUrl.instance().getDishDetailH5Url(recipeId,userId);
            startWebView(url,title);
        }

        @Override
        public void onDishPraise(String recipeId) {
            String userId = UserStore.get(getBaseContext()).getUserId();
            mRecipeActionsCreator.recipePraise(userId, recipeId);
        }
    };

    private void startWebView(String url,String title){
        HaierLoger.d(TAG,"url="+url);
        HaierLoger.d(TAG,"title="+title);
        Intent intent = new Intent().setClass(this, WebActivity.class);
        intent.putExtra(WebActivity.URL,url);
        intent.putExtra(WebActivity.TITLE,title);
        startActivity(intent);
    }

    RecipeSearchInterface mRecipeSearchInterface = new RecipeSearchInterface() {
        @Override
        public void onSearchHotkey(String key) {
            //隐藏软键盘
            closeKeyBoard();
            mKeyEditText.setText(key);
            keyWord = key;
            //标记这是搜索而不是全部
            getMoreType = GET_MORE_SEARCH;
            currentPage = 1;
            mRecipeActionsCreator.getKeyRecipe(key, 1);

            searchFrame.setVisibility(View.GONE);
            mKeyEditText.clearFocus();
        }
    };

    /**
     * 隐藏软键盘
     */
    private void closeKeyBoard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager.isActive()) {
            inputMethodManager.hideSoftInputFromWindow(RecipeListActivity.this.getCurrentFocus().getWindowToken(), 0);
        }
    }

    /**
     * 弹出键盘
     */
    private void openKeyBoard(){
//        InputMethodManager m=(InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
//        m.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (!inputMethodManager.isActive()) {
            // 接受软键盘输入的编辑文本或其它视图
            inputMethodManager.showSoftInput(mKeyEditText, InputMethodManager.SHOW_FORCED);
        }
    }

    TextWatcher mTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            if (mKeyEditText.getText().toString().length() == 0) {
                recipeWithUserList = tempRecipeWithUserList;
                refreshRecipeView(recipeWithUserList);
                getMoreType = GET_MORE_ALL;
                currentPage = 2;
                canGetMoreRecipe = true;
                closeKeyBoard();
            }
        }
    };


//    private void refreshView(List<RecipeWithUser> recipeWithUserList) {
//        if (searchFrame.getVisibility() == View.VISIBLE) {
//            searchFrame.setVisibility(View.GONE);
//            mKeyEditText.clearFocus();
//        }
//        if (mRecipeListAdapter != null && recipeWithUserList != null && recipeWithUserList.size() > 0) {
//            mRecipeListAdapter.setmRecipeDataList(recipeWithUserList);
//        }
//        mRecipeRecylerView.loadMoreComplete();
//        finishTopRefreshComplete();
//    }
//

    // 设置搜索的初始化状态--键盘搜索键处使用，toolbar右键点击事件使用，点击热搜词时使用
    private void setSearchState() {
        //标记这是搜索而不是全部--键盘--toolbar
        getMoreType = GET_MORE_SEARCH;
        currentPage = 1;//每次重新搜索页码都重置为1
        mRecipeActionsCreator.getKeyRecipe(mKeyEditText.getText().toString(), 1);
        searchFrame.setVisibility(View.GONE);
        mKeyEditText.clearFocus();
    }
}