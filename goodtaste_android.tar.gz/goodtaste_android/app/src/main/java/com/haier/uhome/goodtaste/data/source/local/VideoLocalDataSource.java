package com.haier.uhome.goodtaste.data.source.local;

import android.content.Context;

import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.TopVideoInfo;
import com.haier.uhome.goodtaste.data.models.TopVideoInfo_Table;
import com.haier.uhome.goodtaste.data.models.VideoCommentInfo;
import com.haier.uhome.goodtaste.data.models.VideoInfo;
import com.haier.uhome.goodtaste.data.models.req.VideoCommentReq;
import com.haier.uhome.goodtaste.data.source.VideoDataSource;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;
import com.raizlabs.android.dbflow.runtime.transaction.process.ProcessModelInfo;
import com.raizlabs.android.dbflow.runtime.transaction.process.SaveModelTransaction;
import com.raizlabs.android.dbflow.sql.language.Delete;
import com.raizlabs.android.dbflow.sql.language.SQLite;

import java.util.List;

import rx.Observable;
import rx.Subscriber;
import rx.schedulers.Schedulers;

public class VideoLocalDataSource extends AbsLocalDataSource implements VideoDataSource {
    public VideoLocalDataSource(RxPreference preference, Context context) {
        super(preference, context);
    }

    @Override
    public Observable<List<TopVideoInfo>> getTopVideo(final String userId, String updateTime) {
        return Observable.create(new Observable.OnSubscribe<List<TopVideoInfo>>() {
            @Override
            public void call(Subscriber<? super List<TopVideoInfo>> subscriber) {
                if (!subscriber.isUnsubscribed()) {
                    List<TopVideoInfo> videoInfoList = SQLite.select()
                        .from(TopVideoInfo.class)
                        .orderBy(TopVideoInfo_Table.updateTime, false)
                        .queryList();
                    subscriber.onNext(videoInfoList);
                    subscriber.onCompleted();
                }
            }
        }).subscribeOn(Schedulers.io());
    }

    @Override
    public Observable<BaseResult> postLike(String userId, String videoId) {
        return null;
    }

    @Override
    public Observable<BaseResult> commentVideo(VideoCommentReq comment) {
        return null;
    }

    @Override
    public Observable<List<VideoInfo>> getVideoList(String albumId, int pageNum) {
        return null;
    }

    @Override
    public Observable<List<VideoInfo>> getVideoListByAlbumId(String albumId) {
        return null;
    }

    @Override
    public Observable<List<VideoCommentInfo>> getVideoComment(String videoId, String userId,String size) {
        return null;
    }

    @Override
    public Observable<List<VideoCommentInfo>> getMoreVideoComment(String videoId, String userId, int pageNum) {
        return null;
    }

    @Override
    public Observable<BaseResult> deleteVideoComment(String commentId, String videoId, String userId) {
        return null;
    }

    @Override
    public Observable<VideoInfo> getVideoInfo(String videoId) {
        return null;
    }

    @Override
    public Observable<List<TopVideoInfo>> saveTopVideoInfo(final List<TopVideoInfo> videoInfoList) {
        return Observable.create(new Observable.OnSubscribe<List<TopVideoInfo>>() {
            @Override
            public void call(Subscriber<? super List<TopVideoInfo>> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                // 先清表
                Delete.table(TopVideoInfo.class);
                // 设置主键
                for (TopVideoInfo videoInfo : videoInfoList) {
                    videoInfo.setId(videoInfo.getData().getId());
                    videoInfo.setUpdateTime(videoInfo.getData().getPublishTime());
                }
                // 插入数据
                new SaveModelTransaction<>(ProcessModelInfo.withModels(videoInfoList)).onExecute();

                subscriber.onNext(videoInfoList);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());
    }
}
