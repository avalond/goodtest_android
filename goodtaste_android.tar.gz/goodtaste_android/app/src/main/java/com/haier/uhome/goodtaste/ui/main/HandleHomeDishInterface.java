package com.haier.uhome.goodtaste.ui.main;

/**
 * 首页推荐菜谱部分点击事件的回调
 * Created by sharp on 16-5-6.
 */
public interface HandleHomeDishInterface {

    //菜谱的厨咖主页
    void onDishCookerPage(String cookerUserId);

    //打开菜谱
    void onDishMainPage(String recipeId,String title);

    //菜谱点赞
    void onDishPraise(String recipeId);
}
