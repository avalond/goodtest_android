package com.haier.uhome.goodtaste.stores;

import android.content.Context;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.actions.HomePageActions;
import com.haier.uhome.goodtaste.data.models.TopVideoInfo;

import java.util.List;

/**
 * Created by sharp on 16-5-9.
 */
public class VideoStore extends BaseStore {

    private static VideoStore instance;

    public synchronized static VideoStore get(Context context) {
        if (instance == null) {
            HaierApplication app = (HaierApplication) context.getApplicationContext();
            instance = new VideoStore(app.getRxFlux().getDispatcher());
        }
        return instance;
    }

    protected VideoStore(Dispatcher dispatcher) {
        super(dispatcher);
    }

    public static final String ID = "VideoStore";

    private List<TopVideoInfo> mTopVideoInfoList;

    @Override
    protected void onAction(RxAction action) {
        switch (action.getType()) {
            case HomePageActions.ID_PAGE_REFRESH:
                //                mChefInfoList = ((MainRefreshInfo) action.getData()).getChefInfoList();
                //需要在此将成功返回的数据写入数据库缓存起来
                break;
            case HomePageActions.ID_VIDEO_REFRESH:
                mTopVideoInfoList = (List<TopVideoInfo>) action.getData();
                //需要在此将成功返回的数据写入数据库缓存起来
                break;
            default: // 重要！！！重要！！！重要！！！ 如果不需要处理那么就要忽略该事件
                return;
        }
        postStoreChange(new RxStoreChange(ID, action));
    }


    public List<TopVideoInfo> getmTopVideoInfoList() {
        return mTopVideoInfoList;
    }
}
