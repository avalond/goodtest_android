package com.haier.uhome.goodtaste.data.models;

import com.google.gson.annotations.SerializedName;
import com.haier.uhome.goodtaste.data.source.local.GoodTasteDataBase;
import com.raizlabs.android.dbflow.annotation.ForeignKey;
import com.raizlabs.android.dbflow.annotation.ModelContainer;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.io.Serializable;

/**
 * Created by dallas on 16-5-7.
 */
@ModelContainer
@Table(database = GoodTasteDataBase.class, allFields = true)
public class TopVideoInfo extends BaseModel implements Serializable {
    private static final long serialVersionUID = 219438438985819052L;

    @PrimaryKey
    private String id;

    private String updateTime;

    @ForeignKey(saveForeignKeyModel = true)
    private UserInfo userInfo;

    @ForeignKey(saveForeignKeyModel = true)
    @SerializedName("videoInfo")
    private VideoData data;

    private String subscribeStatus;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public UserInfo getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }

    public VideoData getData() {
        return data;
    }

    public void setData(VideoData data) {
        this.data = data;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getSubscribeStatus() {
        return subscribeStatus;
    }

    public void setSubscribeStatus(String subscribeStatus) {
        this.subscribeStatus = subscribeStatus;
    }

}
