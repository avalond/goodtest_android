/*
* 文件名：SignUtils
* 版权：〈版权〉
* 描述：〈描述〉
* 修改人： malm@haierubic.com
* 修改时间：2015-09-22 
* 修改单号：〈修改单号〉
* 修改内容：〈修改内容〉
*/


package com.haier.uhome.goodtaste.utils;

import java.security.MessageDigest;

public class SignUtils {

    public static String getSign(String reqJson, String time, String appId, String appKey) {
        String md5Str = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] bytes = md.digest(reqJson.getBytes("utf-8"));//计算摘要
            md5Str = binaryToHexString(bytes);//转换成16进制字符串
        } catch (Exception e) {
            e.printStackTrace();
        }
        return md5Str;
    }

    public static String binaryToHexString(byte[] bytes) {
        StringBuilder hex = new StringBuilder();
        String hexStr = "0123456789abcdef";
        for (int i = 0; i < bytes.length; i++) {
            //字节高4位
            hex.append(String.valueOf(hexStr.charAt((bytes[i] & 0xF0) >> 4)));
            //字节低4位
            hex.append(String.valueOf(hexStr.charAt(bytes[i] & 0x0F)));
        }
        return hex.toString();
    }
}
