package com.haier.uhome.goodtaste.stores;

import android.content.Context;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.actions.DirectMessageActions;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;

import java.util.List;

/**
 * Created by Administrator on 2016/5/8.
 */
public class DirectMessageStore extends BaseStore {

    private static DirectMessageStore instance;
    public static final String ID = "direct_message_store";
    private static HaierApplication app;
    private List<MessageInfo> list;

    protected DirectMessageStore(Dispatcher dispatcher) {
        super(dispatcher);
    }
    //private Context context;//持有的是acticity，不能及时回收，会造成内存泄露

    public static DirectMessageStore get(Context context) {
        //instance.context = context;
        if (instance == null) {
            app = (HaierApplication) context.getApplicationContext();
            instance = new DirectMessageStore(app.getRxFlux().getDispatcher());
        }
        return instance;
    }

    /*public DirectMessageStore(Dispatcher dispatcher, Context context) {
        super(dispatcher);
        app = (HaierApplication) context.getApplicationContext();
    }*/

    @Override
    protected void onAction(RxAction action) {

        switch (action.getType()) {
            case DirectMessageActions.ID_GETUNREAD_MESSAGE:
                List<MessageInfo> messageInfos = (List<MessageInfo>) action.getData();
                /*if (messageInfos != null) {
                   // postStoreChange(new RxStoreChange(ID, action));
                    //DirectMessageDbUtil directMessageDbUtil = new DirectMessageDbUtil(context);
                    RxPreference pf = new RxPreference(context);
                    int x = 1;
                    for (int i = 0; i < messageInfos.size(); i++) {
                        MessageInfo messageInfo = messageInfos.get(i);
                        String msgid = messageInfo.getId();

                        if (!pf.contains(msgid)) {
                            pf.put(msgid, x);
                        } else {
                            int sum = pf.getInt(msgid, 0);
                            sum++;
                            pf.put(msgid, sum);
                        }
                       directMessageDbUtil.addDirectMessage(messageInfo.getUserId(), messageInfo.getMsgId(),
                                messageInfo.getMsg(), messageInfo.getTime(),
                                messageInfo.getNickName(), messageInfo.getUserBpic());
                        messageInfo.save();
                        //List<MessageInfo> messageInfos1 = queryMessage(messageInfo);

                    }

                }*/
                break;
            case DirectMessageActions.ID_UNREAD_SAVE_MESSAGE_LIST:
                List<MessageInfo> messageList = (List<MessageInfo>) action.getData();
                break;

            case DirectMessageActions.ID_UNREAD_MESSAGE_STATUS:
                RxPreference pf = new RxPreference(app.getApplicationContext());
                list = (List<MessageInfo>) action.getData();
                int sum ;
                if (list.size() != 0 ) {
                    sum = pf.getInt(list.get(0).getTargetUid(), 0);
                    pf.put(list.get(0).getTargetUid(), list.size() + sum);
                }

                break;
            case DirectMessageActions.ID_REMAVE_STATUS:
                String id = (String) action.getData();
                RxPreference rp = new RxPreference(app.getApplicationContext());
                if ( rp.getInt(id , 0) != 0) {
                    rp.put(id, 0);
                }

                break;
            case DirectMessageActions.ID_UPDATA_MESSAGE_STATUS:
                BaseResult baseResult = (BaseResult) action.getData();

                break;
            default:
                return;
        }

        postStoreChange(new RxStoreChange(ID, action));

    }


}
