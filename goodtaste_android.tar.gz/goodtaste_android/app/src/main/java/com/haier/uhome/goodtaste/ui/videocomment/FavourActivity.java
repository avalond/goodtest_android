package com.haier.uhome.goodtaste.ui.videocomment;

/**
 * Created by Administrator on 2016/5/11.
 */
public class FavourActivity  {
}
