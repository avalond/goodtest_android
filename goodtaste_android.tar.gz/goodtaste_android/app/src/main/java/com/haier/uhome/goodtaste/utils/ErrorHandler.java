package com.haier.uhome.goodtaste.utils;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.text.TextUtils;

import com.google.gson.JsonSyntaxException;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.exception.BaseException;
import com.haier.uhome.goodtaste.exception.NoneResponseException;

import java.net.ConnectException;
import java.net.SocketTimeoutException;


/**
 * 处理异常
 * Created by Dallas on 2016/3/15.
 */
public final class ErrorHandler {

    public static String handelError(Throwable throwable, Context context) {
        Resources res = context.getResources();
        String error = throwable.getMessage();
        if (throwable instanceof BaseException) {
            // 1. 如果没有设置错误码，则返回错误内容
            String errorCode = ((BaseException) throwable).getCode();
            if ("error".equals(errorCode)) {
                return error;
            }
            // 2. 如果有错误码并且是Http错误码
            if (TextUtils.isDigitsOnly(errorCode)) {
                int code = Integer.parseInt(errorCode);
                if (code >= 400 && code < 500) {
                    error = res.getString(R.string.request_error);
                } else if (code >= 500) {
                    error = res.getString(R.string.server_error);
                }
                return error;
            } else {
                // 3. 业务错误码
                String newCode = errorCode;
                String methodCode = "";
                String[] codes = errorCode.split("_");
                if (codes.length >= 3) {
                    newCode = codes[2];
                }
                switch (newCode) {
                    case "21015":
                    case "21016":
                    case "21018":
                    case "21019":
                        error = context.getResources().getString(R.string.token_invalide);
                        Intent intent = new Intent();
                        intent.setAction(HaierActionConst.GOTO_LOGIN_ACTION);
                        intent.addCategory(Intent.CATEGORY_DEFAULT);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(intent);
                        break;
                    case "21014":
                        error = res.getString(R.string.logout_error);
                        break;
                    case "22104":
                    case "22105":
                    case "22106":
                    case "22803": //平台修改22803表示账号已被占用 20160225
                        error = res.getString(R.string.account_exists_error);
                        break;
                    case "22101":
                    case "22821": //平台修改22821表示账号不存在 20160225
                        error = res.getString(R.string.none_account_error);
                        break;
                    case "22823":
                        error = res.getString(R.string.account_reset_error);
                        break;
                    case "22109":
                    case "22820":
                        error = res.getString(R.string.account_or_pwd_error);
                        break;
                    case "22250":
                    case "22805":
                        error = res.getString(R.string.verifynum_error);
                        break;
                    case "22251":
                        error = res.getString(R.string.verify_num_expired_error);
                        break;
                    // 非通用错误：
                    //case "JK_00003_22820":
                    //break;
                    default:
                        error = res.getString(R.string.request_error);
                        break;
                }
            }
        } else if (throwable instanceof NoneResponseException) {
            error = res.getString(R.string.none_response_error);
        } else if (throwable instanceof SocketTimeoutException) {
            error = res.getString(R.string.net_timeout);
        } else if (throwable instanceof ConnectException) {
            error = res.getString(R.string.net_no);
        } else if (throwable instanceof JsonSyntaxException) {
            error = res.getString(R.string.json_syntax_error);
        } else if (throwable instanceof retrofit2.adapter.rxjava.HttpException) {
            int code = ((retrofit2.adapter.rxjava.HttpException) throwable).code();
            if (code >= 400 && code < 500) {
                error = res.getString(R.string.request_error);
            } else if (code >= 500) {
                error = res.getString(R.string.server_error);
            }
        }
        return error;
    }
}
