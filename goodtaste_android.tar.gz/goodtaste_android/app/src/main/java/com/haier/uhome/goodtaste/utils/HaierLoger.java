package com.haier.uhome.goodtaste.utils;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * <br>Created by Dallas on 2016/1/24.
 */
public class HaierLoger {
    public static final String DEFAULT_MESSAGE = "execute";
    public static final String LINE_SEPARATOR = System.getProperty("line.separator");
    public static final String NULL_TIPS = "Log with null object";
    public static final String PARAM = "Param";
    public static final String NULL = "null";

    public static final int VERBOSE = Log.VERBOSE;
    public static final int DEBUG = Log.DEBUG;
    public static final int INFO = Log.INFO;
    public static final int WARN = Log.WARN;
    public static final int ERROR = Log.ERROR;
    public static final int ASSERT = Log.ASSERT;
    public static final int JSON = ASSERT + 110;

    public static final int JSON_INDENT = 4;

    private static boolean isShowLog = true;

    public static void showLog(boolean isShowLog) {
        HaierLoger.isShowLog = isShowLog;
    }

    public static void v() {
        printLog(VERBOSE, null, DEFAULT_MESSAGE);
    }

    public static void v(Object msg) {
        printLog(VERBOSE, null, msg);
    }

    public static void v(String tag, Object... objects) {
        printLog(VERBOSE, tag, objects);
    }

    public static void d() {
        printLog(DEBUG, null, DEFAULT_MESSAGE);
    }

    public static void d(Object msg) {
        printLog(DEBUG, null, msg);
    }

    public static void d(String tag, Object... objects) {
        printLog(DEBUG, tag, objects);
    }

    public static void i() {
        printLog(INFO, null, DEFAULT_MESSAGE);
    }

    public static void i(Object msg) {
        printLog(INFO, null, msg);
    }

    public static void i(String tag, Object... objects) {
        printLog(INFO, tag, objects);
    }

    public static void w() {
        printLog(WARN, null, DEFAULT_MESSAGE);
    }

    public static void w(Object msg) {
        printLog(WARN, null, msg);
    }

    public static void w(String tag, Object... objects) {
        printLog(WARN, tag, objects);
    }

    public static void e() {
        printLog(ERROR, null, DEFAULT_MESSAGE);
    }

    public static void e(Object msg) {
        printLog(ERROR, null, msg);
    }

    public static void e(String tag, Object... objects) {
        printLog(ERROR, tag, objects);
    }

    public static void a() {
        printLog(ASSERT, null, DEFAULT_MESSAGE);
    }

    public static void a(Object msg) {
        printLog(ASSERT, null, msg);
    }

    public static void a(String tag, Object... objects) {
        printLog(ASSERT, tag, objects);
    }

    public static void json(String jsonFormat) {
        printLog(JSON, null, jsonFormat);
    }

    private static void printLog(int type, String tagStr, Object... objects) {
        if (type == ERROR) {
            String[] contents = wrapperContent(tagStr, objects);
            String tag = contents[0];
            String msg = contents[1];
            String headString = contents[2];
            printDefault(type, tag, headString + msg);
            return;
        }

        if (!isShowLog) {
            return;
        }

        String[] contents = wrapperContent(tagStr, objects);
        String tag = contents[0];
        String msg = contents[1];
        String headString = contents[2];

        switch (type) {
            case DEBUG:
            case INFO:
            case WARN:
            case ASSERT:
                printDefault(type, tag, headString + msg);
                break;
            case JSON:
                printJson(tag, msg, headString);
                break;
            case VERBOSE:
            default:
                printDefault(VERBOSE, tag, headString + msg);

        }
    }

    private static String[] wrapperContent(String tagStr, Object... objects) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        int index = 5;
        String className = stackTrace[index].getFileName();
        String methodName = stackTrace[index].getMethodName();
        int lineNumber = stackTrace[index].getLineNumber();
        String methodNameShort = methodName.substring(0, 1).toUpperCase() + methodName.substring(1);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[ (")
            .append(className)
            .append(":")
            .append(lineNumber)
            .append(")#")
            .append(methodNameShort)
            .append(" ] ");

        String tag = (tagStr == null ? className : tagStr);
        String msg = (objects == null) ? NULL_TIPS : getObjectsString(objects);
        String headString = stringBuilder.toString();

        return new String[]{tag, msg, headString};
    }

    private static String getObjectsString(Object... objects) {

        if (objects.length > 1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("\n");
            for (int i = 0; i < objects.length; i++) {
                Object object = objects[i];
                if (object == null) {
                    stringBuilder.append(PARAM)
                        .append("[")
                        .append(i)
                        .append("]")
                        .append(" = ")
                        .append(NULL)
                        .append("\n");
                } else {
                    stringBuilder.append(PARAM)
                        .append("[")
                        .append(i)
                        .append("]")
                        .append(" = ")
                        .append(object.toString())
                        .append("\n");
                }
            }
            return stringBuilder.toString();
        } else {
            Object object = objects[0];
            return object == null ? NULL : object.toString();
        }
    }

    private static void printDefault(int type, String tag, String msg) {
        int index = 0;
        int maxLength = 4000;
        int countOfSub = msg.length() / maxLength;

        if (countOfSub > 0) {
            for (int i = 0; i < countOfSub; i++) {
                String sub = msg.substring(index, index + maxLength);
                printSub(type, tag, sub);
                index += maxLength;
            }
            printSub(type, tag, msg.substring(index, msg.length()));
        } else {
            printSub(type, tag, msg);
        }
    }

    private static void printSub(int type, String tag, String sub) {
        switch (type) {
            case DEBUG:
                Log.d(tag, sub);
                break;
            case INFO:
                Log.i(tag, sub);
                break;
            case WARN:
                Log.w(tag, sub);
                break;
            case ERROR:
                Log.e(tag, sub);
                break;
            case ASSERT:
                Log.wtf(tag, sub);
                break;
            case VERBOSE:
            default:
                Log.v(tag, sub);
                break;
        }
    }

    private static void printJson(String tag, String msg, String headString) {
        String message;

        try {
            if (msg.startsWith("{")) {
                JSONObject jsonObject = new JSONObject(msg);
                message = jsonObject.toString(JSON_INDENT);
            } else if (msg.startsWith("[")) {
                JSONArray jsonArray = new JSONArray(msg);
                message = jsonArray.toString(JSON_INDENT);
            } else {
                message = msg;
            }
        } catch (JSONException e) {
            message = msg;
        }

        printLine(tag, true);
        message = headString + LINE_SEPARATOR + message;
        String[] lines = message.split(LINE_SEPARATOR);
        for (String line : lines) {
            HaierLoger.d(tag, "║ " + line);
        }
        printLine(tag, false);
    }

    private static void printLine(String tag, boolean isTop) {
        if (isTop) {
            HaierLoger.d(tag, "╔═════════════════════════════════════════════════════════════════════════════════════");
        } else {
            HaierLoger.d(tag, "╚═════════════════════════════════════════════════════════════════════════════════════");
        }
    }
}
