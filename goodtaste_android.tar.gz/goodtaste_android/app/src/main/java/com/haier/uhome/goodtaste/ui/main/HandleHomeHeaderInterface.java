package com.haier.uhome.goodtaste.ui.main;

import com.haier.uhome.goodtaste.data.models.TopVideoInfo;
import com.haier.uhome.goodtaste.data.models.VideoData;

/**
 * 首页header部分，今日厨咖部分点击时间的回调
 * Created by sharp on 16-5-6.
 */
public interface HandleHomeHeaderInterface {

    //关注按钮的点击
    void onSubscribeUser(String followedUserId,String state);

    //用户头像的点击
    void onCookerMainPage(String cookerUserId);

    //视频图片的点击---参数待定
    void onVideoMainPage(VideoData videoData);

    //点赞的点击
    void onVideoPraise(String videoId);

}
