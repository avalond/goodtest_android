package com.haier.uhome.goodtaste.data.models;

import com.haier.uhome.goodtaste.data.source.local.GoodTasteDataBase;
import com.raizlabs.android.dbflow.annotation.ForeignKey;
import com.raizlabs.android.dbflow.annotation.ModelContainer;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.structure.BaseModel;
import com.raizlabs.android.dbflow.structure.container.ForeignKeyContainer;

import java.io.Serializable;

/**
 * 食材用量对象
 * <br>Created by dallas on 16-5-7.
 */
@ModelContainer
@Table(database = GoodTasteDataBase.class, allFields = true)
public class Ingredients extends BaseModel implements Serializable {

    private static final long serialVersionUID = 897002175085013489L;
    /**
     * id : ”主键Id”
     * name  : 食材名称
     * tagName  : 分类名称
     * usage  : 用量
     * type  : 食材类型（主料，辅料，配料）
     */
    @PrimaryKey
    private String id;

    private String name;
    private String tagName;
    private String usage;
    private String type;

    @ForeignKey(saveForeignKeyModel = false)
    ForeignKeyContainer<RecipeData> recipeDataForeignKeyContainer;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public String getUsage() {
        return usage;
    }

    public void setUsage(String usage) {
        this.usage = usage;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void associateRecipeData(RecipeData recipeData) {
        recipeDataForeignKeyContainer = FlowManager.getContainerAdapter(RecipeData.class)
            .toForeignKeyContainer(recipeData);
    }
}
