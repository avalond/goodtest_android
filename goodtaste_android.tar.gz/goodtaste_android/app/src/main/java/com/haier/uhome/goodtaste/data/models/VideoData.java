package com.haier.uhome.goodtaste.data.models;

import com.haier.uhome.goodtaste.data.source.local.GoodTasteDataBase;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.io.Serializable;

/**
 * Created by dallas on 16-5-11.
 */
@Table(database = GoodTasteDataBase.class, allFields = true)
public class VideoData extends BaseModel implements Serializable {
    private static final long serialVersionUID = -1673917623498051588L;

    @PrimaryKey
    private String id;

    private String albumId;
    private String albumName;
    private String name;
    private String videoUrl;
    private String videoNetUrl;
    private String thumbnail;
    private int status;
    private int isComment;
    private int isRecommend;
    private String remark;
    private String publishUser;
    private String publishTime;
    private int playNum;
    private int supportNumber;
    private int notSupportNumber;
    private int replyNumber;
    private int shareNumber;
    private String shareUrl;
    private boolean isPraise = false;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAlbumId() {
        return albumId;
    }

    public void setAlbumId(String albumId) {
        this.albumId = albumId;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public String getVideoNetUrl() {
        return videoNetUrl;
    }

    public void setVideoNetUrl(String videoNetUrl) {
        this.videoNetUrl = videoNetUrl;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getIsComment() {
        return isComment;
    }

    public void setIsComment(int isComment) {
        this.isComment = isComment;
    }

    public int getIsRecommend() {
        return isRecommend;
    }

    public void setIsRecommend(int isRecommend) {
        this.isRecommend = isRecommend;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getPublishUser() {
        return publishUser;
    }

    public void setPublishUser(String publishUser) {
        this.publishUser = publishUser;
    }

    public String getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(String publishTime) {
        this.publishTime = publishTime;
    }

    public int getPlayNum() {
        return playNum;
    }

    public void setPlayNum(int playNum) {
        this.playNum = playNum;
    }

    public int getSupportNumber() {
        return supportNumber;
    }

    public void setSupportNumber(int supportNumber) {
        this.supportNumber = supportNumber;
    }

    public int getNotSupportNumber() {
        return notSupportNumber;
    }

    public void setNotSupportNumber(int notSupportNumber) {
        this.notSupportNumber = notSupportNumber;
    }

    public int getReplyNumber() {
        return replyNumber;
    }

    public void setReplyNumber(int replyNumber) {
        this.replyNumber = replyNumber;
    }

    public int getShareNumber() {
        return shareNumber;
    }

    public void setShareNumber(int shareNumber) {
        this.shareNumber = shareNumber;
    }

    public String getShareUrl() {
        return shareUrl;
    }

    public void setShareUrl(String shareUrl) {
        this.shareUrl = shareUrl;
    }

    public boolean getIsPraise() {
        return isPraise;
    }

    public void setIsPraise(boolean isPraise) {
        this.isPraise = isPraise;
    }
}
