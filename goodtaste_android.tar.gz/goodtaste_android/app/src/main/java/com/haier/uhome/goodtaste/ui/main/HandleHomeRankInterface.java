package com.haier.uhome.goodtaste.ui.main;

/**
 * 首页厨咖排名部分点击事件的回调
 * Created by sharp on 16-5-6.
 */
public interface HandleHomeRankInterface {

    //厨咖主页
    void onCookerMainPage(String userId ,String cookerUserId);

    //厨咖排名页
    void onCookerRankListPage();

}
