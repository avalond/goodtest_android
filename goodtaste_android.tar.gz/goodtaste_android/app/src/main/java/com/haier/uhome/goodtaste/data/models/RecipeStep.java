package com.haier.uhome.goodtaste.data.models;

import com.haier.uhome.goodtaste.data.source.local.GoodTasteDataBase;
import com.raizlabs.android.dbflow.annotation.ForeignKey;
import com.raizlabs.android.dbflow.annotation.ModelContainer;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.structure.BaseModel;
import com.raizlabs.android.dbflow.structure.container.ForeignKeyContainer;

import java.io.Serializable;

/**
 * 菜谱步骤
 * <br>Created by dallas on 16-5-7.
 */
@ModelContainer
@Table(database = GoodTasteDataBase.class, allFields = true)
public class RecipeStep extends BaseModel implements Serializable {
    private static final long serialVersionUID = 6402833633989683513L;

    /**
     * id : ”主键Id”
     * pic  : 图片大小
     * picUrl  : 图片地址
     * note  : 步骤描述
     */
    @PrimaryKey
    private String id;

    private String pic;
    private String picUrl;
    private String note;

    @ForeignKey(saveForeignKeyModel = false)
    ForeignKeyContainer<RecipeData> recipeDataForeignKeyContainer;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public void associateRecipeData(RecipeData recipeData) {
        recipeDataForeignKeyContainer = FlowManager.getContainerAdapter(RecipeData.class)
            .toForeignKeyContainer(recipeData);
    }
}
