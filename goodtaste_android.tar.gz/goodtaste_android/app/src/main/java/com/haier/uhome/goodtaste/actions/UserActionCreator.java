package com.haier.uhome.goodtaste.actions;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.util.SubscriptionManager;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.UserProfileType;
import com.haier.uhome.goodtaste.data.source.CommonDataSource;
import com.haier.uhome.goodtaste.data.source.UserDataSource;
import com.haier.uhome.goodtaste.exception.BaseException;
import com.haier.uhome.goodtaste.utils.AccountUtil;
import com.haier.uhome.goodtaste.utils.BitmapUtil;
import com.haier.uhome.goodtaste.utils.MD5Utils;

import java.io.File;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

/**
 * <p>Created by dallas on 16-4-19.
 */
public class UserActionCreator extends BaseActionCreator implements UserActions {

    public UserActionCreator(Context context, DataManager dataManager, Dispatcher dispatcher,
        SubscriptionManager subscriptionManager) {
        super(context, dataManager, dispatcher, subscriptionManager);
    }

    @Override
    public void register(String account, String pwd, String uvc) {
        final RxAction action = newRxAction(ID_REGISTER, null);
        if (hasRxAction(action)) {
            return;
        }
        if (TextUtils.isEmpty(uvc)) {
            postError(action, new BaseException(mContext.getString(R.string.null_regis_verification)));
            return;
        }
        if (TextUtils.isEmpty(pwd)) {
            postError(action, new BaseException(mContext.getString(R.string.pls_input_pwd)));
            return;
        }
        if (!AccountUtil.getVerify(uvc)) {
            postError(action, new BaseException(mContext.getString(R.string.invalid_regis_verification)));
            return;
        }
        UserDataSource repository = mDataManager.getUserRepository();
        Subscription subscription = repository.register(account, pwd, uvc, "").subscribe(new Subscriber<BaseResult>() {

            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(BaseResult baseResult) {
                RxAction<BaseResult> resultAction = newRxAction(ID_REGISTER, baseResult);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }


    @Override
    public void getUserInfo(String userId) {
        final RxAction action = newRxAction(ID_GET_USER_INFO, null);
        if (hasRxAction(action)) {
            return;
        }
        postShowLoading("");
        UserDataSource repository = mDataManager.getUserRepository();
        Subscription subscription = repository.findUserInfoById(userId).subscribe(new Subscriber<UserInfo>() {
            @Override
            public void onCompleted() {
                postStopLoading();
            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(UserInfo userInfo) {
                RxAction<UserInfo> resultAction = newRxAction(ID_GET_USER_INFO, userInfo);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    @Override
    public void uploadAvatar(final String userId, File file) {
        final RxAction action = newRxAction(ID_UPLOAD_AVATAR, null);
        if (hasRxAction(action)) {
            return;
        }

        Subscription subscription = resizeBitmap(file, 300, 300).flatMap(new Func1<File, Observable<String>>() {
            @Override
            public Observable<String> call(File file) {
                return updateUserAvatar(userId, file);
            }
        })  .observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<String>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(String avatarUrl) {
                RxAction<String> resultAction = newRxAction(ID_UPLOAD_AVATAR, avatarUrl);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    @Override
    public void updateUserProfile(String userId, @UserProfileType.Type final int type, final String content) {
        final RxAction action = newRxAction(ID_UPDATE_USER_PROFILE, null);
        if (hasRxAction(action)) {
            return;
        }
        UserDataSource repository = mDataManager.getUserRepository();
        Subscription subscription = repository.updateUserInfoById(userId, type, content)
            .subscribe(new Subscriber<BaseResult>() {
                @Override
                public void onCompleted() {
                }

                @Override
                public void onError(Throwable e) {
                    postError(action, e);
                }

                @Override
                public void onNext(BaseResult recipeInfos) {
                    Bundle data = new Bundle();
                    data.putInt("type", type);
                    data.putString("content", content);

                    RxAction<Bundle> resultAction = newRxAction(ID_UPDATE_USER_PROFILE, data);
                    postRxAction(resultAction);
                }
            });
        addRxAction(action, subscription);
    }

    @Override
    public void postUvcMobile(String account, String pwd, String confirmPwd) {
        final RxAction action = newRxAction(ID_POST_UVC_MOBILE, null);
        if (hasRxAction(action)) {
            return;
        }
        if (TextUtils.isEmpty(account)) {
            postError(action, new BaseException(mContext.getString(R.string.null_phone_number)));
            return;
        }
        if (!AccountUtil.isMobileNum(account)) {
            postError(action, new BaseException(mContext.getString(R.string.invalid_phone_number)));
            return;
        }

        UserDataSource repository = mDataManager.getUserRepository();

        Subscription subscription = repository.applyRegMsgCode(account).subscribe(new Subscriber<BaseResult>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
                postError(action, e);
            }

            @Override
            public void onNext(BaseResult baseResult) {
                RxAction<BaseResult> resultAction = newRxAction(ID_POST_UVC_MOBILE, baseResult);
                postRxAction(resultAction);
            }
        });
        addRxAction(action, subscription);
    }

    private Observable<File> resizeBitmap(final File imageFile, final int destWidth, final int destHeight) {
        return Observable.create(new Observable.OnSubscribe<File>() {
            @Override
            public void call(Subscriber<? super File> subscriber) {
                try {
                    Bitmap temp = BitmapUtil.decodeBitmap(imageFile, destWidth, destHeight);
                    File directory = BitmapUtil.getImageCacheDir(mContext);
                    File result = BitmapUtil.saveBitmap(temp, directory.getPath(),
                        MD5Utils.md5(imageFile.getPath().getBytes()) + ".jpg");
                    temp.recycle();

                    subscriber.onNext(result);
                    subscriber.onCompleted();
                } catch (Exception e) {
                    e.printStackTrace();
                    subscriber.onError(e);
                }
            }
        }).subscribeOn(Schedulers.io());
    }

    private Observable<String> updateUserAvatar(final String userId, final File file) {
        final CommonDataSource repository = mDataManager.getCommonRepository();
        final UserDataSource userRepository = mDataManager.getUserRepository();
        return Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                // 上传头像至资源服务器
                String url = repository.uploadAvatar(userId, file).toBlocking().single();
                if (TextUtils.isEmpty(url)) {
                    Observable.error(new BaseException(mContext.getString(R.string.avatar_upload_failed)));
                    return;
                }
                // 更新用户头像URL
                BaseResult result = userRepository.updateUserInfoById(userId, UserProfileType.AVATAR, url)
                    .toBlocking()
                    .single();
                if (!BaseResult.RET_OK.equals(result.getRetCode())) {
                    Observable.error(new BaseException(mContext.getString(R.string.avatar_upload_failed)));
                    return;
                }
                subscriber.onNext(url);
                subscriber.onCompleted();
            }
        });
    }
}
