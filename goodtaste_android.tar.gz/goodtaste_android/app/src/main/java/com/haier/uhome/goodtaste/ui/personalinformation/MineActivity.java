package com.haier.uhome.goodtaste.ui.personalinformation;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.actions.DirectMessageActionCreator;
import com.haier.uhome.goodtaste.actions.DirectMessageActions;
import com.haier.uhome.goodtaste.actions.UserActionCreator;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.source.remote.services.H5HybirdUrl;
import com.haier.uhome.goodtaste.stores.DirectMessageStore;
import com.haier.uhome.goodtaste.stores.UserStore;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.ui.WebActivity;
import com.haier.uhome.goodtaste.ui.collection.MyCollectionActivity;
import com.haier.uhome.goodtaste.ui.login.LoginActivity;
import com.haier.uhome.goodtaste.ui.message.DirectMessagesActivity;
import com.haier.uhome.goodtaste.utils.DateUtil;
import com.haier.uhome.goodtaste.utils.ErrorHandler;
import com.haier.uhome.goodtaste.utils.ImageDownLoader;
import com.haier.uhome.goodtaste.widgets.DialogHelper;
import com.haier.uhome.goodtaste.widgets.roundedimageview.RoundedImageView;

import java.util.List;

import bf.cloud.hybrid.HybridActivity;
import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by Administrator on 2016/5/10.
 */
public class MineActivity extends BaseActivity {

    private DirectMessageStore directMessageStore;
    private TextView mRightBtn;

    @Bind(R.id.iv_user_icon)
    RoundedImageView userIcon;
    @Bind(R.id.tv_nick_name)
    TextView nickName;
    @Bind(R.id.tv_level)
    TextView level;
    @Bind(R.id.tv_integral)
    TextView integral;
    @Bind(R.id.tv_fans)
    TextView fans;
    @Bind(R.id.tv_followsNumber)
    TextView followsNumber;
    @Bind(R.id.ll_login)
    LinearLayout login;
    @Bind(R.id.ll_unlogin)
    LinearLayout unlogin;
    @Bind(R.id.ll_mine_all)
    LinearLayout mine;

    private UserStore mUserStore;
    private String userid;
    private DirectMessageActionCreator deviceActionCreator;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mine);
        setToolbarTitle(getString(R.string.information_people));
        mine.setVisibility(View.INVISIBLE);

        infilsh();
    }
    //刷新数据
    private void infilsh() {
        //super.onResume();
        //UserActionCreator mUserActionCreator = getApp().getUserActionCreator();
        //mUserActionCreator.getUserInfo(mUserStore.getUserId());
        //showProgressDialog(getString(R.string.information_loading));
        deviceActionCreator = new DirectMessageActionCreator(this,
                getApp().getDataManager(),
                getApp().getRxFlux().getDispatcher(), getApp().getRxFlux().getSubscriptionManager());

        UserInfo userInfo = mUserStore.getUserInfo();
        /*if (userInfo != null) {
            ImageDownLoader.get(this).display(userInfo.getAvater(), R.drawable.head_default_icon, userIcon);
            ImageDownLoader.get(this).display(userInfo.getAvater() ,
                    R.drawable.head_default_icon ,userIcon);
            nickName.setText(userInfo.getNickName());
            level.setText(userInfo.getLevelName());
            integral.setText(userInfo.getScore());
            fans.setText(userInfo.getFansNumber());
            followsNumber.setText(userInfo.getFollowsNumber());
            //stopProgressDialog();
            mine.setVisibility(View.VISIBLE);
        }
        userid = mUserStore.getUserId();

        deviceActionCreator.getUnReadMessStatus(userid);
        UserActionCreator mUserActionCreator = getApp().getUserActionCreator();
        mUserActionCreator.getUserInfo(mUserStore.getUserId());*/
        if (TextUtils.isEmpty(mUserStore.getAccessToken())) {
            unlogin.setVisibility(View.VISIBLE);
            login.setVisibility(View.INVISIBLE);
            mRightBtn.setVisibility(View.INVISIBLE);
            mine.setVisibility(View.VISIBLE);
        } else {
            login.setVisibility(View.VISIBLE);
            unlogin.setVisibility(View.INVISIBLE);
            mRightBtn.setVisibility(View.VISIBLE);
            mine.setVisibility(View.VISIBLE);
            if (userInfo != null) {
                ImageDownLoader.get(this).display(userInfo.getAvater(), R.drawable.head_default_icon, userIcon);
                ImageDownLoader.get(this).display(userInfo.getAvater() ,
                        R.drawable.head_default_icon ,userIcon);
                nickName.setText(userInfo.getNickName());
                level.setText(userInfo.getLevelName());
                integral.setText(userInfo.getScore());
                fans.setText(userInfo.getFansNumber());
                followsNumber.setText(userInfo.getFollowsNumber());
                //stopProgressDialog();
                mine.setVisibility(View.VISIBLE);
            }else{
                showProgressDialog(getString(R.string.information_loading));
                userid = mUserStore.getUserId();
                deviceActionCreator.getUnReadMessStatus(userid);
                UserActionCreator mUserActionCreator = getApp().getUserActionCreator();
                mUserActionCreator.getUserInfo(mUserStore.getUserId());
            }
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (resultCode){

            case RESULT_OK:
                infilsh();
                break;
            case RESULT_CODE_INFORMATION:
                infilsh();
                break;
            default:
                break;

        }
    }

    @Override
    protected View createToolbarView(LayoutInflater inflater, ViewGroup container) {
        View view = super.createToolbarView(inflater, container);
        //TextView mLeftBack = (TextView) view.findViewById(R.id.toolbar_left_btn);
        mRightBtn = (TextView) view.findViewById(R.id.toolbar_right_btn);
        mRightBtn.setVisibility(View.VISIBLE);
        showDrawable(R.drawable.top_message);
        return view;
    }

    @Override
    protected void onToolbarRightButtonClicked(View v) {
        super.onToolbarRightButtonClicked(v);
        if (TextUtils.isEmpty(mUserStore.getAccessToken())) {
            Intent intent = new Intent(MineActivity.this, LoginActivity.class);
            startActivityForResult(intent , RESULT_CODE_LOGIN);
        } else {
            showDrawable(R.drawable.top_message);
            Intent intent = new Intent(MineActivity.this, DirectMessagesActivity.class);
            startActivity(intent);
        }

    }
    public static final int RESULT_CODE_LOGIN= 1000;
    public static final int RESULT_CODE_INFORMATION= 1001;
    @OnClick(R.id.ll_gologin)
    protected void goLogin() {

        Intent intent = new Intent(MineActivity.this, LoginActivity.class);
        startActivityForResult(intent , RESULT_CODE_LOGIN);

    }

    @OnClick(R.id.ll_fans)
    protected void showMyFans(){

        String webUrl =H5HybirdUrl.getSocialFanH5Url(userid ,userid);
        Intent intent = new Intent().setClass(this, WebActivity.class);
        intent.putExtra(WebActivity.URL,webUrl);
        intent.putExtra(WebActivity.TITLE,getString(R.string.my_fans));
        startActivity(intent);
    }

    @OnClick(R.id.ll_followsNumber)
    protected void showIntegral(){

        String webUrl =H5HybirdUrl.getSocialH5Url(userid ,userid);
        Intent intent = new Intent().setClass(this, WebActivity.class);
        intent.putExtra(WebActivity.TITLE,getString(R.string.my_followsNumber));
        intent.putExtra(WebActivity.URL,webUrl);
        startActivity(intent);
    }

    @OnClick(R.id.ll_user)
    protected void goUser() {
        Intent i = new Intent(this, PersonalInformationActivity.class);
        startActivityForResult(i , RESULT_CODE_LOGIN);
    }

    @OnClick(R.id.ll_my_collection)
    protected void goMyCollection() {
        if (TextUtils.isEmpty(mUserStore.getAccessToken())) {
            Intent intent = new Intent(MineActivity.this, LoginActivity.class);
            startActivityForResult(intent , RESULT_CODE_LOGIN);

        } else {
            Intent i = new Intent(this, MyCollectionActivity.class);
            startActivity(i);
        }

    }


    @OnClick(R.id.ll_invitation_friend)
    protected void toInvitationFriend(){

        if (TextUtils.isEmpty(mUserStore.getAccessToken())) {
            Intent intent = new Intent(MineActivity.this, LoginActivity.class);
            startActivityForResult(intent , RESULT_CODE_LOGIN);

        } else {
            DialogHelper dialogHelper = new DialogHelper(this);
            String url = H5HybirdUrl.instance().getInviteShareH5Url();
            UserInfo userInfo = UserStore.get(this).getUserInfo();
            String code = "";
            if(userInfo != null){
                code = userInfo.getInviteCode();
            }

            dialogHelper.showInviteFriendShare(code, url);
        }

    }

    @Override
    public void onRxStoresRegister() {
        //directMessageStore = new DirectMessageStore(getApp().getRxFlux().getDispatcher(), this);
        directMessageStore = DirectMessageStore.get(this);
        directMessageStore.register();
        mUserStore = UserStore.get(this);
        mUserStore.register();
    }

    @Override
    public void onRxStoresUnRegister() {
        directMessageStore.unregister();
        mUserStore.unregister();
    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {
        switch (change.getStoreId()) {
            case DirectMessageStore.ID:
                switch (change.getRxAction().getType()) {
                    case DirectMessageActions.ID_UNREAD_MESSAGE_STATUS:
                        List<MessageInfo> messageInfos = (List<MessageInfo>) change.getRxAction().getData();
                        if (messageInfos.size() == 0) {
                            showDrawable(R.drawable.top_message);
                        } else {
                            showDrawable(R.drawable.top_has_unread_message);
                        }

                        break;
                    default:
                        break;
                }
                break;
            case UserStore.ID:
                switch (change.getRxAction().getType()) {
                    case UserActionCreator.ID_GET_USER_INFO:
                        UserInfo userInfo = (UserInfo) change.getRxAction().getData();
                        if (userInfo != null) {
                            ImageDownLoader.get(this)
                                .display(userInfo.getAvater(), R.drawable.head_default_icon, userIcon);
                            ImageDownLoader.get(this).display(userInfo.getAvater() ,
                                    R.drawable.head_default_icon ,userIcon);
                            nickName.setText(userInfo.getNickName());
                            level.setText(userInfo.getLevelName());
                            integral.setText(userInfo.getScore());
                            fans.setText(userInfo.getFansNumber());
                            followsNumber.setText(userInfo.getFollowsNumber());
                            stopProgressDialog();
                            mine.setVisibility(View.VISIBLE);
                        }
                        break;
                    default:
                        break;
                }
            default:
                break;
        }
    }

    private void showDrawable(int res) {
        Drawable drawable = getResources()
                .getDrawable(res);
        /// 这一步必须要做,否则不会显示.
        drawable.setBounds(0, 0, drawable.getMinimumWidth(),
                drawable.getMinimumHeight());
        mRightBtn.setCompoundDrawables(drawable, null, null, null);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        layoutParams.addRule(RelativeLayout.CENTER_VERTICAL);
        //layoutParams.rightMargin = 10;
        mRightBtn.setLayoutParams(layoutParams);
    }

    @Override
    public void onRxError(RxError error) {

        stopProgressDialog();
        showToast(ErrorHandler.handelError(error.getThrowable(), this));
    }
}
