package com.haier.uhome.goodtaste.ui.message;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.actions.DirectMessageActionCreator;
import com.haier.uhome.goodtaste.actions.DirectMessageActions;
import com.haier.uhome.goodtaste.data.models.MessageInfo;
import com.haier.uhome.goodtaste.data.source.remote.services.H5HybirdUrl;
import com.haier.uhome.goodtaste.stores.DirectMessageStore;
import com.haier.uhome.goodtaste.stores.UserStore;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.ui.WebActivity;
import com.haier.uhome.goodtaste.utils.DateUtil;
import com.haier.uhome.goodtaste.utils.ErrorHandler;
import com.haier.uhome.goodtaste.utils.ImageDownLoader;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;
import com.haier.uhome.goodtaste.widgets.MessageListView;
import com.haier.uhome.goodtaste.widgets.roundedimageview.RoundedImageView;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;

/**
 * Created by Administrator on 2016/5/4.
 */
public class DirectMessagesActivity extends BaseActivity {

    private List<MessageInfo> list = new ArrayList<>();

    @Bind(R.id.lv_direct_message)
    MessageListView lvDirectMessage;
    private MyAdapter adapter;
    private DirectMessageStore directMessageStore;
    private DirectMessageActionCreator deviceActionCreator;
    private UserStore mUserStore;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_direct_message);
        showToolbar();
        setToolbarTitle(getString(R.string.direct_message));
        //directMessageDbUtil = new DirectMessageDbUtil(this);
        //list = MessageInfo.
        showProgressDialog();
        deviceActionCreator =  new DirectMessageActionCreator(this , getApp().getDataManager() ,
                getApp().getRxFlux().getDispatcher(),getApp().getRxFlux().getSubscriptionManager());
        //list = deviceActionCreator.queryMessage();
        mUserStore = UserStore.get(this);
        //将服务器返回的未读消息信息获取到并保存到数据库
        deviceActionCreator.getUnReadMessageList(mUserStore.getUserId());


    }

    @Override
    protected View createToolbarView(LayoutInflater inflater, ViewGroup container) {
        View v = super.createToolbarView(inflater, container);
        TextView mRightBtn = (TextView) v.findViewById(R.id.toolbar_right_btn);
        mRightBtn.setVisibility(View.INVISIBLE);
        return v;
    }

    private void initData() {

        if (list != null) {
            adapter = new MyAdapter();
            lvDirectMessage.setAdapter(adapter);
        }
        lvDirectMessage.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (!isRefresh) {
                    TextView tv = (TextView) view.findViewById(R.id.tv_message_unread);
                    tv.setVisibility(View.GONE);
                    //pf.put(list.get(position - 1).getNickName(), 0);
                    //deviceActionCreator.setSp(list.get(position - 1).getId());
                    //将本地数据清除
                    deviceActionCreator.removeSp(list.get(position - 1).getTargetUid());
                    Intent i = new Intent(DirectMessagesActivity.this, MessageActivity.class);
                    MessageInfo messageInfo = list.get(position - 1);
                    i.putExtra(getString(R.string.friend), messageInfo.getNickName());
                    i.putExtra(getString(R.string.userid), messageInfo.getTargetUid());
                    i.putExtra(getString(R.string.msgid), messageInfo.getId());
                    startActivity(i);
                }
            }
        });


        lvDirectMessage.setOnRefreshListener(new MessageListView.OnRefreshListenter() {
            @Override
            public void refresh() {
                deviceActionCreator.getUnReadMessageList(mUserStore.getUserId());
                //deviceActionCreator.getUnReadMessStatus(mUserStore.getUserId());
                isRefresh = true;
            }
        });



    }

    Boolean isRefresh ;

    @Override
    public void onRxStoresRegister() {
        //directMessageStore = new DirectMessageStore(getApp().getRxFlux().getDispatcher() , this);
        directMessageStore = DirectMessageStore.get(this);
        directMessageStore.register();
    }

    @Override
    public void onRxStoresUnRegister() {
        directMessageStore.unregister();
    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {

        switch (change.getStoreId()) {
            case DirectMessageStore.ID:
                switch (change.getRxAction().getType()) {
                    case DirectMessageActions.ID_UNREAD_SAVE_MESSAGE_LIST:

                        lvDirectMessage.finish();
                        isRefresh = false;
                        //showToast("更新完成");
                        //list = queryMessage();
                        // MessageInfo info = (MessageInfo) change.getRxAction().getData();
                        //list = deviceActionCreator.queryMessage();
                        list = (List<MessageInfo>) change.getRxAction().getData();
                        if (list.size() != 0){
                            deviceActionCreator.updateMsgStatus(mUserStore.getUserId() ,
                                    DateUtil.getFormatCurrentTime());

                        }else{
                            deviceActionCreator.getUnReadMessStatus(mUserStore.getUserId());
                        }
                        stopProgressDialog();
                        //sum = list.size();
                        //adapter.notifyDataSetChanged();
                        initData();
                        break;
                    case DirectMessageActions.ID_UNREAD_MESSAGE_STATUS:
                        //rp = new RxPreference(this);
                        List<MessageInfo> messageList = (List<MessageInfo>) change.getRxAction().getData();
                        if (messageList != null){
                            stopProgressDialog();
                            newMsgSum = messageList.size();
                        }

                        adapter.notifyDataSetChanged();
                        break;
                    case DirectMessageActions.ID_REMAVE_STATUS:

                       /* List<MessageInfo> messageList = (List<MessageInfo>) change.getRxAction().getData();
                        if (messageList != null){
                            stopProgressDialog();
                        }
                        sum = messageList.size();
                        adapter.notifyDataSetChanged();*/
                        break;
                    default:
                        return;
                }

            default:
                return;
        }
    }

    @Override
    public void onRxError(RxError error) {
        isRefresh = false;
        lvDirectMessage.finish();
        showToast(ErrorHandler.handelError(error.getThrowable(), this));
    }

    private int newMsgSum;
    private RxPreference rp ;
    private class MyAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView == null) {
                convertView = View.inflate(getApplicationContext(), R.layout.item_direct_message_list, null);
                holder = new ViewHolder();
                holder.fl = (RoundedImageView) convertView.findViewById(R.id.iv_direct_message);
                holder.tvData = (TextView) convertView.findViewById(R.id.tv_direct_data);
                holder.tvMessage = (TextView) convertView.findViewById(R.id.tv_direct_message);
                holder.tvName = (TextView) convertView.findViewById(R.id.tv_direct_name);
                holder.tvUnReadMessage = (TextView) convertView.findViewById(R.id.tv_message_unread);
                convertView.setTag(holder);

            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            final MessageInfo messageInfo = list.get(position);
            holder.tvName.setText(messageInfo.getNickName());
            holder.tvData.setText(messageInfo.getTime());
            holder.tvMessage.setText(messageInfo.getMsg());
            //要在本地保存未读消息个数，再点击条目时消失 ，
            //如果没有点击的话还是要显示对应的未读消息个数
            //int sum = rp.getInt(messageInfo.getTargetUid(), 0);
            deviceActionCreator.getUnReadMessStatus(mUserStore.getUserId());
            //int temp = sum + newMsgSum;
            if (newMsgSum != 0) {
                holder.tvUnReadMessage.setVisibility(View.VISIBLE);
                holder.tvUnReadMessage.setText(newMsgSum + "");
            }
            holder.tvMessage.setText(messageInfo.getMsg());
            ImageDownLoader.get(DirectMessagesActivity.this)
                .display(messageInfo.getAvater(), R.drawable.head_default_icon, holder.fl);
            ImageDownLoader.get(DirectMessagesActivity.this).display(messageInfo.getAvater() ,
                    R.drawable.head_default_icon ,holder.fl);
            holder.fl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //跳转用户主页
                    String webUrl = H5HybirdUrl.getCookerPersonalH5Url(messageInfo.getFromUid() ,
                            mUserStore.getUserId());
                    Intent intent = new Intent().setClass(DirectMessagesActivity.this, WebActivity.class);
                    intent.putExtra(WebActivity.URL,webUrl);
                    intent.putExtra(WebActivity.TITLE,getString(R.string.his_mine));
                    startActivity(intent);
                }
            });
            return convertView;
        }
    }

    class ViewHolder {
        public RoundedImageView fl;
        public TextView tvName;
        public TextView tvMessage;
        public TextView tvData;
        public TextView tvUnReadMessage;
    }

    /*private List<MessageInfo> queryMessage() {

        List<MessageInfo> queryList = new ArrayList<>();
        Map map = directMessageDbUtil.queryAllDirectMessages();
        Iterator<Map.Entry<String, MessageInfo>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, MessageInfo> entry = it.next();
            queryList.add(entry.getValue());
        }
        Collections.sort(queryList, new Comparator<MessageInfo>() {
            @Override
            public int compare(MessageInfo lhs, MessageInfo rhs) {
                if (DateUtil.getDateFromString(lhs.getTime(), "yyyy-MM-dd HH:mm:ss").getTime() >
                        DateUtil.getDateFromString(rhs.getTime(), "yyyy-MM-dd HH:mm:ss").getTime()) {
                    return -1;
                }
                if (DateUtil.getDateFromString(lhs.getTime(), "yyyy-MM-dd HH:mm:ss").getTime() >
                        DateUtil.getDateFromString(rhs.getTime(), "yyyy-MM-dd HH:mm:ss").getTime()) {
                    return 0;
                }
                return 1;
            }
        });

        return queryList;

    }*/


}
