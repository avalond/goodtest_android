package com.haier.uhome.goodtaste.actions;

/**
 * <br>Created by dallas on 16-4-18.
 */
public interface LoadingIndicatorActions {
    String ID_SHOW_LOADING = "show_loading";
    String ID_STOP_LOADING = "stop_loading";
}
