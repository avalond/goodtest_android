package com.haier.uhome.goodtaste.data.models;

import com.haier.uhome.goodtaste.data.source.local.GoodTasteDataBase;
import com.raizlabs.android.dbflow.annotation.ModelContainer;
import com.raizlabs.android.dbflow.annotation.Table;

@ModelContainer
@Table(database = GoodTasteDataBase.class, allFields = true)
public class ChefInfo extends UserInfo {
    private static final long serialVersionUID = 8315467180366315850L;
}
