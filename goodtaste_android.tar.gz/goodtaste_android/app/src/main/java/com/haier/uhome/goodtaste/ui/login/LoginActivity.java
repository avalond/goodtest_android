package com.haier.uhome.goodtaste.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.gmail.adffice.rxflux.RxFlux;
import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.actions.LoginActionCreator;
import com.haier.uhome.goodtaste.actions.LoginActions;
import com.haier.uhome.goodtaste.actions.UserActionCreator;
import com.haier.uhome.goodtaste.actions.UserActions;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.HaierPreference;
import com.haier.uhome.goodtaste.data.models.AccType;
import com.haier.uhome.goodtaste.data.models.LoginInfo;
import com.haier.uhome.goodtaste.stores.BaseStore;
import com.haier.uhome.goodtaste.stores.LoginStore;
import com.haier.uhome.goodtaste.stores.UserRegisStore;
import com.haier.uhome.goodtaste.stores.UserStore;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.ui.WebActivity;
import com.haier.uhome.goodtaste.ui.main.HomeActivity;
import com.haier.uhome.goodtaste.ui.main.HomeMainActivity;
import com.haier.uhome.goodtaste.ui.register.RegisterActivity;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.widgets.ImageEditText;
import com.haier.uhome.goodtaste.utils.ErrorHandler;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;
import com.haier.uhome.social.OauthListener;
import com.haier.uhome.social.OauthPlatform;
import com.haier.uhome.social.OauthTool;
import com.umeng.socialize.handler.UMQQSsoHandler;

import java.util.Map;

import butterknife.Bind;
import butterknife.OnClick;
import rx.Observable;

/**
 * <br>Created by dallas on 16-4-18.
 */
public class LoginActivity extends BaseActivity  {
    @Bind(R.id.et_account)
    ImageEditText etAccount;
    @Bind(R.id.et_password)
    ImageEditText etPassword;
    @Bind(R.id.login_seepw)
    ImageView loginSeepw;

    private UserStore mUserStore;
    private LoginStore mLoginStore;
    private UserActionCreator mUserActionCreator;
    private LoginActionCreator mLoginActionCreator;
    private CheckBox rePassword;
    private static final String QQAPPID="1105330535";
    private static final String WXAPPID="wxb368f746fab5e730";
    private String qqOpenId;
    private String qqAccessToken;
    private String wxOpenId;
    private String wxAccessToken;
    private  Boolean noPw=true;
    private OauthTool oauthTool;
    private String type;
    private Boolean remberPasseord=true;
    private TextView mLeftBack;//ActionBar左侧按钮
    private TextView mRightBtn;//ActionBar左侧按钮
    private RxFlux mRxFlux;
    private DataManager mDataManager;
    public static final int RESULT_CODE = 1000;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        showToolbar();
        setToolbarTitle(getString(R.string.login_btn));
        oauthTool = OauthTool.get(this);
        initData();
        initView();
        setToolbarDividerEnable(true);
        mRxFlux= getApp().getRxFlux();
        mDataManager=getApp().getDataManager();
        mUserActionCreator = getApp().getUserActionCreator();
        mLoginActionCreator = new LoginActionCreator(this, mDataManager, mRxFlux.getDispatcher(),
                mRxFlux.getSubscriptionManager());
    }
    @Override
    protected View createToolbarView(LayoutInflater inflater, ViewGroup container) {
        View view = super.createToolbarView(inflater, container);
        mLeftBack = (TextView) view.findViewById(R.id.toolbar_left_btn);
        mRightBtn = (TextView) view.findViewById(R.id.toolbar_right_btn);
        mRightBtn.setCompoundDrawablesWithIntrinsicBounds(0,0,0,0);
        mLeftBack.setCompoundDrawablesWithIntrinsicBounds(R.drawable.back_icon, 0, 0, 0);
        return view;
    }
    private void initView() {
        rePassword = (CheckBox) findViewById(R.id.cb_Remember_password);
        rePassword.setChecked(remberPasseord);
        etPassword.setCompoundDrawablesWithIntrinsicBounds(
                getResources().getDrawable(R.drawable.password_normal),
                null, null, null);
        rePassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                remberPasseord=true;
            }
        });
    }
    private void initData(){
        String account = mLoginStore.getloginId();
        HaierLoger.a("account", account);
        if(account!=null){
            etAccount.setText(account);
        }
        String pwd = mLoginStore.getPassword();
        HaierLoger.a("account5",pwd);
        if(pwd!=null){
            etPassword.setText(pwd);
        }
        remberPasseord = mLoginStore.getSavestatus();
    }
    private void initPw(){
        etPassword.setCompoundDrawablesWithIntrinsicBounds(
                getResources().getDrawable(R.drawable.password_normal),
                null, getResources().getDrawable(R.drawable.login_delete), null);
    }
    @OnClick(R.id.login_seepw)
    public void seePassword(){
        if(noPw){
            loginSeepw.setImageResource(R.drawable.password_see);
            // 显示为普通文本
            etPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            noPw=false;
            initPw();
        }else{
            //显示为密码
            etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            loginSeepw.setImageResource(R.drawable.password_nosee);
            noPw=true;
            initPw();
        }
    }

    @OnClick(R.id.reset_password)
    public void  resetPassword(){
        Intent intent = new Intent(LoginActivity.this, WebActivity.class);
        intent.putExtra("url","m.haier.com/ids/mobile/find-pwd-loginName.jsp");
        intent.putExtra("title",getString(R.string.password_text));
        startActivity(intent);
    }

    @OnClick(R.id.btn_login)
    protected void onLogin() {
        String account = etAccount.getText().toString();
        String password = etPassword.getText().toString();
        showProgressDialog(getString(R.string.showProgressDialog));
        mLoginActionCreator.login(account, password);
    }

    @OnClick(R.id.login_btn_register)
    public void onRegister(){
        startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
    }

    @OnClick(R.id.wx_login)
    public void onThirdwxlogin(){
        Log.i("wx","weixin login");
        oauthTool.doOauthVerify(this, OauthPlatform.WEIXIN, new OauthListener() {
            @Override
            public void onComplete(@OauthPlatform.Type int platform, Map<String, String> data) {

                showProgressDialog(getString(R.string.showProgressDialog));
                if (data == null) {
                    return;
                }
                String sdata1 = data.toString();
                wxOpenId = data.get("unionid").toString();
                wxAccessToken = data.get("accesstoken").toString();
                HaierLoger.a("unionid",qqOpenId+"..."+qqAccessToken);
                HaierLoger.a("sdata1",sdata1);
                mLoginActionCreator.login(wxOpenId, AccType.WEI_XIN, WXAPPID, wxAccessToken);
            }

            @Override
            public void onError(@OauthPlatform.Type int platform, Throwable err) {
                Log.i("wx error","error");
            }

            @Override
            public void onCancel(@OauthPlatform.Type int platform) {
                Log.i("wx cancel","cancel");
            }
        });
    }

    @OnClick(R.id.qq_login)
    public void onThirdqqlogin(){
        oauthTool.doOauthVerify(this, OauthPlatform.QQ, new OauthListener() {
            @Override
            public void onComplete(@OauthPlatform.Type int platform, Map<String, String> data) {
                showProgressDialog(getString(R.string.showProgressDialog));
                if (data == null) {
                    return;
                }
                HaierLoger.a("QQqq",data.toString());
                String sdata = data.toString();
                qqOpenId = data.get("openid").toString();
                qqAccessToken = data.get("access_token").toString();
                HaierLoger.a("openid",qqOpenId+"..."+qqAccessToken);
                HaierLoger.a("sdata",sdata);
                mLoginActionCreator.login(qqOpenId, AccType.QQ, QQAPPID, qqAccessToken);
            }

            @Override
            public void onError(@OauthPlatform.Type int platform, Throwable err) {
            }

            @Override
            public void onCancel(@OauthPlatform.Type int platform) {
                Toast.makeText(LoginActivity.this,"未安装QQ",Toast.LENGTH_LONG).show();
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        OauthTool.get(this).onActivityResult(requestCode, resultCode, data);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
//        if(LoginActions.ID_3RD_PARTY_LOGIN.equals(type)) {
        OauthTool.destroy();
//        }
    }

    @Override
    public void onRxStoresRegister() {
        mUserStore = UserStore.get(this);
        mUserStore.register();
        mLoginStore =LoginStore.get(this);
        mLoginStore.register();
    }

    @Override
    public void onRxStoresUnRegister() {
        mUserStore.unregister();
        mLoginStore.unregister();
    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {
        stopProgressDialog();
        switch (change.getStoreId()) {
            case BaseStore.ID_SHOW_LOADING:
                showProgressDialog(getString(R.string.showProgressDialog));
                break;
            case BaseStore.ID_STOP_LOADING:
                break;
            case LoginStore.ID:
                HaierLoger.a("aaaa","aaaa");
                break;
            case UserStore.ID:
                type = change.getRxAction().getType();
                switch (change.getRxAction().getType()) {
                    case LoginActions.ID_LOGIN:
                        if (mUserStore.isLoginSuccess()) {
                            showToast(R.string.login_success);
                            String password = etPassword.getText().toString();
                            mLoginActionCreator.savePassword(remberPasseord,password);
                            //startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                            setResult(RESULT_OK);
                            finish();
                        }
//                        else {
//                            showToast(R.string.login_failed);
//                        }
                        break;
                    case LoginActions.ID_3RD_PARTY_LOGIN:
                        if (mUserStore.isLoginSuccess()) {
//                            if (mUserStore.isActivated()) {
                            showToast(R.string.login_success);
                            //startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                            setResult(RESULT_OK);
                            finish();
//                            } else {
//                                showToast(R.string.user_not_activated);
//                            }
                        }
//                        else {
//                            showToast(R.string.login_failed);
//                        }
                        break;

                    default:
                        break;
                }

            default:
                break;
        }
    }

    @Override
    public void onRxError(RxError error) {
        stopProgressDialog();
        showToast(ErrorHandler.handelError(error.getThrowable(), this));
    }

}
