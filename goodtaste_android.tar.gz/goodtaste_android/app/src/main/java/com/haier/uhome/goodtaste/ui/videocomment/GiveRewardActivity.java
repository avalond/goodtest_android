package com.haier.uhome.goodtaste.ui.videocomment;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.gmail.adffice.rxflux.RxFlux;
import com.gmail.adffice.rxflux.action.RxError;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.actions.GiveRewardActions;
import com.haier.uhome.goodtaste.actions.GiveRewardActionsCreator;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.models.RewardInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.UserScore;
import com.haier.uhome.goodtaste.data.models.VideoInfo;
import com.haier.uhome.goodtaste.data.source.remote.services.H5HybirdUrl;
import com.haier.uhome.goodtaste.stores.GiveRewardStore;
import com.haier.uhome.goodtaste.stores.UserStore;
import com.haier.uhome.goodtaste.ui.BaseActivity;
import com.haier.uhome.goodtaste.utils.ErrorHandler;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.utils.ImageDownLoader;
import com.haier.uhome.goodtaste.widgets.DialogHelper;

import butterknife.Bind;

/**
 * Created by Administrator on 2016/5/15.
 */
public class GiveRewardActivity extends BaseActivity implements View.OnClickListener {

    @Bind(R.id.et_custom_integral)
    EditText etCustomIntegral;
    @Bind(R.id.tv_all_integral)
    TextView tvAllIntegral;
    @Bind(R.id.iv_clear)
    ImageView ivClear;
    @Bind(R.id.btn_ok)
    Button btnOk;
    @Bind(R.id.btn_ten_integral)
    Button btnTenIntegral;
    @Bind(R.id.btn_thirty_integral)
    Button btnThirtyIntegral;
    @Bind(R.id.btn_fifty_integral)
    Button btnFiftyIntegral;
    @Bind(R.id.btn_hundred_integral)
    Button btnHundredIntegral;
    @Bind(R.id.iv_reward_icon)
    ImageView ivRewardIcon;
    @Bind(R.id.tv_reward_name)
    TextView tvRewardName;


    private Dialog rewarddialog;
    private Button btnObtainIntegral;
    private Button btnAbandon;
    private static final int DIALOG_HIGHT = 145;
    private static final int DIALOG_WIDTH = 0;
    private static final String TEN_INTEGRAL = String.valueOf(10);
    private static final String THIRTY_INTEGRAL = String.valueOf(30);
    private static final String FIFTY_INTEGRAL = String.valueOf(50);
    private static final String HUNDRED_INTEGRAL = String.valueOf(100);
    private VideoInfo mUserInfoReward;
    private TextView tvText;
    private TextView tvBtnObtain;
    private GiveRewardActionsCreator rewardActionsCreator;
    private String userId;
    private GiveRewardStore mGiveRewardStore;
    private UserStore userStore;
    private String point;
    private String videoUserId;
    private String nickName;
    private String avater;
    private String message;
    private RewardInfo rewardUserDate;
    private String rewardScore;
    private String score;
    public final static String MSG_KEY = "VideoComment";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_givareward);
        RxFlux rxFlux = getApp().getRxFlux();
        DataManager dataManager = getApp().getDataManager();
        rewardActionsCreator = new GiveRewardActionsCreator(this, dataManager, rxFlux.getDispatcher(),
                rxFlux.getSubscriptionManager());
        showProgressDialog(getResources().getString(R.string.load_footer_loading));
        initDate();
        stopProgressDialog();
    }

    private void initDate() {
        setToolbarTitle(getResources().getString(R.string.chose_money));
        btnOk.setOnClickListener(this);
        ivClear.setOnClickListener(this);
        btnTenIntegral.setOnClickListener(this);
        btnThirtyIntegral.setOnClickListener(this);
        btnFiftyIntegral.setOnClickListener(this);
        btnHundredIntegral.setOnClickListener(this);
        //获取传递过来的数据
        Intent i = getIntent();
        mUserInfoReward = (VideoInfo) i.getSerializableExtra(MSG_KEY);
        //解析视频数据
        videoUserId = mUserInfoReward.getUserInfo().getUserId();
        //当前用户信息
        nickName = mUserInfoReward.getUserInfo().getNickName();
        avater = mUserInfoReward.getUserInfo().getAvater();
        userId = userStore.getUserId();
        //赋值操作
        tvRewardName.setText(this.nickName);
        ImageDownLoader.get(this).display(this.avater, ivRewardIcon);
        rewardActionsCreator.findUserPoint(userId);
    }

    @Override
    protected View createToolbarView(LayoutInflater inflater, ViewGroup container) {
        View view = super.createToolbarView(inflater, container);
        TextView mLeftBack = (TextView) view.findViewById(R.id.toolbar_left_btn);
        TextView mRightBtn = (TextView) view.findViewById(R.id.toolbar_right_btn);
        mLeftBack.setCompoundDrawablesWithIntrinsicBounds(R.drawable.back_icon, 0, 0, 0);
        mRightBtn.setVisibility(View.INVISIBLE);
        return view;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.btn_ok:
                message = etCustomIntegral.getText().toString().trim();
                rewardActionsCreator.rewardUser(userId, videoUserId, message);
                if (TextUtils.isEmpty(message)) {
                    showToast(getResources().getString(R.string.give_reward));
                    return;
                }
                String allInTegral = tvAllIntegral.getText().toString().trim();
                String customIntegral = etCustomIntegral.getText().toString().trim();
                int allInTegralInt = Integer.valueOf(allInTegral).intValue();
                int customIntegralInt = Integer.valueOf(customIntegral).intValue();
                if (customIntegralInt > allInTegralInt) {
                    showDialog();
                }
                break;
            case R.id.btn_obtain_integral:
                DialogHelper dialogHelper = new DialogHelper(this);
                String url = H5HybirdUrl.instance().getInviteShareH5Url();
                UserInfo userInfo = UserStore.get(this).getUserInfo();
                String code = "";
                if(userInfo != null){
                    code = userInfo.getInviteCode();
                }

                dialogHelper.showInviteFriendShare(code, url);
                break;
            case R.id.iv_clear:
                etCustomIntegral.setText("");
                break;
            case R.id.btn_ten_integral:
                etCustomIntegral.setText(TEN_INTEGRAL);
                break;
            case R.id.btn_thirty_integral:
                etCustomIntegral.setText(THIRTY_INTEGRAL);
                break;
            case R.id.btn_fifty_integral:
                etCustomIntegral.setText(FIFTY_INTEGRAL);
                break;
            case R.id.btn_hundred_integral:
                etCustomIntegral.setText(HUNDRED_INTEGRAL);
                break;
            default:
                break;
        }
    }


    @Override
    public void onRxStoresRegister() {
        userStore = UserStore.get(this);
        userStore.register();
        mGiveRewardStore = new GiveRewardStore(getApp().getRxFlux().getDispatcher());
        mGiveRewardStore.register();
    }

    @Override
    public void onRxStoresUnRegister() {
        mGiveRewardStore.unregister();
        userStore.unregister();
    }

    @Override
    public void onRxStoreChanged(RxStoreChange change) {
        switch (change.getStoreId()) {
            case GiveRewardStore.ID:
                switch (change.getRxAction().getType()) {
                    case GiveRewardActions.ID_FIND_POINT:
                        UserScore findPointData = (UserScore) change.getRxAction().getData();
                        point = findPointData.getPoint();
                        int pointInt = Integer.valueOf(point).intValue();
                        if (pointInt < 0) {
                            tvAllIntegral.setText(0);
                        }
                        tvAllIntegral.setText(point);
                        break;
                    case GiveRewardActions.ID_RAWARD_USER:
                        rewardUserDate = (RewardInfo) change.getRxAction().getData();
                        //打赏积分
                        rewardScore = rewardUserDate.getRewardScore();
                        //剩余积分
                        score = rewardUserDate.getScore();
                        showDialogok();
                        rewardActionsCreator.findUserPoint(userId);
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }

    }

    @Override
    public void onRxError(RxError error) {
        showToast(ErrorHandler.handelError(error.getThrowable(), this));
    }

    private void showDialog() {
        rewarddialog = new Dialog(this, R.style.dialog_video);
        View view = View.inflate(this, R.layout.layout_reward_dialog, null);
        rewarddialog.setContentView(view); //设置dialog的布局
        Window dialogWindow = rewarddialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        dialogWindow.setGravity(Gravity.CENTER);

        lp.y = DIALOG_HIGHT;
        lp.x = DIALOG_WIDTH;
        dialogWindow.setAttributes(lp);
        rewarddialog.setCanceledOnTouchOutside(false);
        rewarddialog.show();//显示dialog界面
        btnObtainIntegral = (Button) view.findViewById(R.id.btn_obtain_integral);
        btnAbandon = (Button) view.findViewById(R.id.btn_abandon);
        btnObtainIntegral.setOnClickListener(this);
        btnAbandon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rewarddialog.dismiss();
            }
        });
    }

    private void showDialogok() {
        rewarddialog = new Dialog(this, R.style.dialog_video);
        View view = View.inflate(this, R.layout.layout_ok_reward_dialog, null);
        rewarddialog.setContentView(view); //设置dialog的布局
        Window dialogWindow = rewarddialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        dialogWindow.setGravity(Gravity.CENTER);

        lp.y = DIALOG_HIGHT;
        lp.x = DIALOG_WIDTH;
        dialogWindow.setAttributes(lp);
        rewarddialog.setCanceledOnTouchOutside(false);
        rewarddialog.show();//显示dialog界面

        tvBtnObtain = (TextView) view.findViewById(R.id.btn_obtain);
        tvBtnObtain.setText(getResources().getString(R.string.btn_obtain) + score);
        tvText = (TextView) view.findViewById(R.id.tv_text);
        tvText.setText(getResources().getString(R.string.tv_text) + "" + rewardScore + getResources().
                getString(R.string.integration));

        btnAbandon = (Button) view.findViewById(R.id.btn_abandon);
        btnAbandon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rewarddialog.dismiss();
            }
        });
    }

}
