package com.haier.uhome.goodtaste.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.haier.uhome.goodtaste.R;

/**
 * Created by Administrator on 2016/5/6.
 */
public class MessageListView extends ListView implements OnScrollListener {


    //private LinearLayout header_root;
    //private LinearLayout header_view;
    private ImageView imageView;
    private TextView text;
    private TextView time;
    private View customView;
    private int headerViewHeight;
    private RotateAnimation up;
    private RotateAnimation down;
    private int downY = -1;
    private View headerView;

    private static final int PULL_DOWN = 1;
    private static final int RELEASE_REFRESH = 2;
    private static final int ISREFRESHING = 3;
    private static int currentstate = PULL_DOWN;

    /*private Handler handler = new Handler(){
        public void handleMessage(android.os.Message msg) {
            //结束刷新
            finish();
        }
    };*/
    private View mFooterView;
    private int mFooterViewHeight;
    private boolean isLoadMore;
    private OnRefreshListenter refreshListenter;
    private ProgressBar progressbar;

    /**
     * 结束刷新
     */
    public void finish() {

        //判断是结束下拉刷新还是结束加载更多
        if (currentstate == ISREFRESHING) {
            text.setText("下拉即可刷新");
            progressbar.setVisibility(View.GONE);
            imageView.setVisibility(View.VISIBLE);
            currentstate = PULL_DOWN;
            headerView.setPadding(0, -headerViewHeight, 0, 0);
        }

    }

    public void showSuccess(){
        text.setText("刷新完成");
        progressbar.setVisibility(View.GONE);
        imageView.setImageResource(R.drawable.ic_success);
        imageView.setVisibility(View.VISIBLE);
        //currentstate = PULL_DOWN;
        headerView.setPadding(0, headerViewHeight, 0, 0);
    }

    public MessageListView(Context context) {
        // super(context);
        this(context, null);
    }

    public MessageListView(Context context, AttributeSet attrs) {
        // super(context, attrs);
        this(context, attrs, 0);
    }

    public MessageListView(Context context, AttributeSet attrs,
                           int defStyle) {
        super(context, attrs, defStyle);
        // 添加刷新头
        setHeader();
        //设置滑动监听
        setOnScrollListener(this);
    }

    /**
     * 添加刷新头
     */
    private void setHeader() {
        headerView = View.inflate(getContext(), R.layout.listview_header_loader, null);
        /*header_root = (LinearLayout) headerView
                .findViewById(R.id.refresh_header_root);*/
        /*header_view = (LinearLayout) headerView
                .findViewById(R.id.ll);*/
        /*headerView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });*/
        imageView = (ImageView) headerView.findViewById(R.id.iv_pull_loading);
        progressbar = (ProgressBar) headerView.findViewById(R.id.iv_loading);
        text = (TextView) headerView.findViewById(R.id.tv_header_tips);
        time = (TextView) headerView.findViewById(R.id.time);
        // 设置隐藏刷新头
        headerView.measure(0, 0);
        headerViewHeight = headerView.getMeasuredHeight();
        headerView.setPadding(0, -headerViewHeight, 0, 0);
        // 添加刷新头
        addHeaderView(headerView);
        // 初始化动画
        setAnimation();
    }

    /**
     * 初始化动画
     */
    private void setAnimation() {
        up = new RotateAnimation(0, -180, Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f);
        up.setDuration(300);
        up.setFillAfter(true);// 设置动画结束保持结束的状态

        down = new RotateAnimation(-180, -360, Animation.RELATIVE_TO_SELF,
                0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        down.setDuration(300);
        down.setFillAfter(true);// 设置动画结束保持结束的状态

    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:

                downY = (int) ev.getY();
                break;
            case MotionEvent.ACTION_MOVE:
                if (downY == -1) {
                    downY = (int) ev.getY();
                }

                //如果是正在刷新，不能再次将listview拉动
                if (currentstate == ISREFRESHING) {
                    return true;
                }

                int moveY = (int) ev.getY();

                if (moveY - downY > 0 && getFirstVisiblePosition() == 0) {
                    // 下拉刷新操作
                    int padding = moveY - downY - headerViewHeight;
                    // 刷新头移动相应的位置
                    headerView.setPadding(0, padding, 0, 0);
                    // 下拉刷新 -> 释放刷新
                    if (padding > 0 && currentstate == PULL_DOWN) {
                        currentstate = RELEASE_REFRESH;
                        swtichOption();
                    }
                    // 释放刷新 -> 下拉刷新
                    if (padding < 0 && currentstate == RELEASE_REFRESH) {
                        currentstate = PULL_DOWN;
                        swtichOption();
                    }
                    return true;
                }

                break;
            case MotionEvent.ACTION_UP:
                //downY = -1;
                // 释放刷新 -> 正在刷新
                if (currentstate == RELEASE_REFRESH) {
                    currentstate = ISREFRESHING;
                    headerView.setPadding(0, 0, 0, 0);
                    swtichOption();
                    //handler.sendEmptyMessageDelayed(0, 1000);
                    if (refreshListenter != null) {
                        refreshListenter.refresh();
                    }
                }
                // 下拉刷新 -> 弹回
                if (currentstate == PULL_DOWN) {
                    headerView.setPadding(0, -headerViewHeight, 0, 0);
                }
                break;
            default:
                break;
        }
        return super.onTouchEvent(ev);
    }

    /**
     * 根据状态，更改UI效果
     */
    public void swtichOption() {
        switch (currentstate) {
            case PULL_DOWN:
                text.setText("下拉即可刷新");
                imageView.startAnimation(down);
                break;
            case RELEASE_REFRESH:
                text.setText("释放刷新");
                imageView.startAnimation(up);
                break;
            case ISREFRESHING:
                text.setText("正在刷新");
                imageView.clearAnimation();
                imageView.setVisibility(View.GONE);
                progressbar.setVisibility(View.VISIBLE);

                break;
            default:
                break;
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem,
                         int visibleItemCount, int totalItemCount) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {

    }

    /**
     * 获取监听器
     * @author Administrator
     *
     */
    public void setOnRefreshListener(OnRefreshListenter refreshListenter){
        this.refreshListenter = refreshListenter;
    }


    public interface OnRefreshListenter{
        /**
         * 下拉刷新
         */
        void refresh();

    }

}


