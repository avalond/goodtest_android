package com.haier.uhome.goodtaste.widgets.swipmenu;


import com.haier.uhome.goodtaste.widgets.swipmenu.SwipeMenu;

public interface SwipeMenuCreator {

    void create(SwipeMenu menu);
}
