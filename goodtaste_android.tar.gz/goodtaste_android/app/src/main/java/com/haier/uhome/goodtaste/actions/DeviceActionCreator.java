package com.haier.uhome.goodtaste.actions;

import android.content.Context;

import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.util.SubscriptionManager;
import com.haier.uhome.goodtaste.data.DataManager;

/**
 * Created by dallas on 16-4-19.
 */
public class DeviceActionCreator extends BaseActionCreator implements DeviceActions {

    public DeviceActionCreator(Context context, DataManager dataManager, Dispatcher dispatcher,
        SubscriptionManager subscriptionManager) {
        super(context, dataManager, dispatcher, subscriptionManager);
    }
}
