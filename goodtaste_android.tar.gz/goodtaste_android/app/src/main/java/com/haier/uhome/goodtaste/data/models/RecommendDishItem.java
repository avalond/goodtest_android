package com.haier.uhome.goodtaste.data.models;

/**
 * Created by sharp on 16-5-5.
 */
public class RecommendDishItem extends Item {

    private String mUserId;
//    private String mUserName;
//    private String mUserPicURL;
//    private String mDishId;
//    private String mDishName;
//    private String mDishPicURL;
//    private String mLevel; //难度级别
//    private String mDuring; //用时
//    private String mCuisine;//口味
    private RecommendDishItemType mRecommendDishItemType = RecommendDishItemType.DISH_TYPE;


    public enum RecommendDishItemType {
        HEAD_TYPE,
        RANK_TYPE,
        DISH_TYPE,
    }

    public String getmUserId() {
        return mUserId;
    }

    public void setmUserId(String mUserId) {
        this.mUserId = mUserId;
    }

    public RecommendDishItemType getmRecommendDishItemType() {
        return mRecommendDishItemType;
    }

    public void setmRecommendDishItemType(RecommendDishItemType mRecommendDishItemType) {
        this.mRecommendDishItemType = mRecommendDishItemType;
    }
}
