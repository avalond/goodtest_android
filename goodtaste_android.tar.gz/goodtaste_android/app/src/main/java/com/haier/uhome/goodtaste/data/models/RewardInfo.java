package com.haier.uhome.goodtaste.data.models;

import java.io.Serializable;

/**
 * Created by dallas on 16-5-21.
 */
public class RewardInfo implements Serializable {
    private static final long serialVersionUID = -3780850277123696742L;

    /**
     * 打赏积分
     */
    private String rewardScore;
    /**
     * 当前积分
     */
    private String score;

    public String getRewardScore() {
        return rewardScore;
    }

    public void setRewardScore(String rewardScore) {
        this.rewardScore = rewardScore;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }
}
