package com.haier.uhome.goodtaste.ui.main.adapter;

import android.app.Activity;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.haier.uhome.goodtaste.R;
import com.haier.uhome.goodtaste.data.models.TopVideoInfo;
import com.haier.uhome.goodtaste.ui.main.HandleHomeHeaderInterface;
import com.haier.uhome.goodtaste.utils.HaierLoger;
import com.haier.uhome.goodtaste.utils.ImageDownLoader;

import java.util.LinkedList;
import java.util.List;

/**
 * 今日厨咖ViewPager
 * Created by sharp on 16-5-6.
 */
public class CookerPagerAdapter extends PagerAdapter {

    private static final String TAG = "CookerPagerAdapter";
    private List<TopVideoInfo> mTopVideoInfoList;
    private Activity mActivity;
    private LayoutInflater mLayoutInflater;
    private LinkedList<View> mViewCache = new LinkedList<>();
    //    private HandleHomeCityWeatherInterface mHandleHomeCityWeatherInterface;
    private HandleHomeHeaderInterface mHeaderInterface;


    public CookerPagerAdapter(Activity activity, List<TopVideoInfo> topVideoInfoList,
        HandleHomeHeaderInterface headerInterface) {
        //        if (topVideoInfoList == null) {
        //            mTopVideoInfoList = new ArrayList<>();
        //        } else {
        //            mTopVideoInfoList = topVideoInfoList;
        //        }
        mTopVideoInfoList = topVideoInfoList;
        mActivity = activity;
        mLayoutInflater = LayoutInflater.from(mActivity);
        mHeaderInterface = headerInterface;
    }


    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

    @Nullable
    public String getCurrentCityBGURL(int position) {
        TopVideoInfo topVideoInfo = mTopVideoInfoList.get(position);
        if (topVideoInfo != null) {
            return topVideoInfo.getData().getThumbnail();
        }
        return null;
    }

    @Override
    public int getCount() {
        if (mTopVideoInfoList != null) {
            return mTopVideoInfoList.size();
        }
        return 0;
    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        HeaderHolder headerHolder = null;
        View convertView = null;
        if (mViewCache.size() == 0) {
            convertView = mLayoutInflater.inflate(R.layout.layout_header_pager_fragment_first_main, null, false);
            headerHolder = new HeaderHolder(convertView);
            convertView.setTag(headerHolder);
        } else {
            convertView = mViewCache.removeFirst();
            headerHolder = (HeaderHolder) convertView.getTag();
        }

        TopVideoInfo topVideoInfo = null;
        if (mTopVideoInfoList != null && mTopVideoInfoList.size() > 0) {
            topVideoInfo = mTopVideoInfoList.get(position);
        }
        String userId = "";
        String videoUrl = "";//
        String videoBgViewUrl = "";
        String videoName = "";
        String userPicUrl = "";

        if (topVideoInfo != null) {
            videoUrl = topVideoInfo.getData().getVideoUrl();
            videoBgViewUrl = topVideoInfo.getData().getThumbnail();
            videoName = topVideoInfo.getData().getAlbumName();
        }

        String videoBgViewUrlCache = (String)headerHolder.videoBgView.getTag(R.string.top_vedio_url_tag);
        if (!videoBgViewUrl.equals(videoBgViewUrlCache)){
            headerHolder.videoBgView.setTag(R.string.top_vedio_url_tag,videoBgViewUrl);
            ImageDownLoader.get(mActivity).display(videoBgViewUrl, headerHolder.videoBgView);
        }

        if (!TextUtils.isEmpty(videoName)) {
            headerHolder.videoNameText.setText(videoName);
        }else{
            headerHolder.videoNameText.setText("");
        }

        headerHolder.playBtnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mHeaderInterface.onVideoMainPage( mTopVideoInfoList.get(position).getData());
            }
        });
        container.addView(convertView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        return convertView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        View contentView = (View) object;
        container.removeView(contentView);
        mViewCache.add(contentView);
    }


    @Override
    public boolean isViewFromObject(View arg0, Object arg1) {
        return arg0 == arg1;
    }


    public void updateViewList(List<TopVideoInfo> list) {
        mTopVideoInfoList = list;
        HaierLoger.d(TAG, "list.size()" + list.size());
        notifyDataSetChanged();
    }

    static class HeaderHolder {
        TextView videoNameText;
        ImageView playBtnView;
        ImageView videoBgView;

        public HeaderHolder(View convertView) {

            playBtnView = (ImageView) convertView.findViewById(R.id.iv_play_btn);
            videoBgView = (ImageView) convertView.findViewById(R.id.iv_today_video_play_bg);
            videoNameText = (TextView) convertView.findViewById(R.id.tv_today_video_name);
        }
    }
}
