package com.haier.uhome.goodtaste.utils.rxPreference;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action0;
import rx.functions.Func0;
import rx.functions.Func1;
import rx.schedulers.Schedulers;
import rx.subscriptions.Subscriptions;

/**
 * <br>Created by Dallas.
 */
public class RxPreference {
    private static final String KEY_IS_NULL = "key == null";
    private static final String CLASS_OF_T_IS_NULL = "classOfT == null";
    private static final String TYPE_TOKEN_OF_T_IS_NULL = "typeTokenOfT == null";
    private static final String VALUE_IS_NULL = "value == null";

    private final SharedPreferences preferences;
    private final SharedPreferences.Editor editor;
    private final Map<Class<?>, Accessor<?>> accessors = new HashMap<>();
    private JsonConverter jsonConverter;

    public RxPreference(@NonNull Context context) {
        this(context, new GsonConverter());
    }

    public RxPreference(@NonNull SharedPreferences preferences) {
        this(preferences, new GsonConverter());
    }

    public RxPreference(@NonNull Context context, @NonNull JsonConverter jsonConverter) {
        this(PreferenceManager.getDefaultSharedPreferences(context), jsonConverter);
    }

    public RxPreference(@NonNull SharedPreferences preferences, @NonNull JsonConverter jsonConverter) {
        this.preferences = checkNotNull(preferences, "preferences is null");
        this.jsonConverter = checkNotNull(jsonConverter, "jsonConverter is null");
        this.editor = preferences.edit();
        initAccessor();
    }

    public SharedPreferences getPreferences() {
        return preferences;
    }

    public boolean contains(String key) {
        return preferences.contains(key);
    }

    public String getString(String key, String defaultValue) {
        return get(key, String.class, defaultValue);
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        return get(key, Boolean.class, defaultValue);
    }

    public int getInt(String key, int defaultValue) {
        return get(key, Integer.class, defaultValue);
    }

    public float getFloat(String key, float defaultValue) {
        return get(key, Float.class, defaultValue);
    }

    public long getLong(String key, long defaultValue) {
        return get(key, Long.class, defaultValue);
    }

    public <T> T get(String key, Class<T> classOfT, T defaultValue) {
        checkNotNull(key, KEY_IS_NULL);
        checkNotNull(classOfT, CLASS_OF_T_IS_NULL);

        if (!contains(key) && defaultValue == null) {
            return null;
        }

        return get(key, TypeToken.fromClass(classOfT), defaultValue);
    }

    public <T> T get(@NonNull String key, @NonNull TypeToken<T> typeTokenOfT, T defaultValue) {
        checkNotNull(key, KEY_IS_NULL);
        checkNotNull(typeTokenOfT, TYPE_TOKEN_OF_T_IS_NULL);

        Type typeOfT = typeTokenOfT.getType();
        for (Map.Entry<Class<?>, Accessor<?>> entry : accessors.entrySet()) {
            if (typeOfT.equals(entry.getKey())) {
                @SuppressWarnings("unchecked") Accessor<T> accessor = (Accessor<T>) entry.getValue();
                return accessor.get(key, defaultValue);
            }
        }

        if (contains(key)) {
            return jsonConverter.fromJson(preferences.getString(key, null), typeOfT);
        } else {
            return defaultValue;
        }
    }

    public <T> void put(@NonNull String key, @NonNull T value) {
        checkNotNull(value, VALUE_IS_NULL);

        put(key, value, TypeToken.fromValue(value));
    }

    public <T> void put(@NonNull final String key, @NonNull final T value, @NonNull TypeToken typeTokenOfT) {
        checkNotNull(key, KEY_IS_NULL);
        checkNotNull(value, VALUE_IS_NULL);
        checkNotNull(typeTokenOfT, TYPE_TOKEN_OF_T_IS_NULL);

        Class<?> classOfValue = value.getClass();

        // 不是基本类型
        if (!accessors.containsKey(classOfValue)) {
            String json = jsonConverter.toJson(value, typeTokenOfT.getType());
            editor.putString(key, json).apply();
            return;
        }

        @SuppressWarnings("unchecked") Accessor<T> accessor = (Accessor<T>) accessors.get(classOfValue);
        accessor.put(key, value);
    }

    public void remove(@NonNull String key) {
        checkNotNull(key, KEY_IS_NULL);
        if (!contains(key)) {
            return;
        }

        editor.remove(key).apply();
    }

    public void clear() {
        if (size() == 0) {
            return;
        }

        editor.clear().apply();
    }

    public int size() {
        return preferences.getAll().size();
    }

    /**
     * 返回RxJava Observable，用于订阅SharedPreferences数据发生变化。和{@link #observe}不同的是，
     * 该方法在被订阅后会先返回一次SharedPreferences中<code>key<code/>对应的Value。如果没有对应值则返回<code>defaultValue<code/>。
     */
    public <T> Observable<T> getAndObserve(@NonNull final String key, @NonNull final Class<T> classOfT,
        @NonNull final T defaultValue) {
        return getAndObserve(key, TypeToken.fromClass(classOfT), defaultValue);
    }

    /**
     * 返回RxJava Observable，用于订阅SharedPreferences数据发生变化。和{@link #observe}不同的是，
     * 该方法在被订阅后会先返回一次SharedPreferences中<code>key<code/>对应的Value。如果没有对应值则返回<code>defaultValue<code/>。
     */
    public <T> Observable<T> getAndObserve(@NonNull final String key, @NonNull final TypeToken<T> typeTokenOfT,
        @NonNull final T defaultValue) {
        return observe(key, typeTokenOfT, defaultValue).mergeWith(Observable.defer(new Func0<Observable<T>>() {
            @Override
            public Observable<T> call() {
                return Observable.just(get(key, typeTokenOfT, defaultValue));
            }
        }));
    }

    /**
     * 返回RxJava Observable，用于订阅SharedPreferences数据发生变化。如果数据发生变化，订阅者将会收到
     * 变化的值。如果SharedPreferences中没有<code>key<code/>，则返回<code>defaultValue<code/>。
     */
    public <T> Observable<T> observe(@NonNull final String key, @NonNull final Class<T> classOfT,
        @NonNull final T defaultValue) {
        checkNotNull(key, KEY_IS_NULL);
        checkNotNull(classOfT, CLASS_OF_T_IS_NULL);

        return observe(key, TypeToken.fromClass(classOfT), defaultValue);
    }

    /**
     * 返回RxJava Observable，用于订阅SharedPreferences数据发生变化。如果数据发生变化，订阅者将会收到
     * 变化的值。如果SharedPreferences中没有<code>key<code/>，则返回<code>defaultValue<code/>
     */
    public <T> Observable<T> observe(@NonNull final String key, @NonNull final TypeToken<T> typeTokenOfT,
        @NonNull final T defaultValue) {
        checkNotNull(key, KEY_IS_NULL);
        checkNotNull(typeTokenOfT, TYPE_TOKEN_OF_T_IS_NULL);

        return observePreferences().filter(new Func1<String, Boolean>() {
            @Override
            public Boolean call(String s) {
                return key.equals(s);
            }
        }).map(new Func1<String, T>() {
            @Override
            public T call(String s) {
                return get(key, typeTokenOfT, defaultValue);
            }
        });
    }


    /**
     * @return 返回RxJava Observable，用于订阅SharedPreferences数据发生变化。
     */
    public Observable<String> observePreferences() {
        return Observable.create(new Observable.OnSubscribe<String>() {
            // NOTE: Without this OnChangeListener will be GCed.
            Collection<OnChangeListener> listenerReferences = Collections.synchronizedList(
                new ArrayList<OnChangeListener>());

            @Override
            public void call(final Subscriber<? super String> subscriber) {
                final OnChangeListener onChangeListener = new OnChangeListener(subscriber);
                preferences.registerOnSharedPreferenceChangeListener(onChangeListener);
                listenerReferences.add(onChangeListener);
                subscriber.add(Subscriptions.create(new Action0() {
                    @Override
                    public void call() {
                        preferences.unregisterOnSharedPreferenceChangeListener(onChangeListener);
                        listenerReferences.remove(onChangeListener);
                    }
                }));
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
    }


    private void initAccessor() {
        accessors.put(Boolean.class, new Accessor<Boolean>() {
            @Override
            public Boolean get(String key, Boolean defaultValue) {
                return preferences.getBoolean(key, defaultValue);
            }

            @Override
            public void put(String key, Boolean value) {
                editor.putBoolean(key, value).apply();
            }
        });
        accessors.put(Float.class, new Accessor<Float>() {
            @Override
            public Float get(String key, Float defaultValue) {
                return preferences.getFloat(key, defaultValue);
            }

            @Override
            public void put(String key, Float value) {
                editor.putFloat(key, value).apply();
            }
        });
        accessors.put(String.class, new Accessor<String>() {
            @Override
            public String get(String key, String defaultValue) {
                return preferences.getString(key, defaultValue);
            }

            @Override
            public void put(String key, String value) {
                editor.putString(key, value).apply();
            }
        });
        accessors.put(Integer.class, new Accessor<Integer>() {
            @Override
            public Integer get(String key, Integer defaultValue) {
                return preferences.getInt(key, defaultValue);
            }

            @Override
            public void put(String key, Integer value) {
                editor.putInt(key, value).apply();
            }
        });
        accessors.put(Long.class, new Accessor<Long>() {
            @Override
            public Long get(String key, Long defaultValue) {
                return preferences.getLong(key, defaultValue);
            }

            @Override
            public void put(String key, Long value) {
                editor.putLong(key, value).apply();
            }
        });
    }

    private <T> T checkNotNull(T object, String message) {
        if (object == null) {
            throw new NullPointerException(message);
        }
        return object;
    }

    private interface Accessor<T> {
        T get(String key, T defaultValue);

        void put(String key, T value);
    }

    private static class OnChangeListener implements SharedPreferences.OnSharedPreferenceChangeListener {
        private final Subscriber<? super String> subscriber;

        public OnChangeListener(Subscriber<? super String> subscriber) {
            this.subscriber = subscriber;
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
            if (!subscriber.isUnsubscribed()) {
                subscriber.onNext(key);
            }
        }
    }


}
