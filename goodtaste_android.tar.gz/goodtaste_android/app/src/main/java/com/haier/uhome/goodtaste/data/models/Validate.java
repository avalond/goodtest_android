package com.haier.uhome.goodtaste.data.models;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * 动态验证码
 */
public final class Validate {
    public static final int TYPE_MOBILE = 1;
    public static final int TYPE_EMAIL = 2;

    /**
     * 验证方式
     */
    @IntDef({TYPE_MOBILE, TYPE_EMAIL})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Type {}

    public static final int SCENE_ACTIVATION = 1;
    public static final int SCENE_RESET_PASSWORD = 2;
    public static final int SCENE_UPDATE_EMAIL = 3;
    public static final int SCENE_UPDATE_MOBILE = 4;

    /**
     * 验证场景
     */
    @IntDef({SCENE_ACTIVATION, SCENE_RESET_PASSWORD, SCENE_UPDATE_EMAIL, SCENE_UPDATE_MOBILE})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Scene {}
}
