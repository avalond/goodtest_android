package com.haier.uhome.goodtaste.stores;

import android.content.Context;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.gmail.adffice.rxflux.store.RxStoreChange;
import com.haier.uhome.goodtaste.HaierApplication;
import com.haier.uhome.goodtaste.actions.VideoCommentActions;
import com.haier.uhome.goodtaste.data.DataManager;
import com.haier.uhome.goodtaste.data.HaierPreference;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.CommentInfo;
import com.haier.uhome.goodtaste.data.models.LoginInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.models.VideoCommentInfo;
import com.haier.uhome.goodtaste.data.models.VideoInfo;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;
import com.raizlabs.android.dbflow.sql.language.Select;

import java.util.List;

/**
 * Created by Administrator on 2016/5/6.
 */
public class VideoCommentStores extends BaseStore {

    private UserInfo mUserInfo;
    private String mUserId;
    private LoginInfo mLoginInfo;
    private String mAccessToken;
    private static VideoCommentStores instance;
    private CommentInfo mCommentInfo;

    public static final String ID = "VideoCommentStores";
    RxPreference preference;

    public synchronized static VideoCommentStores get(Context context) {
        if (instance == null) {
            HaierApplication app = (HaierApplication) context.getApplicationContext();
            instance = new VideoCommentStores(app.getRxFlux().getDispatcher());
        }
        return instance;
    }

    private VideoCommentStores(Dispatcher dispatcher) {
        super(dispatcher);
        preference = DataManager.instance().getPreference();
        mAccessToken = preference.getString(HaierPreference.KEY_TOKEN, "");
        mUserId = preference.getString(HaierPreference.KEY_USERID, "");
        mUserInfo = new Select().from(UserInfo.class).querySingle();
    }

    @Override
    protected void onAction(RxAction action) {
        switch (action.getType()) {
            case VideoCommentActions.ID_LIKE:
                BaseResult likedata = (BaseResult) action.getData();
                break;
            case VideoCommentActions.ID_VIDEO_INFO:
                VideoInfo videoinfodata = (VideoInfo) action.getData();

                break;
            case VideoCommentActions.ID_FIVE_MESSAGE:
                List<VideoCommentInfo> fivemessagedata = (List<VideoCommentInfo>) action.getData();

                break;
            case VideoCommentActions.ID_MORE_VIDEO_COMMENT:
                List<VideoCommentInfo> morevideodata = (List<VideoCommentInfo>) action.getData();

                break;
            case VideoCommentActions.ID_VIDEO_LIST_BY_ALBUMID:
                List<VideoInfo> videolistbyalbumid = (List<VideoInfo>) action.getData();

                break;
            case VideoCommentActions.ID_SEND:

                break;
            case VideoCommentActions.ID_COMMENT_VIDEO:
                BaseResult commentvideo = (BaseResult) action.getData();

                break;
            case VideoCommentActions.ID_DELE_VIDEO_ITEM:
                BaseResult deleVideoItem = (BaseResult) action.getData();

            default:
                return;
        }
        postStoreChange(new RxStoreChange(ID, action));
    }

    public String getAccessToken() {
        return mAccessToken;
    }
}
