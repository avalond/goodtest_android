package com.haier.uhome.goodtaste.data.source;

import android.content.Context;

import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.ChefInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;

import java.util.List;

import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;

/**
 * Created by lijin on 16-5-7.
 */
public class ChefRepository implements ChefDataSource {
    private final ChefDataSource mLocalDataSource;
    private final ChefDataSource mRemoteDataSource;
    private final Context mContext;

    public ChefRepository(Context context, ChefDataSource localDataSource, ChefDataSource remoteDataSource) {
        mContext = context;
        mLocalDataSource = localDataSource;
        mRemoteDataSource = remoteDataSource;
    }

    @Override
    public Observable<List<ChefInfo>> findChefRank(String pageNum) {
        Observable<List<ChefInfo>> localData = mLocalDataSource.findChefRank(pageNum)
            .observeOn(AndroidSchedulers.mainThread());
        Observable<List<ChefInfo>> remoteData = mRemoteDataSource.findChefRank(pageNum)
            .flatMap(new Func1<List<ChefInfo>, Observable<List<ChefInfo>>>() {
                @Override
                public Observable<List<ChefInfo>> call(List<ChefInfo> chefInfos) {
                    return saveChefRank(chefInfos);
                }
            })
            .observeOn(AndroidSchedulers.mainThread());

        return Observable.concat(localData, remoteData);
    }

    @Override
    public Observable<List<UserInfo>> findFansByUserId(String userId, String pageNum) {
        return mRemoteDataSource.findFansByUserId(userId, pageNum);
    }

    @Override
    public Observable<Integer> findFansNumByUserId(String userId) {
        return mRemoteDataSource.findFansNumByUserId(userId);
    }

    @Override
    public Observable<List<UserInfo>> findFocusByUserId(String userId, String pageNum) {
        return mRemoteDataSource.findFocusByUserId(userId, pageNum);
    }

    @Override
    public Observable<Integer> findFocusNumByUserId(String userId) {
        return mRemoteDataSource.findFocusNumByUserId(userId);
    }

    @Override
    public Observable<BaseResult> addPraise(String userId, String recipeId) {
        return mRemoteDataSource.addPraise(userId, recipeId);
    }

    @Override
    public Observable<BaseResult> subscribe(String userId, String followedUserId) {
        return mRemoteDataSource.subscribe(userId, followedUserId);
    }

    @Override
    public Observable<BaseResult> unsubscribe(String userId, String followedUserId) {
        return mRemoteDataSource.unsubscribe(userId, followedUserId);
    }

    @Override
    public Observable<Boolean> isSubscribe(String userId, String targetUserId) {
        return mRemoteDataSource.isSubscribe(userId, targetUserId);
    }

    @Override
    public Observable<BaseResult> collectRecipe(String userId, String recipeId) {
        return mRemoteDataSource.collectRecipe(userId, recipeId);
    }

    @Override
    public Observable<BaseResult> uncollectRecipe(String userId, String recipeId) {
        return mRemoteDataSource.uncollectRecipe(userId, recipeId);
    }

    @Override
    public Observable<BaseResult> commentRecipe(String userId, String recipeId, String content) {
        return mRemoteDataSource.commentRecipe(userId, recipeId, content);
    }

    @Override
    public Observable<BaseResult> delCommentRecipe(String id) {
        return mRemoteDataSource.delCommentRecipe(id);
    }

    @Override
    public Observable<List<ChefInfo>> saveChefRank(List<ChefInfo> chefList) {
        return mLocalDataSource.saveChefRank(chefList);
    }
}
