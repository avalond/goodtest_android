package com.haier.uhome.goodtaste.data.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * 食材
 * <br>Created by dallas on 16-5-7.
 */
public class Material implements Serializable {
    private static final long serialVersionUID = -2119667547429401632L;

    /**
     * id : 主键Id
     * name  : 名称
     * pinyin  : 拼音
     * enName  : 英文名
     * picUrl  : 食材图片
     */

    private String id;
    private String name;
    private String pinyin;
    @SerializedName("enanme")
    private String enName;
    private String picUrl;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPinyin() {
        return pinyin;
    }

    public void setPinyin(String pinyin) {
        this.pinyin = pinyin;
    }

    public String getEnName() {
        return enName;
    }

    public void setEnName(String enName) {
        this.enName = enName;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }
}
