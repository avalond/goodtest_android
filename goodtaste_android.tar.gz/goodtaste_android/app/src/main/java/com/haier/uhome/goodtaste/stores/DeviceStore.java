package com.haier.uhome.goodtaste.stores;

import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;

import com.gmail.adffice.rxflux.action.RxAction;
import com.gmail.adffice.rxflux.dispatcher.Dispatcher;
import com.haier.uhome.updevice.device.UpDevice;
import com.raizlabs.android.dbflow.annotation.NotNull;

import java.util.ArrayList;
import java.util.List;

import static com.haier.uhome.goodtaste.utils.Preconditions.checkNotNull;

/**
 * Created by dallas on 16-4-19.
 */
public class DeviceStore extends BaseStore {
    private static DeviceStore instance;

    public synchronized static DeviceStore get(Dispatcher dispatcher) {
        if (instance == null) {
            instance = new DeviceStore(dispatcher);
        }
        return instance;
    }

    private ArrayMap<String, UpDevice> mDeviceMap = new ArrayMap<>();

    protected DeviceStore(Dispatcher dispatcher) {
        super(dispatcher);
    }

    @Override
    protected void onAction(RxAction action) {

    }

    @NotNull
    public List<UpDevice> getDeviceList() {
        return new ArrayList<>(mDeviceMap.values());
    }

    @Nullable
    public UpDevice getDevice(String mac) {
        checkNotNull(mac);
        return mDeviceMap.get(mac);
    }
}
