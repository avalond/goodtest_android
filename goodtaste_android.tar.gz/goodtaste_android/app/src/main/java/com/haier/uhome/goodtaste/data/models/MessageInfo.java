package com.haier.uhome.goodtaste.data.models;

import com.google.gson.annotations.SerializedName;
import com.haier.uhome.goodtaste.data.source.local.GoodTasteDataBase;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.io.Serializable;

/**
 * Created by lijin on 16-5-6.
 */
@Table(database = GoodTasteDataBase.class, allFields = true)
public class MessageInfo extends BaseModel implements Serializable {
    private static final long serialVersionUID = -752634555856923430L;
    @PrimaryKey
    @SerializedName("msgId")
    private String id;

    @SerializedName("userId")
    private String targetUid;
    private String msg;
    private String nickName;
    private String avater;
    private String time;

    private String fromUid;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getTargetUid() {
        return targetUid;
    }

    public void setTargetUid(String targetUid) {
        this.targetUid = targetUid;
    }

    public String getFromUid() {
        return fromUid;
    }

    public void setFromUid(String fromUid) {
        this.fromUid = fromUid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAvater() {
        return avater;
    }

    public void setAvater(String avater) {
        this.avater = avater;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public MessageInfo() {
    }

    public MessageInfo(String targetUid, String msg, String nickName,
                       String avater, String time, String fromUid) {
        this.targetUid = targetUid;
        this.msg = msg;
        this.nickName = nickName;
        this.avater = avater;
        this.time = time;
        this.fromUid = fromUid;
    }
}
