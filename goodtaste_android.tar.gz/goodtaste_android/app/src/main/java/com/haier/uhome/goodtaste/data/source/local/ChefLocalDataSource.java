package com.haier.uhome.goodtaste.data.source.local;

import android.content.Context;

import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.data.models.ChefInfo;
import com.haier.uhome.goodtaste.data.models.UserInfo;
import com.haier.uhome.goodtaste.data.source.ChefDataSource;
import com.haier.uhome.goodtaste.utils.rxPreference.RxPreference;
import com.raizlabs.android.dbflow.runtime.transaction.process.ProcessModelInfo;
import com.raizlabs.android.dbflow.runtime.transaction.process.SaveModelTransaction;
import com.raizlabs.android.dbflow.sql.language.Delete;
import com.raizlabs.android.dbflow.sql.language.SQLite;

import java.util.List;

import rx.Observable;
import rx.Subscriber;
import rx.schedulers.Schedulers;

/**
 * Created by lijin on 16-5-6.
 */
public class ChefLocalDataSource extends AbsLocalDataSource implements ChefDataSource {
    public ChefLocalDataSource(RxPreference preference, Context context) {
        super(preference, context);
    }


    @Override
    public Observable<List<ChefInfo>> findChefRank(String pageNum) {
        return Observable.create(new Observable.OnSubscribe<List<ChefInfo>>() {
            @Override
            public void call(Subscriber<? super List<ChefInfo>> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                List<ChefInfo> recipeList = SQLite.select().from(ChefInfo.class).limit(5).queryList();
                subscriber.onNext(recipeList);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());
    }

    @Override
    public Observable<List<UserInfo>> findFansByUserId(String userId, String pageNum) {
        return null;
    }

    @Override
    public Observable<Integer> findFansNumByUserId(String userId) {
        return null;
    }

    @Override
    public Observable<List<UserInfo>> findFocusByUserId(String userId, String pageNum) {
        return null;
    }

    @Override
    public Observable<Integer> findFocusNumByUserId(String userId) {
        return null;
    }

    @Override
    public Observable<BaseResult> addPraise(String userId, String recipeId) {
        return null;
    }

    @Override
    public Observable<BaseResult> subscribe(String userId, String followedUserId) {
        return null;
    }

    @Override
    public Observable<BaseResult> unsubscribe(String userId, String followedUserId) {
        return null;
    }

    @Override
    public Observable<Boolean> isSubscribe(String userId, String targetUserId) {
        return Observable.empty();
    }

    @Override
    public Observable<BaseResult> collectRecipe(String userId, String recipeId) {
        return null;
    }

    @Override
    public Observable<BaseResult> uncollectRecipe(String userId, String recipeId) {
        return null;
    }

    @Override
    public Observable<BaseResult> commentRecipe(String userId, String recipeId, String content) {
        return null;
    }

    @Override
    public Observable<BaseResult> delCommentRecipe(String id) {
        return null;
    }

    @Override
    public Observable<List<ChefInfo>> saveChefRank(final List<ChefInfo> chefList) {
        return Observable.create(new Observable.OnSubscribe<List<ChefInfo>>() {
            @Override
            public void call(Subscriber<? super List<ChefInfo>> subscriber) {
                if (subscriber.isUnsubscribed()) {
                    return;
                }
                Delete.table(ChefInfo.class);

                // 插入数据
                new SaveModelTransaction<>(ProcessModelInfo.withModels(chefList)).onExecute();

                subscriber.onNext(chefList);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io());
    }
}
