package com.haier.uhome.goodtaste.data.models;

/**
 * Created by Dallas on 2016/2/15.
 */
public class UploadResult extends BaseResult {
    private static final long serialVersionUID = -928529293434115709L;
    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
