package com.haier.uhome.goodtaste.data.source.remote;

import android.support.annotation.IntDef;
import android.support.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.haier.uhome.goodtaste.data.models.BaseEntity;
import com.haier.uhome.goodtaste.data.models.BaseResult;
import com.haier.uhome.goodtaste.exception.BaseException;
import com.haier.uhome.goodtaste.exception.NoneResponseException;
import com.haier.uhome.goodtaste.utils.HaierLoger;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

/**
 * <br>Created by Dallas on 2015/10/22.
 */
public abstract class AbsRemoteDataSource {
    /**
     * 联调环境（开发过程中使用该环境，服务器环境部署在虚拟机上）
     */
    public static final int DEBUG = 0;
    /**
     * 验证环境（同联调环境，只是服务器环境部署在真实设备上）
     */
    public static final int DEBUG_VERIFY = 1;
    /**
     * 验收环境（质量部验收时使用该环境，一般程序内不需要设置该环境。通过使用生产环境域名并设置路由器DNS来接入该环境）
     */
    public static final int PRE_PRODUCT = 2;
    /**
     * 生产环境（使用域名）
     */
    public static final int PRODUCT = 3;

    @IntDef({DEBUG, DEBUG_VERIFY, PRE_PRODUCT, PRODUCT})
    @Retention(RetentionPolicy.SOURCE)
    public @interface EnvironmentMode {}

    public static final String TAG = AbsRemoteDataSource.class.getSimpleName();
    private static long sSequenceIdCount = 0;

    protected final Gson gson;
    protected final OkHttpClient httpClient;
    @EnvironmentMode
    protected final int mode;

    public AbsRemoteDataSource(@EnvironmentMode int mode, @NonNull OkHttpClient httpClient) {
        this.gson = new GsonBuilder().serializeNulls().create();
        this.httpClient = httpClient;
        this.mode = mode;
    }

    public OkHttpClient getHttpClient() {
        return httpClient;
    }

    protected <T> T createService(String url, final Class<T> service) {
        return new Retrofit.Builder().baseUrl(url)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
            .client(httpClient)
            .build()
            .create(service);
    }

    protected Map<String, String> getHeaders() {
        for (Interceptor interceptor : httpClient.interceptors()) {
            if (interceptor instanceof AccessTokenInterceptor) {
                return ((AccessTokenInterceptor) interceptor).getHeaders();
            }
        }
        return new HashMap<>();
    }

    protected static String getSequenceId() {
        String dateStr;
        SimpleDateFormat dFormat = new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault());
        Date date = new Date(System.currentTimeMillis());
        dateStr = dFormat.format(date);
        String count = String.format(Locale.getDefault(), "%06d", sSequenceIdCount);
        sSequenceIdCount++;
        if (sSequenceIdCount > 999999) {
            sSequenceIdCount = 0;
        }
        return dateStr + count;
    }

    protected static final Observable.Transformer RESULT_TRANSFORMER = new ResultTransformer();

    @SuppressWarnings("unchecked")
    protected <T, R> Observable.Transformer<T, R> getTransformer2() {
        return (Observable.Transformer<T, R>) RESULT_TRANSFORMER;
    }

    @SuppressWarnings("unchecked")
    protected <T> Observable.Transformer<T, T> getTransformer() {
        return (Observable.Transformer<T, T>) RESULT_TRANSFORMER;
    }

    @SuppressWarnings("unchecked")
    static class ResultTransformer<T, R> implements Observable.Transformer<T, R> {
        @Override
        public Observable<R> call(Observable<T> observable) {
            return observable.subscribeOn(Schedulers.io()).map(new Func1<T, R>() {
                @Override
                public R call(T result) {
                    if (result == null) {
                        throw new NoneResponseException();
                    }
                    if (result instanceof BaseResult && !BaseResult.RET_OK.equals(((BaseResult) result).getRetCode())) {
                        throw new BaseException(((BaseResult) result).getRetInfo(), ((BaseResult) result).getRetCode());
                    }
                    if (result instanceof BaseEntity) {
                        if (!BaseEntity.RET_OK.equals(((BaseEntity) result).getRetCode())) {
                            throw new BaseException(((BaseEntity) result).getRetInfo(),
                                ((BaseEntity) result).getRetCode());
                        } else {
                            return (R) ((BaseEntity) result).getData();
                        }
                    }
                    return (R) result;
                }
            }).doOnError(new Action1<Throwable>() {
                @Override
                public void call(Throwable throwable) {
                    String errorMsg = throwable.getMessage();
                    HaierLoger.e(TAG, errorMsg);
                }
            }).observeOn(AndroidSchedulers.mainThread());
        }
    }

}
